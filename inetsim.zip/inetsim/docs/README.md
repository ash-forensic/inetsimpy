# inetsim-py Documentation

This directory contains operational and design notes for running `inetsim-py`,
a modern Python 3 reimplementation of the INetSim lab workflow. It was built
to address the DNS instability encountered with the Perl-based tool in this
lab and extend TLS capture, Tor interface emulation and configurable web responses.

Start with the [GitHub README](../README.md) for installation, configuration,
features and a summary of tested operating systems.

## Documents

- [Architecture](architecture.md): package layout, service lifecycle, logging, artifacts, and trust boundaries.
- [Features](features.md): supported services, protocol behavior, TLS behavior, Tor emulation, and known limits.
- [Web Responses](web-responses.md): the modern simulated sign-in page, customization, fingerprinting limits and the WannaCry kill-switch distinction.
- [Lab Setup](lab-setup.md): REMnux/FLARE-VM style host-only setup and common run commands.
- [Windows Client Lab](windows-client-lab.md): private internal network, Windows DNS/default gateway through REMnux, traffic interception, and native client probes.
- [DNS Setup](dns-setup.md): Linux, Windows, phone, VM, and browser DNS configuration.
- [Download Workflow](download-workflow.md): runnable harmless replacements, architecture selection, extensionless stages, and client execution validation.
- [Tor Setup](tor-setup.md): onion SOCKS endpoints, focused client validation, logging, and real-Tor limits.
- [Validation](validation.md): profile requirements, repeatable client probes, recorded REMnux results, and test scope.
- [Testing Results](testing-results.md): tested OS versions and roles, latest suite counts, Linux/native Windows/Wine results, skips and evidence filenames.
- [Certificate Setup](certificates.md): built-in HTTPS lab CA, mitmproxy CA, Linux/Windows install scripts, browser trust.
- [Compatibility Results](compatibility-results.md): signed CRL validation, pin enforcement, the supplied WannaCry observation and real Tor boundaries.
- [CLI Reference](cli-reference.md): all CLI commands, arguments, and common examples.
- [Troubleshooting](troubleshooting.md): common failures and focused commands to diagnose them.

## Safety Model

Use this project only on isolated lab networks. The simulator is designed to observe and contain client behavior; it is not intended to be exposed to production networks or the public internet.
