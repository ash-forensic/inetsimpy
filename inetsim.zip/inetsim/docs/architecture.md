# Architecture

`inetsim-py` is an asyncio service runner with a small configuration layer, per-service protocol handlers, JSONL event logging, and content-addressed artifact storage.

## Package Layout

- `src/inetsim_py/cli.py`: command-line interface, interface detection, DNS override lifecycle, local CA trust lifecycle, diagnostics.
- `src/inetsim_py/config.py`: TOML parsing, defaults, dataclass config objects, validation, port-collision checks.
- `src/inetsim_py/runner.py`: starts enabled services, tracks running servers/processes, stops them cleanly.
- `src/inetsim_py/logger.py`: JSONL event writer.
- `src/inetsim_py/timeutils.py`: shared real/fake time source for logs and protocol responses.
- `src/inetsim_py/artifacts.py`: bounded content-addressed artifact storage.
- `src/inetsim_py/downloads.py`: packaged binary templates, interpreter-specific scripts, and opt-in raw return stubs.
- `src/inetsim_py/data/downloads/`: compiled harmless replacements and their source/binary hash manifest.
- `src/inetsim_py/acl.py`: client CIDR allow-list checks.
- `src/inetsim_py/services/`: individual protocol emulators.
- `src/inetsim_py/mitm_addon.py`: mitmproxy addon used when optional proxy mode is enabled.
- `configs/lab-subnet.toml`: lab profile using standard service ports.
- `scripts/`: CA helpers, independent client validators, and the maintainer binary rebuild script.
- `tools/download-stubs/`: auditable C/assembly sources; compilers are only needed to rebuild the packaged replacements.

## Runtime Flow

1. CLI loads TOML or built-in defaults.
2. Optional `--interface` detects the first IPv4 address/CIDR on the requested interface and overrides:
   - `global.listen_host`
   - `global.allowed_clients`
   - `services.dns.sinkhole_ip`
   - `services.dns.sinkhole_ipv4`
3. Config validation checks data types, listen addresses, networks, ports, banners, and enabled-service port collisions.
4. Optional `--manage-dns` applies a systemd-resolved DNS override for the local host.
5. `InetSimPy.start()` constructs shared helpers:
   - `SubnetAcl`
   - `EventLogger`
   - `ArtifactStore`
   - shared fake-time configuration from `global.fake_time_utc`
6. Enabled services bind their listeners and return `RunningService` objects.
7. On Ctrl-C/SIGTERM, services stop, a session report is written, managed CA trust is removed, managed DNS is reverted, and project `__pycache__` directories are removed.

## Service Lifecycle

Each service follows the same pattern:

- Accept only clients allowed by `global.allowed_clients`.
- Parse a bounded request or command sequence.
- Respond with controlled, local-only behavior.
- Write a structured JSONL event.
- Save request bodies or submitted data as artifacts only when configured limits allow.

`RunningService` tracks TCP servers, UDP transports, optional subprocesses, and startup notes. The runner closes every registered object on shutdown.

## Logging

Logs are newline-delimited JSON under `logs/`, one file per protocol:

- `dns.jsonl`
- `ntp.jsonl`
- `tftp.jsonl`
- `http.jsonl`
- `https.jsonl`
- `smtp.jsonl`
- `pop3.jsonl`
- `ftp.jsonl`
- `smb.jsonl`
- `mitmproxy.jsonl`
- `tor_socks.jsonl`
- `tor_control.jsonl`
- `tcp.jsonl`
- `dummy.jsonl`

Each event includes a UTC timestamp and protocol name. Sensitive fields such as SMTP/POP3/FTP passwords and Tor control authentication are redacted, with length/hash metadata where useful.

Generated web downloads include `response_kind`, `download_name`, and
`response_sha256`; proxy synthesis also records the response artifact. These
identify bytes served, not client execution. Tor events additionally retain the
requested onion target, service ID/subdomain, and HTTP/TLS or binary metadata.

When `global.fake_time_utc` is set, event timestamps are pinned to that configured timestamp. Shutdown also writes `logs/session-*.json` with service and event-count metadata. Session report filenames use real wall-clock UTC plus a random suffix, so repeated fake-time runs do not overwrite each other.

## Artifacts

Artifacts are stored under `artifacts/` using SHA-256 filenames. The configured limit is `global.max_artifact_bytes`.

Examples:

- HTTP/HTTPS request bodies.
- SMTP messages.
- FTP/TFTP uploads.
- Optional FTP upload index under the artifact directory when `services.ftp.persist_uploads` is enabled.
- mitmproxy request/response bodies.
- Tor SOCKS HTTP request bodies.
- Generated TLS certificates.
- mitmproxy runtime configuration and CA files.

## Session State

Runtime-only state is reset when the process exits, except for artifacts written under `global.artifact_dir`.

When `services.ftp.persist_uploads = true`, completed FTP uploads are captured as artifacts and indexed in:

```text
artifacts/ftp/uploads/index.json
```

On the next run, FTP reloads that index and exposes the uploaded files in the virtual FTP filesystem. If an indexed artifact is missing, the stale entry is removed when encountered.

## Trust Boundaries

- DNS sinkholing redirects names to the simulator but does not force browsers or malware to trust TLS certificates.
- Built-in HTTPS uses a generated lab CA and per-SNI certificates for arbitrary sinkholed hostnames when clients trust `artifacts/tls/inetsim-ca.crt`; clients without SNI, without CA trust, or with certificate pinning may still reject it.
- mitmproxy can inspect HTTPS only when the client uses the proxy and trusts the mitmproxy CA. Certificate-pinned clients may still reject it.
- Tor SOCKS/control answer application-facing requests without real circuits or onion cryptographic identities. Target port `443` checks buffered early HTTP and a short socket sniff window before selecting TLS. Pre-buffered optimistic TLS is unsupported; binary protocols are logged/closed. See [Tor setup](tor-setup.md).
- Replacement programs only execute when the client runs them. Validation scripts require an explicit `--execute` and an exact match with a known harmless template; the server never executes downloads. See [download workflow](download-workflow.md).
