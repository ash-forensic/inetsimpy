# Certificate Setup

TLS behavior depends on what the client trusts.

## Built-in HTTPS Lab CA

The built-in HTTPS service generates a local lab CA and CA-signed HTTPS certificates under:

```text
artifacts/tls/inetsim-ca.crt
artifacts/tls/inetsim-ca.key
artifacts/tls/inetsim-https.crt
artifacts/tls/inetsim-https.key
artifacts/tls/hosts/<requested-sni>.crt
artifacts/tls/hosts/<requested-sni>.key
```

The default certificate hostname comes from:

```toml
[services.https]
cert_common_name = "inetsim.local"
```

When a client connects with SNI, the HTTPS service generates a per-host certificate signed by `artifacts/tls/inetsim-ca.crt`. For example, a sinkholed request for `https://google.com/` gets a certificate for `google.com`.

For browser or OS validation to pass, install this CA into the client trust store:

```text
artifacts/tls/inetsim-ca.crt
```

Certificate-pinned clients may still reject the generated certificate.

## Signed revocation data for Windows

The built-in CA can publish a signed CRL so Windows Schannel can perform its
normal revocation checks. Enable the following setting with the client's
reachable REMnux address, and keep the HTTP listener enabled:

```toml
[global]
tls_crl_url = "http://192.168.56.5/pki/lab-ca.crl"
```

Restart INetSim. The existing CA and client trust stay in use. Generated web,
SMTP/POP3/FTP and SOCKS HTTPS certificates gain a CRL Distribution Points
extension; existing leaf files are updated when loaded. Existing leaf private
keys are retained. Updating a certificate can still change an exact certificate
fingerprint, so keep identity changes in mind when testing pins.

The HTTP listener serves the signed DER CRL at the configured path, with
`application/pkix-crl`, before ordinary page/download routes. It exposes only
this CRL, not the CA private key or arbitrary files. The CRL is valid for seven
days; a background check every 30 minutes renews it when less than a day remains.
Explicit revocations survive renewal. This requires OpenSSL and writable lab
PKI state under `artifacts/tls/pki/`.

Default Windows curl now works without `--ssl-revoke-best-effort`,
`--ssl-no-revoke`, or `--insecure` in the prepared lab. The optional mitmproxy
CA is separate; this feature applies to certificates issued by the built-in CA.
OCSP-only clients and externally issued certificate chains need their own
compatible revocation service.

From the REMnux project working directory, publish a fresh CRL or revoke an
owned test leaf:

```bash
cd /home/remnux/inetsim-vm-validation
sudo .venv/bin/python scripts/manage-crl.py --config configs/vm-validation-full.toml refresh
sudo .venv/bin/python scripts/manage-crl.py --config configs/vm-validation-full.toml revoke artifacts/tls/hosts/owned-test.test.crt
```

Windows caches CRLs and certificate-chain results. A newly published revocation
does not instantly invalidate an older cached result. For a deliberate lab
revocation test, use a fresh client state, or refresh the caches from an
Administrator prompt and restart the client:

```powershell
certutil -urlcache http://192.168.56.5/pki/lab-ca.crl delete
certutil -setreg chain\ChainCacheResyncFiletime @now
```

Microsoft documents [CRL retrieval and validation](https://learn.microsoft.com/en-us/windows-server/identity/ad-cs/operate-certificate-revocation-crl-cdp)
and [cache invalidation](https://techcommunity.microsoft.com/blog/coreinfrastructureandsecurityblog/how-to-refresh-the-crl-cache-on-windows-vista/1128394/).
Inspect the revocation result printed by `certutil -verify -urlfetch`; it can
report a revoked leaf while returning process exit code zero.

Repeat the native positive/negative checks using
`scripts/validate-windows-revocation.py`. The positive check also proves that a
matching public-key pin succeeds and a different pinned key is rejected.
See [compatibility results](compatibility-results.md) for the dated evidence.

For strict verification on the first connection, prewarm known names or enable
synchronous first-seen generation:

```toml
[services.https]
prewarm_hosts = ["example.test"]
block_on_unknown_sni = true
```

Without these settings, an unknown first-seen SNI can receive the default
certificate while a matching certificate is generated asynchronously. Synchronous
generation briefly blocks the event loop. DNS identities longer than 64
characters, including onion subdomains, retain the full SAN; their certificate
CN uses a short fallback. Client hostname verification checks the SAN.

SMTP/POP3/FTP TLS and Tor SOCKS HTTPS use the same built-in lab CA. Tor HTTPS
uses the requested SOCKS hostname; point the application at the Tor SOCKS
endpoint as described in [Tor setup](tor-setup.md).

To change the generated default certificate identity, set this key in the
existing HTTPS section:

```toml
cert_common_name = "example.test"
```

With the service stopped, remove the old generated default certificate and key,
then restart it so they regenerate:

```bash
rm -f artifacts/tls/inetsim-https.crt artifacts/tls/inetsim-https.key
```

Clients still need to trust the lab CA or a configured certificate chain.

Changing `cert_common_name` only changes the default certificate; SNI-based
identities remain enabled. To supply a fixed certificate/key pair instead:

```toml
[services.https]
auto_generate_cert = false
cert_file = "certs/server.crt"
key_file = "certs/server.key"
```

That pair configures the web HTTPS listener. Other built-in TLS services still
use their generated certificates and lab CA.

## mitmproxy CA

When mitmproxy starts, it creates CA files under:

```text
artifacts/mitmproxy/conf/
```

The commonly installed CA file is:

```text
artifacts/mitmproxy/conf/mitmproxy-ca-cert.pem
```

For HTTPS inspection through mitmproxy:

1. Configure the client to use the simulator as proxy.
2. Install the mitmproxy CA into the client trust store.
3. Restart the browser or application if needed.

Certificate-pinned clients may still reject interception.

## Temporary Trust on Simulator Host

When mitmproxy is enabled and the simulator host itself is the HTTPS client:

```bash
sudo python3 inetsim.py --interface <iface> --manage-dns --trust-mitm-ca --config configs/lab-subnet.toml run
```

This installs the mitmproxy CA into the local Debian/Ubuntu trust store while the simulator runs and removes it on normal shutdown.

## Linux Client Helper

Install:

```bash
sudo ./scripts/install-ca-linux.sh install artifacts/tls/inetsim-ca.crt inetsim-https-lab
```

Remove:

```bash
sudo ./scripts/install-ca-linux.sh remove inetsim-https-lab
```

For mitmproxy HTTPS inspection, install its separate public CA under another
name. Both CAs can coexist when testing built-in services and the proxy:

```bash
sudo ./scripts/install-ca-linux.sh install artifacts/mitmproxy/conf/mitmproxy-ca-cert.pem inetsim-mitm-lab
```

Remove that proxy CA after testing:

```bash
sudo ./scripts/install-ca-linux.sh remove inetsim-mitm-lab
```

The helper uses:

```text
/usr/local/share/ca-certificates/<name>.crt
update-ca-certificates
```

Omitting the name uses `inetsim-mitmproxy-ca` for either input. Use distinct
names to avoid replacing one CA with the other, and copy only the public
certificate plus helper to the client VM.

## Windows Client Helper

Copy these files to the Windows VM:

```text
inetsim-ca.crt
scripts/install-ca-windows.ps1
```

Run Administrator PowerShell:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\install-ca-windows.ps1 -Action Install -CertPath .\inetsim-ca.crt
```

Remove:

```powershell
.\install-ca-windows.ps1 -Action Remove
```

The Windows helper installs into:

```text
Local Machine -> Trusted Root Certification Authorities
```

For a precise removal, pass the certificate path:

```powershell
.\install-ca-windows.ps1 -Action Remove -CertPath .\inetsim-ca.crt
```

## Firefox

Firefox may use its own certificate store.

Option 1, use Windows roots:

```text
about:config
security.enterprise_roots.enabled = true
```

Option 2, import manually:

```text
Settings -> Privacy & Security -> Certificates -> View Certificates -> Authorities -> Import
Trust this CA to identify websites
```

## Browser Cache

After installing or removing a CA:

- Restart the browser.
- Clear SSL state if needed.
- Flush DNS if testing name resolution at the same time.
