# CLI Reference

The console entry point is:

```bash
inetsim-py [global options] <command>
```

When running from a checkout, the equivalent command is:

```bash
python3 inetsim.py [global options] <command>
```

Global options must appear before the subcommand.

## Global Options

| Option | Description |
| --- | --- |
| `-h`, `--help` | Show CLI help and exit. |
| `-c CONFIG`, `--config CONFIG` | Path to a TOML configuration file. If omitted, built-in safe loopback defaults are used. |
| `-i INTERFACE`, `--interface INTERFACE` | Detect IPv4 address and CIDR from this interface and override `global.listen_host`, `global.allowed_clients`, `services.dns.sinkhole_ip`, and `services.dns.sinkhole_ipv4` for this run. |
| `--manage-dns` | During `run`, point systemd-resolved DNS for `--interface` at the simulator and revert on exit. Requires `--interface`. |
| `--trust-mitm-ca` | During `run`, install the managed mitmproxy CA into the local OS trust store and remove it on exit. Requires `services.mitmproxy.enabled = true`. |
| `--trust-https-ca` | During `run`, install the built-in HTTPS lab CA into the local OS trust store and remove it on exit. |
| `--transparent-proxy` | During `run`, install local iptables OUTPUT redirects for TCP/80 and TCP/443 and revert on exit. |
| `--transparent-router` | During `run`, install forwarded-traffic iptables PREROUTING redirects for TCP/80 and TCP/443 and revert on exit. |
| `--transparent-interface INTERFACE` | Limit transparent iptables rules to an interface. Uses `-o` for local OUTPUT mode and `-i` for router PREROUTING mode. Defaults to `--interface` when set. |
| `--transparent-source CIDR` | Limit transparent iptables rules to an IPv4 source CIDR. May be repeated. Router mode defaults to IPv4 `global.allowed_clients` when omitted. |

## Commands

| Command | Description |
| --- | --- |
| `run` | Run all enabled services. This is the default command if no command is supplied. |
| `doctor` | Probe configured local DNS, HTTP, and HTTPS listeners. Useful when a browser or client is not reaching the simulator. |
| `restore-dns` | Revert managed DNS for `--interface`, flush systemd-resolved caches, and ask NetworkManager to reapply the interface when available. Requires `--interface`. |
| `restore-transparent` | Remove local iptables transparent proxy rules for the current config. |
| `check-config` | Parse config, apply any `--interface` override, validate settings, and print an effective service summary. |
| `print-default-config` | Print the built-in TOML configuration. |

Subcommands currently only accept `-h`/`--help`; they do not define command-specific options.

## Common Examples

Run with built-in loopback defaults:

```bash
inetsim-py run
```

Run a lab profile on an interface, auto-detecting the interface IP/CIDR:

```bash
sudo python3 inetsim.py --interface eth1 --config configs/lab-subnet.toml run
```

Run a lab profile and temporarily manage local DNS on the simulator host:

```bash
sudo python3 inetsim.py --interface eth1 --manage-dns --config configs/lab-subnet.toml run
```

Run mitmproxy mode and temporarily trust the mitmproxy CA on the simulator host:

```bash
sudo python3 inetsim.py --interface eth1 --manage-dns --trust-mitm-ca --config configs/lab-subnet.toml run
```

Recover local DNS after a hard stop:

```bash
sudo python3 inetsim.py --interface eth1 restore-dns
```

Show the effective lab config:

```bash
python3 inetsim.py --interface eth1 --config configs/lab-subnet.toml check-config
```

Probe local listeners:

```bash
python3 inetsim.py --interface eth1 --config configs/lab-subnet.toml doctor
```

Print the built-in default config:

```bash
python3 inetsim.py print-default-config
```

## Command Notes

### `--interface`

Uses:

```bash
ip -j -4 addr show dev <interface>
```

The first IPv4 address found is used. For example, an interface with `10.10.20.5/24` becomes:

```text
global.listen_host = "10.10.20.5"
global.allowed_clients = ["10.10.20.0/24"]
services.dns.sinkhole_ip = "10.10.20.5"
services.dns.sinkhole_ipv4 = "10.10.20.5"
```

The config file on disk is not modified.

### `global.fake_time_utc`

Set this to an ISO-8601 timestamp to freeze simulator time across logs, HTTP `Date` headers, NTP responses, and session reports:

```toml
[global]
fake_time_utc = "2024-01-01T00:00:00Z"
```

Leave it empty for real current UTC time.

### Session Reports

On normal shutdown, `inetsim-py` writes a JSON session summary:

```text
logs/session-*.json
```

The report includes running services, event counts, allowed clients, listen address, artifact directory, and fake-time configuration.

The filename uses real wall-clock UTC plus a random suffix, even when `global.fake_time_utc` is set, so multiple runs do not overwrite each other.

### Download template configuration

`services.http.fake_download_extensions` maps suffixes to harmless templates;
`services.http.fake_download_routes` maps exact URL paths, including paths with
no extension. Merge into the relevant existing TOML table:

```toml
[services.http.fake_download_routes]
"/get-stage" = "windows_executable_x64"
"/bootstrap" = "shell_script"
```

Configured text routes take precedence, followed by the enabled login page,
exact download paths, extension matches, and the default body. URL query strings
do not affect path matching. Built-in web services use
`services.http.fake_downloads_enabled`; the proxy uses
`services.mitmproxy.synthesize_downloads`.

See [download workflow](download-workflow.md) for all template kinds and
[validation](validation.md) for the standalone client scripts. Their options
belong to those scripts, not the `inetsim-py run` subcommand.

### FTP upload persistence

FTP uploads are always captured as artifacts when size limits allow. To reload completed uploads into the FTP virtual filesystem on later runs, enable:

```toml
[services.ftp]
persist_uploads = true
upload_index = "ftp/uploads/index.json"
```

The index path is relative to `global.artifact_dir`.

Within one running session, completed FTP uploads are immediately available for later `LIST`, `SIZE`, and `RETR` commands. Across restarts, only uploads recorded in the index are restored.

### `--manage-dns`

Applies local host DNS changes using:

```bash
resolvectl dns <interface> <simulator-ip>
resolvectl domain <interface> '~.'
resolvectl flush-caches
```

On cleanup, it runs:

```bash
resolvectl revert <interface>
resolvectl flush-caches
nmcli device reapply <interface>   # when nmcli is available
resolvectl flush-caches
```

This affects only the machine running the simulator. Other VMs or phones still need their DNS set to the simulator IP.

### `--trust-mitm-ca`

Waits for:

```text
artifacts/mitmproxy/conf/mitmproxy-ca-cert.pem
```

Then installs it as:

```text
/usr/local/share/ca-certificates/inetsim-py-mitmproxy.crt
```

and runs:

```bash
update-ca-certificates
```

On cleanup, the managed CA is removed or the previous file is restored.

This option targets Debian/Ubuntu-style trust stores on the simulator host. Use the helper scripts in `scripts/` for lab clients.

### `--trust-https-ca`

Waits for:

```text
artifacts/tls/inetsim-ca.crt
```

Then installs it into the local Debian/Ubuntu trust store while the simulator runs. This is for direct HTTPS sinkholing with generated per-SNI certificates.

### `--transparent-proxy`

Installs local iptables rules similar to:

```bash
iptables -t nat -A OUTPUT -p tcp --dport 80 -j REDIRECT --to-ports <http-port>
iptables -t nat -A OUTPUT -p tcp --dport 443 -j REDIRECT --to-ports <https-or-mitmproxy-port>
iptables -t nat -A OUTPUT -p udp --dport 443 -j REDIRECT --to-ports <quic-port>
```

When `--transparent-interface eth0` is used, OUTPUT rules include `-o eth0`. When `--transparent-source 192.0.2.10/32` is used, rules include `-s 192.0.2.10/32`.

It reverts these rules on normal shutdown. This affects local outbound traffic on the simulator host; routing other guests through the simulator still requires network/firewall setup outside the process.

### `--transparent-router`

Installs router-style iptables rules similar to:

```bash
iptables -t nat -A PREROUTING -p tcp --dport 80 -j REDIRECT --to-ports <http-port>
iptables -t nat -A PREROUTING -p tcp --dport 443 -j REDIRECT --to-ports <https-or-mitmproxy-port>
iptables -t nat -A PREROUTING -p udp --dport 443 -j REDIRECT --to-ports <quic-port>
```

When `--transparent-interface eth1` is used, PREROUTING rules include `-i eth1`. If no `--transparent-source` is provided, router mode adds one rule per IPv4 `global.allowed_clients` CIDR.

Use this when the simulator host is the routed gateway for sandbox guests. To remove those rules after a hard stop, pass the same mode and selector options to cleanup:

```bash
sudo python3 inetsim.py --config configs/lab-subnet.toml --transparent-router --transparent-interface eth1 restore-transparent
```
