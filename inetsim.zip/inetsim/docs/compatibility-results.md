# TLS revocation, pinning and the supplied WannaCry sample

## Revocation fixed in the prepared lab

On 2026-10-18, signed CRL publication was added for the built-in lab CA and
enabled on REMnux. The existing CA certificate and client trust were preserved.
Tests on native Windows 11 Pro/Tiny11 build 22621.525 observed:

- Default Schannel curl accepted a valid, freshly issued lab certificate without
  any revocation bypass flag.
- Windows `certutil -verify -urlfetch` retrieved the signed CRL and verified the
  valid leaf.
- After revoking that leaf and publishing an updated CRL, default curl and
  certutil rejected/reported it as revoked from a fresh Windows state.
- A matching SHA-256 public-key pin succeeded; a different pinned key failed
  with curl exit code 90.
- All 12 Windows routing checks passed with default revocation policy.
- All 22 SOCKS/onion checks passed without the previous offline-revocation flag;
  400 sessions at concurrency 16, including 100 TLS, had zero failures.
- All 17 native protocol groups passed after the CRL update.
- The host regression suite passed 216 tests with 9 skips; the deployed REMnux
  suite passed 215 tests with 10 skips.

An older cached certificate-chain result remained accepted in the original
client during the first revoke test. A fresh VM rejected the leaf. After the
documented cache refresh and a reboot, the original Windows client also
rejected it in both default curl and certutil. All four valid-leaf/pin checks
and both revoked-leaf checks passed again after reboot. All 12 routing checks
also passed after reboot with normal revocation policy. The
[certificate guide](certificates.md) explains cache refresh and the seven-day
CRL validity window. `certutil`'s text result must be inspected: its
process can exit zero even when its output says the leaf is revoked.

## Certificate pinning is an identity constraint

A trusted CA and valid revocation information do not satisfy a client's pin for
a different key or exact certificate. The native test above confirms that
pinning remains enforced. Installing a CA cannot supply another endpoint's
private key.

For an owned pinned test endpoint, use its matching certificate/key through
`services.https.cert_file` and `key_file`, or configure the test client's pin to
match the owned lab identity. Existing fixed certificate support already serves
that use case. A client whose pin cannot be configured needs a separate,
sample-specific analysis/instrumentation plan. Any such client change must be
recorded when interpreting behavior; this update does not claim a universal
pinning bypass.

## Supplied PMAT WannaCry observation

The user-supplied archive was:

```text
PMAT-labs-main/labs/4-1.Bossfight-wannacry.exe/Ransomware.wannacry.exe.malz.7z
Sample SHA-256: 24d004a104d4d54034dbcffc2a4b19a11f39008a575aa614ea04703480b1022c
Size: 3,723,264 bytes; x86 PE
```

The archive was read statically without executing its contents on the host.
Its embedded resource contains a Tor bundle whose executable reports version
`0.2.9.10` in its strings. The outer executable imports WinINet HTTP functions
and contains the plain-HTTP kill-switch domain.

The exact sample bytes were run once in a separate disposable Windows clone.
The original Windows client was off. REMnux and the clone each had one internal
network adapter; there was no external route, NAT/bridge/host-only attachment,
shared folder, clipboard or drag/drop. Defender initially quarantined the file.
A temporary exclusion was then confined to the clone's analysis folder.

Observed behavior:

- One DNS A request for `www.iuqerfsodp9ifjaposdfjhgosurijfaewrwergwea.com`
  from `192.168.56.20` resolved to REMnux at `192.168.56.5`.
- One HTTP/1.1 GET for `/` received HTTP 200 and the simulator's 3,940-byte
  enterprise login page. The logged User-Agent was empty.
- The sample exited with code 0 after 0.625 seconds.
- The observation sentinel retained its exact SHA-256. At the later process
  snapshot, the only new process was the observation helper's PowerShell.
- No HTTPS, SOCKS, Tor control, SMB or other logged service activity appeared
  during the 14-second observation window.
- An 11-packet execution-window PCAP contains the kill-switch request and
  HTTP 200 response.

### Why execution stopped

The observed successful HTTP contact followed by a normal exit is consistent
with WannaCry's own kill-switch branch. The observation launcher did not
terminate the process. Microsoft documents that a successful `InternetOpenUrlA`
connection to this variant's kill-switch URL stops further execution.
[Microsoft's WannaCrypt analysis](https://www.microsoft.com/en-us/security/blog/2017/05/12/wannacrypt-ransomware-worm-targets-out-of-date-systems/)
describes the check.

DNS resolution alone is not that successful URL connection. In this run,
INetSim also answered HTTP, satisfying the reachable-site condition. Recognition
of a particular INetSim HTML string is not required for this check; changing the
page appearance does not by itself avoid it. See [web response profiles](web-responses.md).

### Saved evidence

| File in `compatibility-fixes/` | Contents |
| --- | --- |
| `wannacry-execution-window.pcap` | 11 packets; 5,172 bytes; narrow window around execution |
| `wannacry-capture.pcap` | 169 packets; 25,783 bytes; includes surrounding observation traffic |
| `wannacry-server-events.json` | Correlated DNS/HTTP records and empty HTTPS/SOCKS/control/SMB service-event lists |
| `wannacry-observation.json` | Sample hash, PID 2620, UTC start/end, exit code, elapsed time, sentinel hashes and later process snapshot |
| `wannacry-static.json` | PE/import/resource metadata, kill-switch URL and bundled Tor version strings/hash |

Execution started at `2026-10-18T08:12:11.237588Z`; the observation ended at
`08:12:25.336373Z`. The process exited after 0.625 seconds, before the wider
observation ended. The sentinel and later process snapshot are limited probes,
not a complete filesystem or process-creation audit.

This establishes the observed DNS/HTTP behavior, not ransomware encryption,
TLS pinning or Tor bootstrap compatibility. No kill-switch or sample code was
patched. The
sample-run clone was discarded after exporting evidence and recreated from the
clean source snapshot.

## Real Tor bootstrap

The existing SOCKS emulator supplies application responses. It does not act as
Tor relays, directory authorities or an onion rendezvous network. A real Tor
client verifies directory and relay identities; DNS/HTTP redirection cannot
produce trusted signed consensus data for the public network. See the
[Tor directory protocol](https://spec.torproject.org/dir-spec/).

An isolated real-Tor test needs a private Tor network and a client explicitly
configured to trust its authorities, for example using the Tor Project's
[Chutney test-network tooling](https://research.torproject.org/tools/). That is
a distinct configuration, and it does not recreate the identities or private
keys of the sample's original onion services. The observed WannaCry run never
reached its bundled Tor stage, so no real bootstrap success is claimed.

The local evidence directory is
`/home/shadocat/Downloads/VM/inetsim-validation/compatibility-fixes/`.
It contains native client reports, the signed-CRL test results, static sample
metadata, process observations and PCAPs. It contains no decrypted malware
executable; the original encrypted archive remains at its supplied location.

Both main VMs have a powered-off `crl-validated` snapshot and were restarted
successfully. The simulator, routing and packet-capture services were active
after boot, with no external route and IPv4 forwarding disabled. The primary
Windows client retains normal Defender protection. The clean analysis clone
remains powered off. See [restore instructions](windows-client-lab.md#restore-the-prepared-lab).
