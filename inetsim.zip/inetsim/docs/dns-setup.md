# DNS Setup

DNS is the most important piece for normal INetSim-style behavior. Clients must use the simulator as their DNS server.

## Wildcard Answers for Nonexistent Domains

With `services.dns.wildcard = true`, any valid queried hostname gets an A
record pointing to `services.dns.sinkhole_ipv4` (or the IPv4 `sinkhole_ip`).
The answer retains the queried hostname. The simulator generates it locally;
the domain does not need to exist or resolve on the internet.

For example, a query for `made-up-domain.invalid` can return:

```text
made-up-domain.invalid. 60 IN A 192.168.56.5
```

Configured static records override the wildcard. AAAA answers require an IPv6
sinkhole or a matching static IPv6 record. Unconfigured record types return
successful empty answers (NOERROR/NODATA), allowing clients to fall back to A.
This does not synthesize arbitrary MX/TXT/HTTPS records; configure supported
record types explicitly. Setting `wildcard = false` makes unknown names return
NXDOMAIN.

The client's normal resolver must actually send its query to the simulator.
Browsers using Secure DNS, and operating systems handling special names locally,
can bypass it. Use `.test` names for normal browser/OS tests and query the
simulator directly when checking `.invalid` names.

## Repeatable Validation

The optional `validation` extra installs dnspython, an independent DNS client:

```bash
python3 -m pip install -e '.[validation]'
python3 scripts/validate-dns.py 192.168.56.5 --queries 10000 --tcp-queries 2000 --concurrency 32 --json dns-validation.json
python3 scripts/validate-protocols.py 192.168.56.5
```

Run these from a client VM with the simulator as its DNS server and the required
lab CAs installed. The protocol validator's base profile expects mitmproxy on
8080 in addition to the lab config's built-in services. Its `--extended` mode
also expects SMTP/POP3/FTP implicit TLS on 465/995/990 and `/large.txt` containing
`0123456789abcdef` repeated 256 times in the FTP and TFTP virtual file maps.
The prepared offline bundle includes `configs/vm-expanded-validation.toml` for
these checks. Its DNS record matrix is enabled with `--records` and its IPv6
answer with `--ipv6-sinkhole fd00:56::5`; that verifies the DNS AAAA answer over
IPv4, rather than IPv6 connectivity. Pass `--doh-url https://example.test/dns-query`
to check DoH GET and POST with normal TLS verification.

The DNS validator checks wildcard names, case and length boundaries, EDNS,
record-type behavior, sequential/pipelined TCP queries, malformed inputs,
normal OS resolution, and concurrent unique queries. It reports failures and
latencies; it does not establish a performance comparison with Perl INetSim.

## Linux Client

Temporary systemd-resolved override:

```bash
sudo resolvectl dns <interface> <simulator-ip>
sudo resolvectl domain <interface> '~.'
sudo resolvectl flush-caches
```

Revert:

```bash
sudo resolvectl revert <interface>
sudo resolvectl flush-caches
```

With NetworkManager, a reapply can refresh DNS without toggling Wi-Fi:

```bash
sudo nmcli device reapply <interface>
```

## Simulator Host Managed DNS

When running `inetsim-py` on Linux, this can be automated for the simulator host:

```bash
sudo python3 inetsim.py --interface <iface> --manage-dns --config configs/lab-subnet.toml run
```

Manual recovery after a hard stop:

```bash
sudo python3 inetsim.py --interface <iface> restore-dns
```

## Windows / FLARE-VM

Run PowerShell as Administrator.

List adapters:

```powershell
Get-NetAdapter
```

Set DNS on the host-only adapter:

```powershell
Set-DnsClientServerAddress -InterfaceAlias "Ethernet" -ServerAddresses 10.10.20.5
ipconfig /flushdns
```

Verify:

```powershell
Get-DnsClientServerAddress -InterfaceAlias "Ethernet"
nslookup example.test
nslookup example.test 10.10.20.5
```

Restore automatic DNS:

```powershell
Set-DnsClientServerAddress -InterfaceAlias "Ethernet" -ResetServerAddresses
ipconfig /flushdns
```

## Browser DNS Bypass

Browsers and operating systems may bypass lab DNS.

Check these settings:

- Firefox DNS-over-HTTPS.
- Chrome/Edge Secure DNS.
- Android Private DNS.
- iCloud Private Relay.
- Browser proxy settings.
- VPN clients.

For Firefox, either disable DNS-over-HTTPS or set it to use the operating system resolver.

## Phone on Wi-Fi

Phones do not inherit DNS from `--manage-dns` on your laptop. Configure the phone Wi-Fi DNS manually to the simulator IP.

iPhone:

```text
Wi-Fi -> info icon -> Configure DNS -> Manual -> add simulator IP -> remove other DNS servers
```

Android:

```text
Wi-Fi network settings -> IP settings Static -> DNS 1 = simulator IP
Private DNS -> Off
```

Test:

```text
http://example.test/
```

Use `http://` explicitly to avoid search or HTTPS upgrade behavior.
