# Download and execution validation

When a sample downloads a supported file, HTTP, HTTPS, the explicit proxy and
Tor's HTTP emulator serve a locally generated replacement. Executable and script
replacements do no work and exit successfully. The simulator never executes a
download on the server and does not fetch the original file from the internet
in the isolated lab profile.

## Supported replacements

| Selection | Returned content | Execution behavior |
| --- | --- | --- |
| `.exe`, `.scr`, `windows_executable` | Native Windows x86 PE | Calls `ExitProcess(0)` |
| `.dll`, `windows_dll` | Native Windows x86 DLL | Loads successfully; `Run`, `DllRegisterServer`, `DllUnregisterServer` are harmless exports |
| `windows_executable_x64`, `windows_dll_x64` | Corresponding Windows x64 PE | Same behavior, for a 64-bit process |
| `.elf`, `linux_executable` | Static Linux x86-64 ELF | Calls the exit syscall with status 0 |
| `.sh`, `.py`, `.ps1`, `.bat`, `.cmd` | Script for the requested interpreter | Exits with status 0 |
| `.js`, `.vbs` | JavaScript / VBScript | Exits successfully under the appropriate runtime; JS also works in Node |
| `shellcode_x86`, `shellcode_x64` | Raw `xor eax,eax; ret` bytes | Returns zero to a compatible caller; explicit configuration only |
| ZIP, PDF, Office, MSI | Existing synthetic document/container templates | Download/content checks only; Office/MSI are not executable installers |

No compiler or Wine is required to run the simulator. Packaged binaries are
built from [the small C/assembly sources](../tools/download-stubs/). DLL entry
points use the [Windows DLL entry-point interface](https://learn.microsoft.com/en-us/windows/win32/dlls/dynamic-link-library-entry-point-function).
The source and binary SHA-256 values are in
`src/inetsim_py/data/downloads/manifest.json`. Maintainers with GCC and the
x86/x64 MinGW compilers can rebuild or compare them:

```bash
python3 scripts/build-download-stubs.py
python3 scripts/build-download-stubs.py --check
```

Byte-for-byte comparison requires the same compiler/linker toolchain. Requested
filenames are never inserted into script code. EXE/DLL names only appear in a
non-executable trailing note. Replacements create no files, registry entries,
network connections or child processes.

Optional Windows execution regressions use a disposable Wine prefix and MinGW
DLL verification helpers:

```bash
INETSIM_RUN_WINDOWS_DOWNLOAD_INTEGRATION=1 python3 -m pytest tests/test_downloads_wine.py -q
```

## Extensionless URLs and architecture selection

Add exact paths to your existing configuration. Matching ignores the query
string and decodes URL escapes. Existing text `services.http.routes` take
precedence, followed by the enabled login-page path, download paths, extension
matching, and the default response. Merge examples into the existing TOML table
rather than defining that table twice.

```toml
[services.http.fake_download_routes]
"/get-stage" = "windows_executable_x64"
"/get-module" = "windows_dll_x64"
"/bootstrap" = "shell_script"
"/script" = "powershell_script"
```

Explicit script kinds are `shell_script`, `python_script`, `powershell_script`,
`batch_script`, `javascript`, and `vbscript`. These work even when the URL has
no extension. Generic `script` chooses by extension and falls back to a JS
comment for ambiguous names. `fake_downloads_enabled = false` disables both
download path and extension matching in built-in web services; proxy download
synthesis is controlled by `services.mitmproxy.synthesize_downloads`.

Choose Windows architecture explicitly using the extension map or path map.
There is no reliable inference from an arbitrary filename or HTTP user-agent.
A DLL must match the loading process architecture. No arbitrary DLL exports,
managed .NET methods, signed binaries, or installer actions are emulated.

Raw return stubs are **not** enabled for `.bin` or arbitrary URLs by default.
Select one only when the expected architecture and no-argument calling
convention are known. These bytes do not emulate arbitrary injected code,
decryptors, custom stages or network protocols. Hash/signature checks,
encryption, pinning and application-specific expectations may stop a sample
before or after a successful download.

## Verify a client download and execution

Run the validator inside the isolated client VM, with the project installed,
DNS pointing to the simulator and the lab CA trusted:

```bash
python3 scripts/validate-downloads.py https://example.test --execute --json download-results.json
```

Use `--ca /path/to/inetsim-ca.crt` if the CA is not in the client's OS trust
store. Without `--execute`, only transfers and exact contents are checked.
Each downloaded file is compared with the known local harmless template before
execution. Mismatched content is refused. Execution runs in a child process
with a timeout. Temporary downloaded files are removed after the check.

The validator reports execution skips separately when a runtime or matching
architecture is missing. On Windows, use 32-bit Python for x86 DLL checks and
64-bit Python for x64 DLL checks. On Linux, `--wine` additionally runs EXEs in
an installed Wine; it does not validate DLL loading. The prepared Tiny11 native
client results are in [Windows client through REMnux](windows-client-lab.md).
Other Windows releases still need their own validation. For a verified harmless
PowerShell template, the validator passes `-ExecutionPolicy Bypass` to its child
process; it does not change the machine's persistent execution policy. Missing
runtimes remain execution skips.

In an offline Linux VM, initialise a dedicated Wine prefix before using
`--wine`. Disable its optional Mono/HTML/menu components so setup does not wait
for unavailable downloads. Keep these variables set for the validator:

```bash
export WINEPREFIX="$HOME/.wine-inetsim-noop"
export WINEDLLOVERRIDES="mscoree,mshtml,winemenubuilder.exe="
wineboot -u
```

On a headless VM, run Wine initialization and the validator under `xvfb-run -a`.

For the additional `--extended` checks, add these exact test routes:

```toml
[services.http.fake_download_routes]
"/validation/windows-x64.exe" = "windows_executable_x64"
"/validation/windows-x64.dll" = "windows_dll_x64"
"/validation/stage" = "python_script"
"/validation/return" = "shellcode_x64"
```

```bash
python3 scripts/validate-downloads.py https://example.test --execute --wine --extended --json download-results.json
```

On Linux x86-64, the extended execution check calls the fixed three-byte
return stub in an isolated child process. Executable-memory restrictions may
prevent this check. The server still only serves bytes.

HTTP/HTTPS/Tor download events contain `download_name`, `response_kind`, and
`response_sha256`; proxy synthesis also records the hash and response artifact.
Match that hash with the client report. Server events prove what was served;
the validator's exit code records its own client execution. To establish that
an actual sample executed the replacement, observe that sample's process/module
activity on the client. The simulator cannot infer execution from a GET request.

For the same download/execution check through an onion SOCKS connection, use
the [Tor validator](tor-setup.md#repeat-the-focused-checks). See
[validation](validation.md) for profile requirements and recorded test results.
