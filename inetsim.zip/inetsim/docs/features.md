# Features

`inetsim-py` implements the service-simulation workflow in Python 3 with an
asyncio core. It was built to address DNS instability experienced with Perl
INetSim in the original lab. The recorded 120,000-query workload had zero
failures; this is not a controlled stability comparison with the Perl tool.
See [tested operating systems and results](testing-results.md).

## DNS

- UDP and TCP DNS listeners.
- Reuses TCP connections for sequential or pipelined queries, bounded by `global.max_command_count`.
- Wildcard A answers preserve the requested name, including nonexistent domains; AAAA requires an IPv6 sinkhole or matching static record.
- Optional separate IPv4 and IPv6 wildcard sinkhole addresses.
- Configured static records.
- Optional MX, TXT, CNAME, NS, and SRV records.
- DNS-over-HTTPS responses on `/dns-query` through HTTP/HTTPS listeners.
- NOERROR/NODATA behavior for known names where no matching record type exists.
- Useful for redirecting malware C2 domains to local HTTP/HTTPS services.

## Faketime and Session Reports

- Optional `global.fake_time_utc` freezes simulator time at a configured ISO-8601 UTC timestamp.
- Fake time is used by JSONL event timestamps, HTTP `Date` headers, NTP responses, and shutdown session reports.
- On shutdown, a `logs/session-*.json` report summarizes running services, event counts, listen scope, artifact directory, and fake-time configuration.
- Session report filenames use real wall-clock time plus a random suffix, so fake-time sessions do not overwrite earlier reports.

## NTP

- Optional UDP NTP responder.
- Returns local/fake time as a stratum-configured server.
- Logs client version/mode, packet hashes, and requester metadata.

## HTTP and HTTPS

- nginx-style server header by default.
- Generic enterprise sign-in landing page.
- Configurable brand/title/realm text.
- Modern, self-contained simulated admin/sign-in presentation with no external assets or obvious INetSim branding in the generated HTML. TOML and the CLI manage the simulator; the page is not a management dashboard.
- Customizable headers and page text reduce simple response-string fingerprints; they do not prevent every simulation check. See [web responses](web-responses.md), including the WannaCry kill-switch example.
- Harmless fake downloads for configured extensions:
  - `.exe`
  - `.dll`
  - `.scr`
  - `.zip`
  - `.pdf`
  - Office-style containers
  - `.msi`
  - scripts
  - text files
- Absolute URL handling, so `GET http://evil.test/evil.exe` is normalized and served locally.
- Runnable harmless Windows x86/x64 EXE/DLL, static Linux x86-64 ELF, and interpreter-specific scripts. Exact download routes support extensionless stages. See [download workflow](download-workflow.md) for execution checks and format limits.
- Download response SHA-256 hashes for matching server events to client execution reports.
- Bounded request body capture.
- HTTP/1.1 keep-alive with one log event per request.
- HTTPS listener shares the same response profile as HTTP.
- HTTPS logs SNI, TLS version, cipher, host, path, and response type.
- HTTPS can generate per-SNI certificates from a local lab CA for arbitrary sinkholed hostnames when the client trusts that CA.
- Put known validation-sensitive hostnames in `services.https.prewarm_hosts` when the first TLS connection must pass hostname verification.
- Set `services.https.block_on_unknown_sni = true` when strict clients must validate arbitrary first-seen hostnames; this briefly blocks certificate generation inside the TLS SNI callback instead of falling back to the default certificate.
- Optional `global.tls_crl_url` publishes the built-in CA's signed revocation list over HTTP. Generated built-in TLS leaves advertise its distribution point; explicit revocations persist through automatic renewal. Native Windows curl passed normal revocation checks in the prepared lab. The mitmproxy CA is separate; see [certificates](certificates.md).

## SMTP

- Postfix-style banner.
- Handles common commands: `EHLO`, `HELO`, `MAIL FROM`, `RCPT TO`, `DATA`, `AUTH`, `RSET`, `QUIT`.
- Captures submitted messages as bounded `.eml` artifacts.
- Redacts authentication material.
- `STARTTLS` upgrades to TLS with the generated lab CA.
- Optional implicit TLS listener can be enabled with `implicit_tls_port`.

## POP3

- Dovecot-style banner.
- Single placeholder maildrop.
- Handles common mailbox commands: `CAPA`, `USER`, `PASS`, `APOP`, `STAT`, `LIST`, `UIDL`, `RETR`, `TOP`, `DELE`, `NOOP`, `RSET`, `QUIT`.
- Redacts password/authentication material.
- `STLS` upgrades to TLS with the generated lab CA.
- Optional implicit TLS listener can be enabled with `implicit_tls_port`.

## FTP

- vsFTPd-style control-channel banner.
- Handles common control commands.
- Redacts `PASS`.
- Supports minimal PASV/EPSV data channels for `LIST`, `NLST`, `RETR`, and `STOR`.
- Configurable virtual file map for more INetSim-like file-server behavior.
- Uploaded files are captured as artifacts and become available in the session virtual filesystem.
- Optional artifact-backed upload index can reload captured FTP uploads into the virtual filesystem after restart.
- Completed FTP uploads are available immediately during the current session and, when persistence is enabled, after restart.
- Supports common file metadata/navigation commands including `CWD`, `CDUP`, `MKD`, `RMD`, `DELE`, `SIZE`, and `MDTM`.
- `AUTH TLS` upgrades to TLS with the generated lab CA; `PBSZ` and `PROT P` enable encrypted passive data channels for uploads, downloads, and listings. `PROT C` selects clear data channels.
- Upload capture reads fragmented transfers through EOF, bounded by the body limit and transfer timeout. Passive data connections must originate from the control client's address.
- Optional implicit TLS listener can be enabled with `implicit_tls_port`.
- `pasv_advertise_ip` can force the IPv4 address returned in PASV replies for routed labs.

## TFTP

- Optional UDP TFTP listener.
- Supports RRQ downloads from a configurable virtual file map.
- Supports WRQ uploads when enabled and stores received files as artifacts.
- Provides generated placeholder content for unknown requested files.

## SMB

- Direct-hosted SMB listener on TCP/445-style port.
- Optional NetBIOS session-service listener on TCP/139-style port.
- Logs SMB1/SMB2 negotiation attempts and dialect metadata.
- Keeps SMB2 sessions open across common follow-up commands and returns small controlled responses for session setup, tree connect, create, read, write, close, query, echo, and logoff probes.
- No signing, encryption, durable handles, or real share-backed file serving.

## mitmproxy

Optional explicit proxy mode using `mitmdump`.

- Enforces `global.allowed_clients`.
- Logs HTTP/HTTPS request and response metadata.
- Captures request/response bodies up to configured limits.
- Can synthesize fake downloads using the same HTTP payload templates.
- Synthesizes configured route/default responses for blocked upstream requests.
- Blocks upstream by default.
- Allows selected upstream hosts by exact name or wildcard.

Clients must be configured to use the proxy and must trust the mitmproxy CA for HTTPS inspection.

## QUIC

- Optional UDP sink on port 443.
- Logs QUIC-like datagrams, payload hashes, and long-header version/connection-ID metadata.
- Can block with a QUIC Version Negotiation response for long-header packets or a small stateless reset-style response for other UDP payloads, or observe without replying.
- Transparent proxy mode redirects UDP/443 into this sink when the service is enabled, so QUIC attempts are logged by INetSim instead of being rejected only by the kernel.

## Tor Emulation

Two optional Tor-like services are available.

`tor_socks`:

- SOCKS5 and SOCKS4a listener.
- Accepts `CONNECT <host>.onion:<port>`.
- Accepts SOCKS5 no-auth and username/password auth; credential values are logged only as length/hash metadata.
- Logs target host, port, onion status, onion name/version metadata, HTTP metadata, or initial binary payload hashes.
- Serves normal fake HTTP responses when the client speaks HTTP over the SOCKS stream.
- Terminates HTTPS on target port 443 with the generated lab CA, including full SAN identities for long onion subdomains.
- Handles early plaintext HTTP already buffered after CONNECT, then checks a short socket sniff window; otherwise port 443 is handled as TLS.
- Records the onion service ID and optional subdomain separately, plus download response hashes and bounded POST artifacts.
- Rejects unsupported SOCKS commands and closes unsupported binary streams. Stream errors after CONNECT success do not insert a second SOCKS reply.

`tor_control`:

- Tor control-port emulator.
- Handles `PROTOCOLINFO`, `AUTHENTICATE`, `GETINFO`, `ADD_ONION`, `DEL_ONION`, `SIGNAL`, `SETEVENTS`, `TAKEOWNERSHIP`, `SETCONF`, `RESETCONF`, and `QUIT`.
- Provides plausible `GETINFO` responses for listener, bootstrap, and hidden-service onion keys.
- Redacts sensitive authentication/proxy/private-key values.

These services do not create real Tor circuits. Samples must use the emulator's
SOCKS endpoint; DNS changes do not redirect localhost sockets or bootstrap a
bundled Tor daemon. See [Tor setup](tor-setup.md) for configuration, repeatable
checks and limits, including pre-buffered TLS and control-event behavior.

## TCP Banners

- Configurable banner listeners for common ports.
- Lab config includes SSH, MSSQL, and MySQL style banners.
- If port `22` is in use, the SSH-like banner falls back to `2222`.

## Dummy Service

- Configurable TCP and UDP dummy listeners for unknown or redirected traffic.
- Logs client bytes and hashes.
- Can return static protocol-like responses for small legacy services such as echo, daytime, quote, ident, and syslog collection ports.

## Current Limits

- No DHCP service.
- Transparent proxy automation covers local OUTPUT and router PREROUTING redirects with optional interface/source scoping, but it is not full gateway/firewall/DHCP automation.
- SMB negotiation is improved but no real share contents are exposed.
- TFTP is intentionally minimal and does not implement option negotiation or full retransmission behavior.
- Dummy listeners are static responders, not full protocol implementations.
- TLS interception depends on client trust and may fail for pinned clients.
- Office/MSI replacements are download-only containers; runnable replacements and raw return stubs do not reproduce arbitrary next-stage behavior.

See [testing results](testing-results.md) for OS coverage and observed results,
and [validation](validation.md) for commands and profile requirements.
