# Lab Setup

This guide assumes an isolated host-only or internal VM network.

## Offline VirtualBox Validation on REMnux

The Ubuntu 24.04 REMnux VirtualBox appliance is a suitable target for the
Python 3.11+ core. The core has no third-party runtime Python dependencies;
certificate generation also requires the `openssl` executable. The optional
mitmproxy integration needs a separate installation and validation.

Before importing, verify the appliance SHA-256 against the hash for that exact
download on the [REMnux appliance page](https://docs.remnux.org/install-distro/get-virtual-appliance).
Importing the OVA defaults to NAT: change the network settings before its first boot.

1. Create a VirtualBox host-only network, for example `vboxnet0` with host address
   `192.168.56.1/24`. Disable its DHCP server for this static-address example.
2. Give REMnux and the client VM exactly one adapter, attached to that same
   host-only network. Disable every additional adapter. Do not use NAT or bridging.
3. Configure REMnux as `192.168.56.5/24` and the client as `192.168.56.10/24`.
   Leave the default gateway empty on both VMs and set the client's DNS server
   to `192.168.56.5`. In guest IPv6 settings, disable IPv6 for this IPv4 test.
4. Confirm the guests have no default route (`ip route` on Linux, `route print`
   on Windows). Ensure the host does not forward or share internet access onto
   this network. Host-only allows access to the host itself; VirtualBox's
   internal-network mode is the option for VM-to-VM access without host access.
5. Take clean snapshots before testing. Use benign probes for initial validation.

On Linux clients using systemd-resolved, explicitly route lab queries to the
simulator. The default mail and FTP identities end in `.local`, which otherwise
uses multicast DNS. In the client VM, replace `enp0s3` with its lab interface:

```bash
sudo resolvectl dns enp0s3 192.168.56.5
sudo resolvectl domain enp0s3 '~.' '~local'
```

For a persistent networkd/netplan setup, put `search: ["~.", "~local"]` beside
the DNS `addresses` entry under `nameservers` in the guest's netplan profile.

Keep the VM clocks synchronized before testing TLS. An isolated guest can
briefly lag after boot or snapshot restore and reject a newly generated leaf
certificate as "not yet valid". VirtualBox Guest Additions can synchronize to
the host without internet access. Run these on the host for each test VM:

```bash
VBoxManage guestproperty set "VM name" /VirtualBox/GuestAdd/VBoxService/--timesync-set-start 1
VBoxManage guestproperty set "VM name" /VirtualBox/GuestAdd/VBoxService/--timesync-interval 1000
VBoxManage guestproperty set "VM name" /VirtualBox/GuestAdd/VBoxService/--timesync-set-threshold 1000
```

Restart the guest or its `vboxadd-service` after changing these settings, and
compare UTC times in both guests before making fresh TLS connections.

An offline bundle can be transferred using an ISO attached as a virtual optical
disc, or a temporary read-only shared folder. Copy it to the guest's home directory
and detach the transfer medium before taking the test snapshot. No internet
adapter is required for the core installation. Never distribute an existing
`artifacts/` or `logs/` directory: generate a fresh CA inside the test lab.

The prepared `inetsim-vm-validation.tar.gz` bundle contains source, tests, a core
wheel, and `configs/vm-validation.toml`. That profile uses `192.168.56.0/24`,
prewarms `example.test`, and sets `block_on_unknown_sni = true` so a new hostname
can validate on its first TLS handshake. Blocking certificate generation briefly
pauses the event loop; the standard lab profile leaves that behavior disabled.

On REMnux, extract the bundle and install the wheel without contacting an index:

```bash
tar -xzf inetsim-vm-validation.tar.gz
cd inetsim-vm-validation
python3 --version
openssl version
python3 -m venv .venv
.venv/bin/python -m pip install --no-index --no-deps wheelhouse/inetsim_py-*.whl
.venv/bin/inetsim-py --config configs/vm-validation.toml check-config
ip -4 addr
```

The bundle also includes pytest and its dependency wheels. To run the source
test suite offline in REMnux:

```bash
.venv/bin/python -m pip install --no-index --find-links wheelhouse pytest==9.0.2
.venv/bin/python -m pytest -q
```

If `venv` is unavailable, the bundled source also runs directly with
`python3 inetsim.py`. No pip installation is needed for that route. Do not use
`requirements.txt` for an offline core installation; it requests mitmproxy.

Use the actual guest interface name in place of `enp0s3`:

```bash
sudo .venv/bin/inetsim-py --interface enp0s3 --config configs/vm-validation.toml run
```

Run from the extracted directory so relative log and artifact paths stay there.
If startup reports occupied ports, inspect `sudo ss -lntup` and stop conflicting
services inside this disposable VM. REMnux may already contain the original
INetSim or other network tools; do not run both simulators on the same addresses
and ports. Bind to the host-only address with `--interface` as above.

While the simulator runs, copy only `artifacts/tls/inetsim-ca.crt` and
`scripts/validate-lab.py` to the client VM. Keep all `.key` files on REMnux.
From a Linux client, validate before changing the OS trust store:

```bash
python3 validate-lab.py 192.168.56.5 --ca inetsim-ca.crt
```

This checks UDP/TCP DNS answers, HTTP, harmless executable downloads, HTTPS with
CA and hostname verification, and request-body submission. It connects to the
provided IP while preserving the HTTP Host header and TLS SNI, so separately
check the client's normal resolver and browsing path:

```bash
getent ahostsv4 example.test
curl --noproxy '*' --cacert inetsim-ca.crt https://example.test/
```

For OS trust validation, copy `scripts/install-ca-linux.sh` to the Linux client:

```bash
sudo bash install-ca-linux.sh install inetsim-ca.crt inetsim-vm-validation
python3 validate-lab.py 192.168.56.5 --ca inetsim-ca.crt --system-trust
curl --noproxy '*' https://example.test/
sudo bash install-ca-linux.sh remove inetsim-vm-validation
```

On Windows, use the PowerShell helper described in [Certificate Setup](certificates.md)
and test `curl.exe --noproxy "*" https://example.test/` without `-k`.
Browsers may need their own CA import and DNS-over-HTTPS disabled for the test.
Install the CA in test guests, leaving the physical host's trust store unchanged.

On REMnux, verify the requests in `logs/dns.jsonl`, `logs/http.jsonl`, and
`logs/https.jsonl`. The POST to `/validation-upload` should reference a saved
artifact containing `inetsim-vm-validation` followed by a newline. Stop with
Ctrl-C, inspect the session report under `logs/`, and confirm the listeners close.
For a first-seen TLS test, rerun the validator with a new name, for example
`--host fresh-validation.test`.

Passing these probes validates the core DNS/web/certificate path. Before release,
also run the full pytest suite in the guest, exercise the other enabled protocols, test an out-of-subnet
client against the ACL, and validate mitmproxy separately if shipping it.

## Protocol, Download and Tor Validation

The prepared bundle also contains `configs/vm-validation-full.toml` and
`configs/vm-expanded-validation.toml`. The full profile enables the proxy on
8080 and test download routes. The expanded profile additionally enables
implicit mail/FTP TLS, larger FTP/TFTP files and a DNS record matrix. These
generated VM profiles are supplied in the offline bundle; the repository's
standard profile remains `configs/lab-subnet.toml`.

Follow [validation](validation.md) for exact profile requirements, commands and
recorded results. Run one server profile at a time and wait for its listeners
before probing. In the prepared server VM, the enabled systemd unit is
`inetsim-validation`; do not start a second manual instance against the same
ports.

Client workflows have different configuration needs:

- [DNS setup](dns-setup.md): use the simulator as DNS to receive wildcard answers
  for invented domains.
- [Download workflow](download-workflow.md): run known harmless replacements on
  the client with explicit execution checks; server GET logs only prove downloads.
- [Tor setup](tor-setup.md): use `192.168.56.5:9050` as the sample's SOCKS endpoint.
  DNS does not redirect a hard-coded localhost proxy or bootstrap a real Tor daemon.

The prepared VMs have matched `validated-lab` snapshots. Restore them together
to preserve server CA/client trust, and retain the server's `clean-import`
snapshot because the client is a linked clone. General deployments should take
their own matched checkpoints. For Guest Control failures after boot, see
[troubleshooting](troubleshooting.md#virtualbox-guest-control-is-not-ready).

## Example REMnux and FLARE-VM Layout

```text
REMnux    10.10.20.5   runs inetsim-py
FLARE-VM  10.10.20.10  malware analysis client
Network   10.10.20.0/24 host-only or internal
```

On REMnux, identify the host-only interface:

```bash
ip -4 addr
```

Run the simulator:

```bash
sudo python3 inetsim.py --interface <host-only-interface> --config configs/lab-subnet.toml run
```

The `--interface` option detects the interface IP and CIDR and overrides the lab config for that run.

The lab profile also enables legacy compatibility listeners such as NTP, TFTP, and dummy TCP/UDP responders for common small-service ports. Set `global.fake_time_utc` in the config when you want malware time checks to receive a fixed lab time.

## FLARE-VM Network Settings

For basic INetSim-style behavior, FLARE-VM should use REMnux as DNS:

```text
IP address:      10.10.20.10
Subnet mask:     255.255.255.0
DNS server:      10.10.20.5
Default gateway: empty for the isolated same-subnet test
```

For mitmproxy mode, configure FLARE-VM proxy settings:

```text
HTTP proxy:  10.10.20.5
HTTPS proxy: 10.10.20.5
Port:        8080
```

Install `artifacts/tls/inetsim-ca.crt` on FLARE-VM for direct HTTPS sinkholing. Install the mitmproxy CA on FLARE-VM if explicit-proxy HTTPS inspection is required.

## Quick Validation from FLARE-VM

PowerShell:

```powershell
nslookup example.test 10.10.20.5
curl.exe http://example.test/
curl.exe https://example.test/
```

If `nslookup example.test 10.10.20.5` works but normal browsing does not, Windows or the browser is not using REMnux as DNS.
The HTTPS check requires the public lab CA installed in the client as described
above. Using `-k` bypasses that verification and is only a diagnostic check.

## Quick Validation from REMnux

```bash
python3 inetsim.py --interface <host-only-interface> --config configs/lab-subnet.toml doctor
dig @<remnux-ip> example.test
curl -v --resolve example.test:80:<remnux-ip> http://example.test/
curl -vk --resolve example.test:443:<remnux-ip> https://example.test/
```

## Optional Local DNS Management

`--manage-dns` changes DNS only on the machine running the simulator. It is useful when the simulator host itself needs to resolve all names to INetSim:

```bash
sudo python3 inetsim.py --interface <iface> --manage-dns --config configs/lab-subnet.toml run
```

It does not configure DNS on FLARE-VM, phones, or other clients.
