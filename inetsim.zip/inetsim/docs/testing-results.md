# Tested operating systems and results

Recorded on **2026-10-18**. These results come from several distinct passes as
features were added. They describe observed configurations, not certification
of every listed OS variant or all malware behavior.

## Environment coverage

| Environment | Role and runtime | Coverage |
| --- | --- | --- |
| Ubuntu 24.04.5 LTS x86-64 host | Python 3.12.3 | Source regression tests; earlier optional Wine/MinGW payload tests |
| REMnux, Ubuntu 24.04 x86-64 | Python 3.12.3; OpenSSL 3.0.13 in the recorded appliance | Linux simulator server; offline wheel install; source suite; mitmproxy integration in earlier enabled passes |
| Separate REMnux, Ubuntu 24.04 VM | Python 3.12.3, curl and torsocks | Independent DNS, protocol, download/execution and SOCKS/onion client |
| Windows 11 Pro, Tiny11 B1 build 22621.525 x64 | Python 3.12.10 x64/x86, PowerShell 5.1, curl 7.83.1 with Schannel | Native Windows client using Linux as DNS/gateway; OS CA trust; x86/x64 harmless payload execution |
| Disposable clone of that Windows VM | Unchanged supplied PMAT WannaCry bytes | One bounded observation of kill-switch contact and process exit |

Windows was the **client**, not the INetSim server. No native Windows-server,
macOS-server, Windows 10 or Windows Server validation is recorded. Earlier Wine
checks ran on Linux and are not counted as native Windows validation.

## Latest regression suites

| Environment | Result | Evidence filename |
| --- | --- | --- |
| Ubuntu host | 216 passed, 9 skipped | `compatibility-fixes/host-pytest.txt` |
| Deployed REMnux server | 215 passed, 10 skipped | `compatibility-fixes/remnux-pytest-final.txt` |

Optional integrations and available runtimes affect skips. Live mitmproxy,
Wine/MinGW and platform/runtime-dependent executions have separate prerequisites.
Earlier passes had smaller suites: the Tor-era REMnux suite passed 207 tests
with 9 skips while live mitmproxy was enabled; an earlier host payload pass
reported 211 passed and 1 skipped with Wine integration enabled. These numbers
are retained as historical results, not added to the latest totals.

## Linux cross-VM results

| Check | Observed result |
| --- | --- |
| DNS load | 100,000 unique-name UDP queries + 20,000 TCP queries at concurrency 32; zero failures |
| DNS behavior | Invented names, OS resolver path, EDNS, malformed-input recovery, sequential/pipelined TCP reuse, configured records and DoH checked |
| Expanded protocol matrix | 31 groups passed, including implicit mail/FTP TLS, protected FTP data, fragmented uploads, multi-block TFTP, SOCKS and controlled SMB exchanges |
| Download workflow | 15 exact transfer matches over each of HTTP and HTTPS; cross-platform client validator reported 9 execution passes and 6 skips in the recorded execution run |
| Windows formats under Wine | x86/x64 DLL exports/loading and JS/VBS/CMD/BAT execution checked separately |
| Onion application workflow | 23 checks passed; 1,000 sessions at concurrency 16, including 250 TLS sessions; zero failures; curl and torsocks exercised |
| Evidence | Download hashes, bounded POST content, authentication redaction, matching CA trust and post-reboot onion HTTPS execution checked |

The DNS workload validates this Python implementation under the recorded load.
There is no matched workload benchmark against Perl INetSim and no long-duration
soak-test result. The rewrite's motivation includes addressing the DNS instability
experienced in the original lab.

## Native Windows results

The simulator remained on REMnux at `192.168.56.5`. Windows at `192.168.56.20`
used REMnux as DNS and default gateway. Each VM had one internal-network NIC,
with no external uplink. See the [Windows lab guide](windows-client-lab.md).

| Check | Observed result |
| --- | --- |
| Core path | 8 DNS/web/certificate checks passed; untrusted CA rejected before trust installation |
| Protocol matrix | 17 groups passed, including trusted STARTTLS/STLS, FTP, controlled SMB, NTP/TFTP, QUIC sink, SOCKS, DoH and explicit proxy |
| Routing/native TLS | 12 checks passed, including interception of hard-coded DNS/web destinations, Schannel curl, WinHTTP, and blocked unsupported traffic |
| Downloads across three runs | 45 exact matches: x64 Python over HTTP/HTTPS and x86 Python over HTTPS |
| Execution across those runs | 33 passes, including x86/x64 EXE/DLL, SCR, JS/VBS/PowerShell/CMD/BAT and Python; 12 architecture/platform execution skips |
| Onion application workflow | 22 checks passed; 400 sessions at concurrency 16, including 100 TLS; zero failures |
| Server correlation | Download and POST hashes matched client bytes; focused onion events and hard-coded/blocked destinations appeared in logs/capture |
| Reboot | Simulator, routing and packet capture started; client trust, fresh SNI, routing and containment checks passed |

The first native pass used the explicit curl offline-revocation option because
the original lab certificates lacked usable revocation data. A later signed-CRL
update removed that requirement for the built-in CA:

- Default Schannel curl and certutil accepted a valid leaf with the signed CRL.
- A matching SHA-256 public-key pin succeeded; a different pin failed with curl
  exit 90.
- Both tools detected the deliberately revoked leaf from fresh Windows state,
  and on the original client after documented cache refresh and reboot.
- All four valid-leaf/pin and both revoked-leaf checks passed after reboot.
- All 12 routing checks passed after reboot without revocation bypass flags.
- The 17 protocol groups and 22 focused SOCKS checks also passed after the CRL
  update; the 400-session workload had zero failures.

Windows can retain older chain/CRL cache results. `certutil` can report a revoked
leaf while returning process exit code zero, so the validator checks its text.
See [certificates](certificates.md) and [compatibility results](compatibility-results.md).

## Supplied WannaCry sample

Sample SHA-256:

```text
24d004a104d4d54034dbcffc2a4b19a11f39008a575aa614ea04703480b1022c
```

The exact sample bytes ran once in a separate disposable Windows clone. One DNS
query and one HTTP GET to its kill-switch domain were logged. INetSim returned
HTTP 200 with a 3,940-byte page. The process exited with code 0 after 0.625
seconds, consistent with its own kill-switch branch. The observation launcher
did not terminate the process.

The execution-window PCAP contains 11 packets / 5,172 bytes. The wider capture
contains 169 packets / 25,783 bytes, including surrounding traffic. No HTTPS,
SOCKS, Tor-control or SMB service events appeared during the approximately
14-second observation. The sentinel file's hash was unchanged. These limited
observations do not establish an absence of all filesystem or process activity.

Static inspection identified a bundled Tor executable with version strings
`0.2.9.10`; the dynamic observation did not reach that stage. No sample code or
kill-switch behavior was patched. The sample-run clone was discarded and
recreated clean after evidence export. Full details are in
[compatibility results](compatibility-results.md).

## Evidence and repeatability

The original reports remain outside the source tree under the local validation
bundle. These relative names identify the recorded evidence:

| Evidence set | Contents |
| --- | --- |
| `dns-stability-load.json` and `VM-VALIDATION.txt` | DNS workload and Linux protocol results |
| `DOWNLOAD-WORKFLOW-VALIDATION.txt` and `TOR-VALIDATION.txt` | Earlier Linux/Wine download and onion passes |
| `windows-native/` | Native OS details, protocol/download/execution JSON and initial capture |
| `compatibility-fixes/` | Final CRL/pin/routing reports, source update, WannaCry metadata and PCAPs |

The original local bundle is at
`/home/shadocat/Downloads/VM/inetsim-validation/`. Raw captures, credentials, CA
private keys and malware are not required to use the repository documentation.

Follow [validation](validation.md) for repeatable commands and profile settings.
Use [Tor setup](tor-setup.md) for application-facing SOCKS tests. Public Tor
bootstrap, original onion-service identity, arbitrary pinned clients, native
Windows SMB mounts and all malware stages remain outside these results.
