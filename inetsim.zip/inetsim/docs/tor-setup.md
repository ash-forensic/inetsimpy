# Testing onion-service contact in the isolated lab

The simulator emulates the application-facing SOCKS and Tor control interfaces.
It serves local responses for requested `.onion` targets without publishing or
contacting a real onion service. Keep the VM network isolated.

## Point the sample at the emulator

The prepared REMnux server uses:

```toml
[services.tor_socks]
enabled = true
port = 9050

[services.tor_control]
enabled = true
port = 9051
```

Configure the sample's SOCKS endpoint as `192.168.56.5:9050` and request
hostnames through SOCKS5 or SOCKS4a. Use remote-name resolution, such as curl's
`--socks5-hostname` / `socks5h`, so the original onion name reaches the emulator.
An ordinary DNS A answer is not proof that a Tor workflow works.

The client must trust the server's public lab CA for HTTPS validation. For an
independent curl check, use this valid-format test v3 name:

```bash
onion=25njqamcweflpvkl73j4szahhihoc4xt3ktcgjnpaingr5yhkenl5sid.onion
curl --noproxy '' --socks5-hostname 192.168.56.5:9050 "http://$onion/stage.elf" -o stage.elf
curl --noproxy '' --socks5-hostname 192.168.56.5:9050 "https://$onion/stage.elf" -o stage.elf
```

The test address is constructed from an RFC 8032 public test key using the
[Tor v3 address encoding](https://spec.torproject.org/rend-spec/encoding-onion-addresses.html).
No corresponding service or external connectivity is required.

If a sample is hard-coded to `127.0.0.1:9050` or Tor Browser's usual local SOCKS
port, changing its DNS server does not redirect that loopback socket. Configure
the endpoint or arrange a deliberate local TCP forward to the lab server. A
SOCKS endpoint must not be entered as an HTTP proxy.

## Repeat the focused checks

Run from the installed project directory inside the client VM with curl and
Python available. Install the project in the client venv for `--execute`, which
uses its known harmless binary to verify the downloaded bytes:

```bash
.venv/bin/python scripts/validate-tor.py 192.168.56.5 --queries 1000 --concurrency 16 --json tor-results.json
```

Use `--ca /path/to/inetsim-ca.crt` if the CA is not in the OS trust store.
Add `--execute` to verify the downloaded ELF against the installed project's
known harmless template and run it on this Linux x86-64 client. Unexpected
bytes are refused before execution. The extended download route check expects
this entry in the existing download-route table:

```toml
[services.http.fake_download_routes]
"/validation/stage" = "python_script"
```

The prepared VM profiles already contain it. See [validation](validation.md)
for the full profile requirements and dated results. To include client execution:

```bash
.venv/bin/python scripts/validate-tor.py 192.168.56.5 --queries 1000 --concurrency 16 --execute --json tor-results.json
```

Checks cover independent curl SOCKS5/SOCKS4a clients, verified HTTPS, onion
subdomains, username/password negotiation, fragmented handshakes, early HTTP
data, POST capture, HEAD, extensionless downloads, untrusted-CA rejection,
unsupported commands/binary streams, malformed input, control status and
concurrent sessions. Early HTTP data is the
[optimistic SOCKS data extension](https://spec.torproject.org/socks-extensions.html#optimistic-data).

Inspect `logs/tor_socks.jsonl` for `target_host`, `target_port`,
`target_is_onion`, `target_onion_name`, `target_onion_version`, optional
`target_onion_subdomain`, HTTP/TLS fields, download `response_sha256`, and
initial binary hashes. POST bodies are bounded artifacts. The validator's
unique `tor-check-...` token identifies its paths, user-agent and test inputs.
Authentication values are logged as lengths/hashes; control authentication
and private-key input are redacted in `logs/tor_control.jsonl`.

## What this does and does not establish

- A sample that uses the configured SOCKS endpoint for onion HTTP/HTTPS can
  receive local web responses and harmless downloads. Plain HTTP is supported
  on other target ports; TLS termination is currently selected on port 443.
- HTTPS for long onion subdomains retains the full identity in the certificate
  SAN. The certificate CN uses a short fallback when the name exceeds 64 chars.
- Plain HTTP may be sent immediately with CONNECT, including on port 443.
  An optimistically pre-buffered TLS ClientHello is not supported. A plaintext
  request delayed beyond the short port-443 sniff window may be treated as TLS.
- Non-HTTP binary streams are logged and closed. SOCKS BIND, UDP ASSOCIATE and
  Tor RESOLVE/RESOLVE_PTR are not implemented; rejection is a tested limit.
- Onion version metadata is inferred from the service label's length; the
  emulator does not validate onion signatures, checksum, descriptors or keys.
- SOCKS authentication is accepted to observe clients' isolation values; there
  are no circuits to isolate. Control status/bootstrap replies are synthetic.
  ADD_ONION replies do not create a real service or usable private key.
- A sample bundling a real Tor daemon still needs actual Tor circuits. Its
  bootstrap/relay/rendezvous traffic cannot be replaced by this SOCKS emulator.
  Pinned HTTPS, onion client authorization, custom encrypted protocols and
  asynchronous Tor control events are not reproduced.

Server logs prove the target and bytes observed. Client process monitoring is
needed to prove that an actual sample executed a downloaded file. Native
Windows SOCKS/onion checks and the supplied WannaCry observation are recorded
in [compatibility results](compatibility-results.md). Tor Browser and real Tor
bootstrap compatibility still require their own tests.
