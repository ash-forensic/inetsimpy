# Troubleshooting

## A sample exits after receiving a web response

Check the captured domain, response and process result before assuming the
simulator or antivirus terminated it. A sample can deliberately exit after an
environment or reachability check. In the recorded WannaCry run, INetSim
answered the kill-switch URL with HTTP 200 and the sample exited normally after
0.625 seconds. The launcher did not kill it. See
[the recorded explanation and evidence](compatibility-results.md#why-execution-stopped).

The modern web page avoids obvious legacy page branding, but this WannaCry
check depends on successful URL contact rather than matching that branding.
See [web response profiles and fingerprinting](web-responses.md).

## Domain Does Not Resolve

From the client:

```bash
nslookup example.test <simulator-ip>
```

If this works but normal browsing does not, the client is not using the simulator as its active DNS server.

With wildcard mode enabled, invented names should return the lab's A address.
An empty AAAA answer is expected when no IPv6 sinkhole/static record is
configured; it is not a failed IPv4 lookup. Use `.test` for normal OS/browser
checks and query the simulator directly when testing `.invalid`. See [DNS setup](dns-setup.md).

Check:

- Windows adapter DNS.
- Browser DNS-over-HTTPS.
- VPN settings.
- Phone Private DNS or iCloud Private Relay.
- Whether the client is on the same isolated network.

## Direct IP Does Not Load

Try:

```text
http://<simulator-ip>/
```

If direct IP fails:

- Verify the simulator is bound to the lab interface or `0.0.0.0`.
- Check `global.allowed_clients`.
- Check host firewall rules.
- Check VM host-only/internal network mode.
- Check Wi-Fi client isolation for physical devices.

## Browser Goes to Search Instead of Landing Page

Use an explicit URL:

```text
http://example.test/
```

Mobile and desktop browsers may treat bare `example.test` as a search query or force HTTPS for known sites.

## HTTPS Certificate Error

Expected until the client trusts the built-in HTTPS lab CA or the mitmproxy CA being used for interception.

Quick test:

```bash
curl -k https://example.test/
```

This bypasses certificate verification for diagnosis. Repeat without `-k`
after installing the public CA to establish that client trust works.

Proper fix:

- For direct DNS sinkholing to the HTTPS service, install `artifacts/tls/inetsim-ca.crt` into the client trust store.
- For explicit proxy inspection, install `artifacts/mitmproxy/conf/mitmproxy-ca-cert.pem`.
- Ensure the client sends SNI for the requested hostname; clients without SNI receive the default certificate.
- For Firefox, enable Windows root trust or import the CA into Firefox.
- Compare UTC clocks in both guests after boot/snapshot restore if a new leaf
  certificate is reported as not yet valid. See [lab clock setup](lab-setup.md#offline-virtualbox-validation-on-remnux).

If both built-in HTTPS and mitmproxy are tested, install their public CAs under
distinct helper names so one does not overwrite the other. A CA bundle passed
to `validate-protocols.py --ca` must contain both public certificates.
See [certificate setup](certificates.md#linux-client-helper).

## Downloaded File Does Not Execute

Check the selected template and client runtime in
[download workflow](download-workflow.md). Windows DLLs must match the loading
process architecture; the default EXE/DLL templates are x86. Use explicit x64
kinds where needed. Office/MSI containers are download-only templates, while
generic scripts with ambiguous extensions need an explicit script kind.

For an extensionless URL, add its exact path to
`services.http.fake_download_routes`. Existing text routes and the configured
login page take precedence. Path matching ignores query strings. Match
`response_sha256` in server logs with the client validation report. A successful
GET proves a transfer; it does not prove sample execution.

The execution validator refuses unexpected bytes and reports missing runtimes
or incompatible architectures as skips. Inspect `execution`, `exit_code`, and
`skipped` in its JSON report. Wine checks do not establish native Windows
compatibility, and raw return stubs do not emulate arbitrary next-stage logic.

## Onion Service Does Not Respond

Use the configured SOCKS endpoint, not an HTTP proxy. In the prepared lab this
is `192.168.56.5:9050`; the control listener is `:9051`. Request the onion name
remotely with curl's `--socks5-hostname` or SOCKS4a, and check
`logs/tor_socks.jsonl` for `target_host`, `target_port`, TLS errors and response
hashes. HTTPS also requires the built-in lab CA trusted on the client.

DNS changes do not redirect a sample's hard-coded `127.0.0.1:9050`/`:9150`
socket. Configure its proxy endpoint or supply a deliberate local TCP forward.
A bundled real Tor daemon cannot bootstrap real circuits through the emulator.
TLS termination is currently on target port 443; pre-buffered optimistic TLS,
custom binary protocols and asynchronous Tor control events are unsupported.
See [Tor setup](tor-setup.md) for repeatable checks and the full limits.

## VirtualBox Guest Control Is Not Ready

In the REMnux lab, `VBoxManage guestcontrol` sometimes reported that the guest
execution service was not ready after boot although the desktop and network
were running. From a terminal in the affected guest's console, run:

```bash
sudo systemctl restart vboxadd-service
```

Then retry the host's Guest Control command. This repairs the observed Guest
Additions control-channel issue; it does not restart the simulator or install
kernel modules. Check the guest clock before new TLS tests after recovery.

## Google or Other Sites Do Not Show Landing Page

Many high-profile domains use HSTS, HTTPS-only behavior, certificate pinning, or browser preloads.

For captive-page testing, use:

```text
http://example.test/
```

For direct HTTPS sinkholing, trust `artifacts/tls/inetsim-ca.crt`. For explicit proxy inspection, use mitmproxy with its trusted CA and explicit proxy settings.

## DNS Still Broken After Stopping

Run:

```bash
sudo python3 inetsim.py --interface <iface> restore-dns
```

Then check:

```bash
resolvectl status
resolvectl query example.com
```

If needed:

```bash
sudo nmcli device reapply <iface>
```

Restart the browser if it has cached DNS/proxy state.

## Port Already in Use

Check listeners:

```bash
sudo ss -lntup
```

Common conflicts:

- TCP/22: SSH. The lab TCP banner falls back to 2222.
- TCP/80 or TCP/443: local web servers.
- TCP/9050 or TCP/9051: real Tor.
- TCP/445: SMB/Samba.
- UDP/69: TFTP.
- UDP/123: NTP or systemd-timesyncd/chrony/ntpd.
- TCP/UDP small service ports such as 7, 9, 13, 17, 19, 113, and 514 when dummy listeners are enabled.

Disable the conflicting service or change the relevant config port.

## mitmproxy Does Not Start

Install optional dependencies:

```bash
python3 -m pip install -e .[mitm]
```

Check startup logs:

```bash
cat logs/mitmproxy-startup.err.log
```

## What to Collect

When reporting a lab issue, collect:

```bash
python3 inetsim.py --interface <iface> --config configs/lab-subnet.toml check-config
resolvectl status
ss -lntup
tail -n 50 logs/dns.jsonl
tail -n 50 logs/http.jsonl
tail -n 50 logs/tor_socks.jsonl
tail -n 50 logs/tor_control.jsonl
```

Include the relevant validator's JSON report and record which server profile
was running. The commands and expected scope are in [validation](validation.md).

Also include the latest session report when available:

```bash
ls -t logs/session-*.json | head -n 1
cat "$(ls -t logs/session-*.json | head -n 1)"
```
