# Validation

For the consolidated OS matrix and current recorded counts, see
[tested operating systems and results](testing-results.md). The latest recorded
suite passed 216 tests with 9 skips on the Ubuntu host and 215 with 10 skips on
the deployed REMnux server. Native Windows client checks and the later signed-CRL
update are included there. Commands below describe how to repeat the checks;
the historical Linux table near the end describes an earlier pass.

Run service probes from a separate client VM on the isolated lab network. Run
pytest in the installed source checkout. Examples here use the prepared REMnux
server `192.168.56.5` and client `192.168.56.10`; replace addresses for your lab.
The repository's `configs/lab-subnet.toml` uses `10.10.20.0/24` instead.

## Prerequisites and profiles

Follow [lab setup](lab-setup.md) for offline installation, static addresses and
client DNS. Install the public lab CA in the client or pass the relevant
validator's `--ca` option. Never copy the CA private key. The full protocol
validator also checks mitmproxy HTTPS, so its trust store or supplied CA bundle
must include both the built-in CA and the separate mitmproxy CA.

Run commands from the project directory with its installed `.venv`. Core probes
use the standard library; DNS stress checks additionally require dnspython;
Tor checks require curl. With a transferred wheelhouse, install the optional
DNS client without internet access:

```bash
.venv/bin/python -m pip install --no-index --find-links wheelhouse dnspython
```

For a checkout prepared before isolation, the equivalent extra is
`python3 -m pip install -e '.[validation]'`.

| Profile | Availability | Probe requirements |
| --- | --- | --- |
| `configs/lab-subnet.toml` | Repository | Standard service ports; adjust interface/subnet; mitmproxy disabled by default |
| `configs/vm-validation.toml` | Prepared offline bundle | IPv4 core lab and first-seen SNI validation |
| `configs/vm-validation-full.toml` | Prepared offline bundle and server VM | Adds mitmproxy on 8080 and the four download test routes below |
| `configs/vm-expanded-validation.toml` | Prepared offline bundle and server VM | Also enables implicit TLS, large FTP/TFTP test files and the DNS record matrix |

The full protocol validator expects the lab's enabled services, including the
proxy on 8080 and Tor on 9050/9051. Resolve `example.test`, `mx01.corp.local`,
`mail.corp.local` and `ftp.local` through the simulator. On systemd-resolved
clients, route both `~.` and `~local` to its DNS address. Wait for all required
listeners to finish starting; a systemd `active` status alone does not prove
that every listener is ready.

For a custom profile, merge these keys into its existing download-route table
before running extended download checks or the focused Tor validator:

```toml
[services.http.fake_download_routes]
"/validation/windows-x64.exe" = "windows_executable_x64"
"/validation/windows-x64.dll" = "windows_dll_x64"
"/validation/stage" = "python_script"
"/validation/return" = "shellcode_x64"
```

The Tor validator only requires the `/validation/stage` entry from that table.
Do not define the same TOML table twice. These are explicit test endpoints;
raw return stubs remain disabled for arbitrary `.bin` requests.

## Client commands

### DNS, web and certificate path

```bash
.venv/bin/python scripts/validate-lab.py 192.168.56.5 --ca /path/to/inetsim-ca.crt --system-trust
.venv/bin/python scripts/validate-dns.py 192.168.56.5 --queries 100000 --tcp-queries 20000 --concurrency 32 --doh-url https://example.test/dns-query --json dns-results.json
```

The first command checks direct UDP/TCP DNS and HTTP/HTTPS with hostname
verification. The DNS validator also checks normal OS resolution, invented
names, EDNS, malformed-input recovery and TCP reuse/pipelining. See [DNS setup](dns-setup.md).
Its DoH HTTPS check uses OS certificate trust.

### Protocol matrix

```bash
.venv/bin/python scripts/validate-protocols.py 192.168.56.5
.venv/bin/python scripts/validate-protocols.py 192.168.56.5 --extended
```

The second command needs the expanded profile: SMTP/POP3/FTP implicit TLS on
465/995/990, plus `/large.txt` in both FTP and TFTP containing
`0123456789abcdef` repeated 256 times. It checks protected FTPS data, fragmented
uploads, multi-block TFTP, SOCKS variants, SMB sequences, all configured banner
and dummy ports, and all 19 default download extensions.

To repeat the configured DNS record matrix against that same expanded profile:

```bash
.venv/bin/python scripts/validate-dns.py 192.168.56.5 --records --ipv6-sinkhole fd00:56::5 --json dns-matrix.json
```

That checks an AAAA answer over IPv4 transport; it does not test IPv6 connectivity.
Run one server profile at a time because their listener ports overlap. Restore
the normal profile when the expanded checks finish.

### Download and execution

```bash
.venv/bin/python scripts/validate-downloads.py https://example.test --extended --json downloads.json
.venv/bin/python scripts/validate-downloads.py https://example.test --extended --execute --json executions.json
```

The first verifies transfers and exact contents. The second also runs matching
known harmless templates on the client. Missing runtimes or incompatible
architectures are reported as execution skips; a successful download does not
make a skipped execution pass. See [download workflow](download-workflow.md)
for Wine, Windows DLL architecture and raw return-stub details.

### Onion-service application traffic

```bash
.venv/bin/python scripts/validate-tor.py 192.168.56.5 --queries 1000 --concurrency 16 --execute --json tor-results.json
```

This exercises SOCKS5/SOCKS4a, onion HTTP/HTTPS, authentication, malformed-input
handling, control status and a known harmless ELF download/execution. The
execution option requires a Linux x86-64 client. Configure the sample's SOCKS
endpoint as `192.168.56.5:9050`; a real Tor daemon's bootstrap is not emulated.
See [Tor setup](tor-setup.md).

## Source and optional integration tests

Install pytest before isolation or from the offline wheelhouse, as described
in [lab setup](lab-setup.md), then run:

```bash
.venv/bin/python -m pytest -q
INETSIM_RUN_MITMPROXY_INTEGRATION=1 .venv/bin/python -m pytest tests/test_mitmproxy.py -q
INETSIM_RUN_WINDOWS_DOWNLOAD_INTEGRATION=1 .venv/bin/python -m pytest tests/test_downloads_wine.py -q
.venv/bin/python scripts/build-download-stubs.py --check
```

The optional tests need installed mitmproxy or Wine/MinGW, respectively. Binary
rebuild comparison needs GCC and both MinGW compilers with a matching toolchain.
Unavailable or disabled integrations are reported as skips.

## Earlier Linux lab results — 2026-10-18

These are results from distinct passes on REMnux Ubuntu 24.04 with Python 3.12.3,
using a second REMnux VM as the client. They are a dated snapshot, not a claim
that tests run automatically after later edits.

| Pass | Observed result |
| --- | --- |
| Latest Tor regression suite | 207 passed, 9 skipped on REMnux; live mitmproxy enabled; optional Wine/MinGW and unavailable PowerShell skipped |
| Earlier Windows replacement suite | 211 passed, 1 skipped on host with Wine integration enabled; live mitmproxy skipped there |
| Cross-VM protocol matrix | 31 groups passed, including FTPS protected data and all 19 download extensions |
| DNS workload | 100,000 UDP + 20,000 TCP unique-name queries; 32 concurrent clients; zero failures |
| Download workflow | 15 transfers matched over HTTP and HTTPS; nine execution cases passed in the cross-platform client validator; six execution skips reported separately |
| Additional Windows checks | Downloaded x86/x64 DLL loading/exports and JS/VBS/CMD/BAT execution passed under Wine |
| Onion workflow | 23 focused checks passed; curl and torsocks clients worked; 1,000 sessions including 250 TLS sessions had zero failures |
| Evidence checks | Response hashes, bounded POST artifacts, credential redaction, matched client trust and post-reboot onion HTTPS download/execution passed |

The prepared bundle contains `VM-VALIDATION.txt`, `TOR-VALIDATION.txt`, and
`DOWNLOAD-WORKFLOW-VALIDATION.txt` with detailed evidence. Review JSON output and
server logs together; a download event alone cannot prove sample execution.

These earlier passes used REMnux and Wine. The later native Tiny11 client pass
is documented in [Windows client through REMnux](windows-client-lab.md), and the
combined result index is [testing results](testing-results.md). A bounded run of
the supplied WannaCry sample is recorded separately in
[compatibility results](compatibility-results.md). It stopped after kill-switch
HTTP contact; it does not validate later malware stages. The benign tests do
not establish Tor Browser compatibility, real Tor circuits, pinned/encrypted
stage compatibility, long-term reliability or improved stability relative to
Perl INetSim.
