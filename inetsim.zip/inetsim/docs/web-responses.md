# Web responses and fingerprinting

The HTTP and HTTPS services return a modern, self-contained enterprise sign-in
page at `/` by default. It can be styled as an administrative sign-in page by
changing its text. This is the page presented to analysis clients; simulator
configuration remains in TOML and the CLI. The page does not authenticate users
or provide an analyst management dashboard.

## Why the response changed

The project replaces the familiar legacy INetSim landing-page presentation with
a neutral response whose generated HTML contains no obvious INetSim name.
Configurable branding and service headers help avoid simple checks for known
simulator page strings. The HTTP tests check the absence of that name in the
default page and generated download content.

This is a response-profile improvement, not evidence that all malware will
continue execution. Static HTML, server behavior, timing, lab certificates and
protocol limitations can still reveal simulation. No broad comparison of
anti-analysis evasion against Perl INetSim has been performed.

## Configure the page

Edit the existing `[services.http]` section in your config:

```toml
[services.http]
server_header = "nginx/1.24.0"
login_page_enabled = true
login_page_path = "/"
login_page_brand = "Northwind"
login_page_title = "Administration sign in"
login_page_realm = "Authorized staff access"
```

The page includes inline styling and no external image, font or script fetches.
Configuration text is HTML-escaped. HTTP and built-in HTTPS share the page and
download configuration. The controls are visual placeholders; the sign-in
button does not submit credentials. Arbitrary client HTTP request bodies are
captured separately by the service, subject to configured limits.

## Routes and status codes

Merge entries into the existing tables rather than defining a TOML table twice:

```toml
[services.http.routes]
"/health" = "ready\n"
"/api/status" = '{"status":"ok"}'

[services.http.route_statuses]
"/health" = 200
"/api/status" = 200
```

Response selection follows this order:

1. The managed CRL path, when `global.tls_crl_url` is enabled.
2. Explicit `services.http.routes` entries, with configured per-route status.
3. The enabled login-page path.
4. Exact `fake_download_routes`, including extensionless paths.
5. Configured fake-download extensions.
6. The default body/status.

Query strings do not alter path selection. See [download workflow](download-workflow.md)
for available harmless templates. HTTP/HTTPS JSONL events record the selected
response kind, status, size and applicable response hash. The optional proxy
uses its own block/upstream policy; see [features](features.md#mitmproxy).

## WannaCry: successful contact can itself stop execution

In the recorded PMAT sample run, DNS mapped the kill-switch domain to REMnux
and HTTP returned 200. The sample exited normally after 0.625 seconds. This is
consistent with the documented WannaCry check: successfully opening its
kill-switch URL stops further execution. It does not require recognition of a
particular page string. [Microsoft's WannaCrypt analysis](https://www.microsoft.com/en-us/security/blog/2017/05/12/wannacrypt-ransomware-worm-targets-out-of-date-systems/)
describes this behavior.

Changing the simulated page's appearance therefore does not establish that
this sample will proceed. The captured run retained the normal response profile
and unchanged sample bytes. See [compatibility results](compatibility-results.md)
for the requests, observation limits and capture filenames.
