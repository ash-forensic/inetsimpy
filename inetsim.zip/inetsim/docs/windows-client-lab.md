# Windows client through REMnux

The prepared VirtualBox lab runs INetSim on Linux and uses native Windows as
the client. Windows sends off-subnet IPv4 traffic to REMnux, which intercepts
DNS and web traffic and records packets. The network has no external uplink.

| Machine | VirtualBox name | IPv4 | DNS | Default gateway |
| --- | --- | --- | --- | --- |
| REMnux server | `INetSim-REMnux-Test` | `192.168.56.5/24` | Local lab configuration | None |
| Tiny11 client | `INetSim-Windows-Test` | `192.168.56.20/24` | `192.168.56.5` | `192.168.56.5` |

Both machines have one adapter on the VirtualBox **Internal Network**
`INetSim-Detonation`. There are no NAT, bridged, or host-only adapters on these
two machines. Clipboard, drag and drop, and shared folders are disabled.
The earlier REMnux client remains separate and is not part of this network.

## Traffic handling

REMnux's `inetsim-windows-router.service` installs source-scoped rules for
`192.168.56.20` on `enp0s3`:

| Windows traffic | Handling |
| --- | --- |
| UDP/TCP port 53, including hard-coded DNS addresses | DNAT to INetSim DNS on `192.168.56.5:53` |
| TCP ports 80 and 443, including hard-coded destination IPs | DNAT to INetSim HTTP/HTTPS on the same ports |
| UDP port 443 | DNAT to the INetSim QUIC sink |
| Other services addressed to `192.168.56.5`, including sinkholed DNS names | Handled by configured INetSim listeners |
| Other off-subnet traffic | Captured and blocked |

IPv4 forwarding remains disabled and the FORWARD policy is DROP. Intercepted
packets are delivered locally, so enabling general routing is unnecessary.
REMnux also retains its subnet-only OUTPUT filter. Windows IPv6 binding is
disabled on its single lab adapter.

This contains traffic inside the simulator. It does not provide real internet
access, arbitrary protocol emulation, or a real Tor circuit. For SOCKS-aware
software, configure `192.168.56.5:9050`. A program hard-coded to a loopback Tor
proxy needs its own explicit configuration or a separately tested local forward.
Pinned certificates and custom encrypted protocols can still reject simulated
responses.

## Certificates and repeatable probes

The Windows client has separate x64 and x86 Python 3.12 runtimes under
`C:\INetSimLab\py64` and `C:\INetSimLab\py32`. The source and validation scripts
are under `C:\INetSimLab\source`. No Python installer or internet connection
is needed inside the client.

Install only the two public lab CA certificates using Administrator PowerShell:

```powershell
cd C:\INetSimLab
powershell -NoProfile -ExecutionPolicy Bypass -File .\source\scripts\install-ca-windows.ps1 -Action Install -CertPath .\inetsim-lab-ca.crt -Name inetsim-https-lab
powershell -NoProfile -ExecutionPolicy Bypass -File .\source\scripts\install-ca-windows.ps1 -Action Install -CertPath .\inetsim-mitm-ca.crt -Name inetsim-mitmproxy-ca
```

The helper uses the Local Machine root store. The CA private keys stay on
REMnux. HTTPS checks retain certificate-chain and hostname verification.

The prepared REMnux configuration now sets `global.tls_crl_url` and publishes a
signed CRL for its built-in CA. Default Schannel curl works without a revocation
bypass. The earlier pass needed the optional `--curl-revoke-best-effort` option
because no revocation information was published. That legacy option remains
available for older lab configurations, but the commands below use normal
revocation validation. See [certificate setup](certificates.md) and the
[follow-up results](compatibility-results.md), including revoked-leaf rejection
and Windows cache behavior.

Keep guest clocks synchronized. The Windows VM uses Guest Additions clock
sync at startup and a 1,000 ms interval/step threshold. A several-second client
clock lag was enough to reject a certificate generated for a new SNI name.

Repeat the client checks from PowerShell:

```powershell
cd C:\INetSimLab
.\py64\python.exe .\source\scripts\validate-lab.py 192.168.56.5 --ca .\inetsim-lab-ca.crt --system-trust
.\py64\python.exe .\source\scripts\validate-protocols.py 192.168.56.5
.\py64\python.exe .\source\scripts\validate-windows-client.py --json windows-routing.json
.\py64\python.exe .\source\scripts\validate-downloads.py https://example.test --extended --execute --json downloads-x64-https.json
.\py32\python.exe .\source\scripts\validate-downloads.py https://example.test --extended --execute --json downloads-x86-https.json
.\py64\python.exe .\source\scripts\validate-tor.py 192.168.56.5 --queries 400 --concurrency 16 --json windows-tor.json
```

Download execution runs only after an exact comparison with the fixed harmless
templates. Architecture and unavailable-runtime skips are reported separately.
The Tor validator's `--execute` option runs a Linux ELF and should be omitted
on Windows. Protocol checks use Python clients; controlled SMB exchanges do
not establish compatibility with Windows filesystem mounts.

## Logs and captures

On REMnux, the working directory is `/home/remnux/inetsim-vm-validation`:

```bash
tail -f logs/dns.jsonl logs/http.jsonl logs/https.jsonl logs/tor_socks.jsonl
systemctl status inetsim-validation.service inetsim-windows-router.service inetsim-windows-capture.service
ls -lh artifacts/pcap/
```

`inetsim-windows-capture.service` starts on boot and captures Windows traffic
on `enp0s3` into `artifacts/pcap/windows-client.pcap0` through `pcap4`, rotating
at approximately 20 MB per file. Files are private to the REMnux user. Save
session evidence before restoring snapshots or letting the ring overwrite it.
HTTP request bodies and other supported uploads remain in the ordinary
content-addressed artifact directories.

The Windows account is `analyst`. Its generated password is stored locally
at `/home/shadocat/Downloads/VM/inetsim-validation/windows-native/analyst-password.txt`
with owner-only permissions. The original Tiny11 ISO is unchanged.

## Native results — 2026-10-18

The supplied Tiny11 B1 image installed as Windows 11 Pro, build 22621.525,
with Python 3.12.10 x64/x86, PowerShell 5.1, and Schannel curl 7.83.1.
INetSim remained on REMnux throughout.

| Check | Observed result |
| --- | --- |
| DNS/web/CA path | 8 checks passed, including OS root-store trust; untrusted CA rejected before installation |
| Protocol matrix | 17 groups passed, including STARTTLS, FTP, controlled SMB, NTP/TFTP, QUIC sink, SOCKS, DoH and explicit proxy |
| Windows routing | 12 checks passed; external DNS/HTTP/HTTPS destinations intercepted; unsupported traffic and host-only host address unreachable |
| Downloads | 45 exact matches: x64 Python over HTTP/HTTPS and x86 Python over HTTPS |
| Native execution | 33 child executions passed, including x86/x64 EXE and DLL exports, SCR, JS/VBS/PowerShell/CMD/BAT, Python and the extensionless Python stage |
| Execution skips | 12 across the three runs: Linux ELF/shell, raw stub and the DLL architecture that did not match that Python process |
| Onion application traffic | 22 checks passed; 400 sessions at concurrency 16, including 100 TLS, zero failures |
| Server evidence | Download hashes matched; POST bytes and hash matched; 415 onion session events correlated; packet capture contained hard-coded destinations and blocked traffic |
| Host regression suite | 207 passed, 9 optional integrations skipped |
| Reboot persistence | All three REMnux services active; 8 client lab checks and 12 routing checks passed again with a fresh SNI name |

The initial Schannel curl checks used the explicit offline revocation option.
The follow-up CRL implementation removed that requirement; its separate results
are linked above. WinHTTP and Python used normal CA/hostname verification. The CA
helper was verified for initial install, repeated install, removal and restore.
Its empty-search `.Count` error was fixed for Windows PowerShell 5.1.

Detailed transcripts, JSON reports, the source patch, and
`windows-native-validation.pcap` are in
`/home/shadocat/Downloads/VM/inetsim-validation/windows-native`.
The summary is `../WINDOWS-CLIENT-VALIDATION.txt`. Initial failure transcripts
are retained separately from the final successful results.

The initial checks used harmless replacements. A later observation of the
user-supplied WannaCry sample ran in a separate disposable clone and is recorded
in the follow-up results. Neither pass establishes all Windows releases or
arbitrary sample behavior.

## Restore the prepared lab

Both VMs have a powered-off snapshot named `crl-validated`, which includes
the signed-CRL follow-up. The earlier `windows-client-ready` pair is preserved.
The server's earlier `validated-lab` and `before-windows-client` snapshots remain available
for the previous host-only setup.

Save analysis evidence and shut down both guests before restoring the pair:

```bash
VBoxManage snapshot INetSim-REMnux-Test restore crl-validated
VBoxManage snapshot INetSim-Windows-Test restore crl-validated
VBoxManage startvm INetSim-REMnux-Test --type gui
VBoxManage startvm INetSim-Windows-Test --type gui
```

The Windows installation media is detached. All client tools and CA trust are
stored in its disk snapshot. Start REMnux before running client probes.
