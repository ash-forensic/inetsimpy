#!/usr/bin/env python3
"""Rebuild the packaged harmless binaries using GCC/MinGW; never run at startup."""
from __future__ import annotations

import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import tempfile


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="compare a rebuild with the committed assets")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    source = root / "tools/download-stubs"
    destination = root / "src/inetsim_py/data/downloads"
    outputs = {}
    with tempfile.TemporaryDirectory(prefix="download-stubs-") as temporary:
        work = Path(temporary)
        for arch, compiler in [("x86", "i686-w64-mingw32-gcc"), ("x64", "x86_64-w64-mingw32-gcc")]:
            for dll in (False, True):
                name = f"windows-{arch}.{'dll' if dll else 'exe'}"
                output = work / ("download.dll" if dll else "download.exe")
                entry = ("_DllMain@12" if dll else "_entry@0") if arch == "x86" else ("DllMain" if dll else "entry")
                command = [compiler, "-Os", "-s", "-nostdlib", "-fno-ident", "-fno-stack-protector",
                           "-Wl,--no-insert-timestamp", "-Wl,--entry," + entry,
                           "-ffile-prefix-map=" + str(root) + "=.", str(source / "windows.c"),
                           "-o", str(output)]
                command += ["-shared", "-DBUILD_DLL", "-Wl,--kill-at", "-Wl,--image-base," +
                            ("0x10000000" if arch == "x86" else "0x180000000")] if dll else ["-lkernel32", "-mwindows"]
                subprocess.run(command, check=True)
                outputs[name] = output.read_bytes()
        output = work / "download.elf"
        subprocess.run(["gcc", "-m64", "-nostdlib", "-static", "-s", "-Wl,--build-id=none",
                        str(source / "linux-x64.S"), "-o", str(output)], check=True)
        outputs["linux-x64.elf"] = output.read_bytes()
    manifest = {
        "sources": {p.name: sha256(p.read_bytes()).hexdigest() for p in sorted(source.iterdir()) if p.is_file()},
        "binaries": {name: sha256(body).hexdigest() for name, body in outputs.items()},
    }
    outputs["manifest.json"] = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    destination.mkdir(parents=True, exist_ok=True)
    for name, body in outputs.items():
        path = destination / name
        if args.check:
            if not path.exists() or path.read_bytes() != body:
                raise SystemExit(f"Rebuild differs: {path}")
        else:
            path.write_bytes(body)
        print(f"{'MATCH' if args.check else 'WROTE'} {name} {sha256(body).hexdigest()}")


if __name__ == "__main__":
    main()
