#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Usage:
  sudo ./scripts/install-ca-linux.sh install <ca-file> [name]
  sudo ./scripts/install-ca-linux.sh remove [name]

Installs or removes a lab CA from the local Debian/Ubuntu OS trust store.

Arguments:
  ca-file  PEM/CRT CA certificate to trust.
  name     Trust-store filename stem. Default: inetsim-mitmproxy-ca

Examples:
  sudo ./scripts/install-ca-linux.sh install artifacts/mitmproxy/conf/mitmproxy-ca-cert.pem
  sudo ./scripts/install-ca-linux.sh remove
EOF
}

die() {
  printf 'error: %s\n' "$*" >&2
  exit 1
}

require_root() {
  if [[ "${EUID}" -ne 0 ]]; then
    die "this script requires elevated permissions; run it with sudo"
  fi
}

require_command() {
  command -v "$1" >/dev/null 2>&1 || die "required command not found: $1"
}

validate_name() {
  local name="$1"
  [[ "${name}" =~ ^[A-Za-z0-9_.-]+$ ]] || die "invalid certificate name: ${name}"
}

install_ca() {
  local source_ca="$1"
  local name="${2:-inetsim-mitmproxy-ca}"
  validate_name "${name}"
  [[ -f "${source_ca}" ]] || die "CA file does not exist: ${source_ca}"

  local destination="/usr/local/share/ca-certificates/${name}.crt"
  install -m 0644 "${source_ca}" "${destination}"
  update-ca-certificates
  printf 'installed CA: %s\n' "${destination}"
}

remove_ca() {
  local name="${1:-inetsim-mitmproxy-ca}"
  validate_name "${name}"

  local destination="/usr/local/share/ca-certificates/${name}.crt"
  rm -f "${destination}"
  update-ca-certificates
  printf 'removed CA: %s\n' "${destination}"
}

main() {
  if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
    usage
    exit 0
  fi

  local action="${1:-}"
  [[ -n "${action}" ]] || {
    usage >&2
    exit 2
  }

  require_root
  require_command update-ca-certificates

  case "${action}" in
    install)
      [[ $# -ge 2 ]] || die "install requires a CA file"
      install_ca "$2" "${3:-inetsim-mitmproxy-ca}"
      ;;
    remove)
      remove_ca "${2:-inetsim-mitmproxy-ca}"
      ;;
    *)
      usage >&2
      exit 2
      ;;
  esac
}

main "$@"
