param(
    [ValidateSet("Install", "Remove")]
    [string]$Action = "Install",

    [string]$CertPath,

    [string]$Name = "inetsim-mitmproxy-ca"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Test-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-CertificateFromFile {
    param([string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path)) {
        throw "CertPath is required for install, and recommended for precise removal."
    }
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "CA file does not exist: $Path"
    }

    $resolved = (Resolve-Path -LiteralPath $Path).Path
    return [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($resolved)
}

function Open-RootStore {
    $store = [System.Security.Cryptography.X509Certificates.X509Store]::new(
        [System.Security.Cryptography.X509Certificates.StoreName]::Root,
        [System.Security.Cryptography.X509Certificates.StoreLocation]::LocalMachine
    )
    $store.Open([System.Security.Cryptography.X509Certificates.OpenFlags]::ReadWrite)
    return $store
}

function Install-CaCertificate {
    param(
        [string]$Path,
        [string]$FriendlyName
    )

    $cert = Get-CertificateFromFile -Path $Path
    $store = Open-RootStore
    try {
        $existing = @($store.Certificates | Where-Object { $_.Thumbprint -eq $cert.Thumbprint })
        if ($existing.Count -eq 0) {
            $store.Add($cert)
        }

        $installed = Get-ChildItem Cert:\LocalMachine\Root | Where-Object { $_.Thumbprint -eq $cert.Thumbprint }
        foreach ($item in $installed) {
            $item.FriendlyName = $FriendlyName
        }
        Write-Host "installed CA thumbprint: $($cert.Thumbprint)"
    }
    finally {
        $store.Close()
    }
}

function Remove-CaCertificate {
    param(
        [string]$Path,
        [string]$FriendlyName
    )

    $thumbprint = $null
    if (-not [string]::IsNullOrWhiteSpace($Path)) {
        $thumbprint = (Get-CertificateFromFile -Path $Path).Thumbprint
    }

    $store = Open-RootStore
    try {
        $targets = @()
        foreach ($cert in $store.Certificates) {
            if ($thumbprint -and $cert.Thumbprint -eq $thumbprint) {
                $targets += $cert
            }
            elseif (-not $thumbprint -and $cert.FriendlyName -eq $FriendlyName) {
                $targets += $cert
            }
        }

        foreach ($cert in $targets) {
            $store.Remove($cert)
            Write-Host "removed CA thumbprint: $($cert.Thumbprint)"
        }
        if ($targets.Count -eq 0) {
            Write-Host "no matching CA certificate found"
        }
    }
    finally {
        $store.Close()
    }
}

if (-not (Test-Administrator)) {
    throw "this script requires elevated permissions; run PowerShell as Administrator"
}

switch ($Action) {
    "Install" {
        Install-CaCertificate -Path $CertPath -FriendlyName $Name
    }
    "Remove" {
        Remove-CaCertificate -Path $CertPath -FriendlyName $Name
    }
}
