#!/usr/bin/env python3
"""Publish or update revocation data for this lab's own CA."""
import argparse
from pathlib import Path

from inetsim_py.config import load_config, validate_config
from inetsim_py.pki import LabCrl


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', required=True)
    parser.add_argument('action', choices=['refresh', 'revoke'])
    parser.add_argument('certificate', nargs='?', type=Path)
    args = parser.parse_args()
    config = load_config(args.config)
    validate_config(config)
    if not config.global_.tls_crl_url:
        parser.error('set global.tls_crl_url before managing its published CRL')
    crl = LabCrl(config.global_.artifact_dir)
    if args.action == 'revoke':
        if args.certificate is None:
            parser.error('revoke requires a certificate issued by the lab CA')
        crl.revoke(args.certificate)
    else:
        crl.refresh(force=True)
    print(f'Published signed CRL: {crl.path}')
    print(f'Client URL: {config.global_.tls_crl_url}')


if __name__ == '__main__':
    main()
