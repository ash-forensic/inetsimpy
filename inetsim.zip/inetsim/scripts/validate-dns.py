#!/usr/bin/env python3
"""Independently test an INetSim lab DNS server (requires dnspython)."""
from __future__ import annotations

import argparse
import asyncio
import base64
from concurrent.futures import ThreadPoolExecutor
import http.client
import ipaddress
import json
from pathlib import Path
import socket
import statistics
import struct
import time
from urllib.parse import urlsplit
import uuid

try:
    import dns.asyncquery
    import dns.flags
    import dns.message
    import dns.query
    import dns.rcode
    import dns.rdatatype
except ImportError:
    raise SystemExit("Install the optional validation dependency: python3 -m pip install dnspython")


def exact(sock, count):
    result = b""
    while len(result) < count:
        part = sock.recv(count - len(result))
        if not part:
            raise ValueError("DNS TCP connection closed before its next complete response")
        result += part
    return result


def verify(query, response, address):
    if response.id != query.id or response.question != query.question:
        raise ValueError("DNS transaction ID or echoed question differs")
    if response.rcode() != dns.rcode.NOERROR or response.flags & dns.flags.TC:
        raise ValueError(f"DNS failed/truncated: {dns.rcode.to_text(response.rcode())}")
    answers = [r.address for rr in response.answer if rr.rdtype == dns.rdatatype.A
               and rr.name == query.question[0].name for r in rr]
    if answers != [address]:
        raise ValueError(f"expected A {address} for {query.question[0].name}, received {answers}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("server", type=ipaddress.IPv4Address)
    parser.add_argument("--port", type=int, default=53)
    parser.add_argument("--queries", type=int, default=5000, help="unique UDP queries")
    parser.add_argument("--tcp-queries", type=int, default=1000)
    parser.add_argument("--concurrency", type=int, default=32)
    parser.add_argument("--timeout", type=float, default=3)
    parser.add_argument("--ipv6-sinkhole", type=ipaddress.IPv6Address)
    parser.add_argument("--records", action="store_true", help="check the documented matrix.test record profile")
    parser.add_argument("--doh-url", help="also test wire-format DNS over HTTP/HTTPS")
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    if args.queries < 1 or args.tcp_queries < 1 or args.concurrency < 1 or args.timeout <= 0:
        parser.error("query counts, concurrency and timeout must be positive")
    server = str(args.server)
    token = uuid.uuid4().hex[:16]
    results = {"server": server, "token": token, "checks": [], "samples": [], "load": {}}

    def check(label, action):
        try:
            detail = action()
            results["checks"].append({"name": label, "passed": True, "detail": detail})
            print(f"PASS {label}" + (f": {detail}" if detail else ""), flush=True)
        except Exception as exc:
            results["checks"].append({"name": label, "passed": False, "error": f"{type(exc).__name__}: {exc}"})
            print(f"FAIL {label}: {type(exc).__name__}: {exc}", flush=True)

    def query(name, kind="A", tcp=False, **kwargs):
        q = dns.message.make_query(name, kind, **kwargs)
        r = (dns.query.tcp if tcp else dns.query.udp)(q, server, port=args.port, timeout=args.timeout)
        return q, r

    names = [f"does-not-exist-{token}.invalid", f"sub.deep.{token}.test",
             f"MiXeD-{token}.INVALID.", f"_service._tcp.{token}.invalid",
             f"123.{token}.invalid", f"xn--bcher-kva.{token}.invalid",
             "a" * 63 + "." + token + ".invalid",
             ".".join(["a" * 63, "b" * 63, "c" * 63, "d" * 61])]
    for tcp in (False, True):
        def wildcard(tcp=tcp):
            for name in names:
                q, r = query(name, tcp=tcp)
                verify(q, r, server)
                results["samples"].append({"transport": "tcp" if tcp else "udp", "query": q.question[0].name.to_text(),
                                          "rcode": dns.rcode.to_text(r.rcode()), "answers": [rr.to_text() for rr in r.answer]})
            return f"{len(names)} invented/boundary names; requested owner name preserved; A={server}"
        check("wildcard " + ("TCP" if tcp else "UDP"), wildcard)

    def unsupported():
        for kind in ("AAAA", "HTTPS", "SVCB", "TXT", "MX", "SOA"):
            for tcp in (False, True):
                q, r = query(f"nodata-{token}.invalid", kind, tcp=tcp)
                if r.id != q.id or r.question != q.question or r.rcode() != dns.rcode.NOERROR:
                    raise ValueError(f"{kind} should return NOERROR")
                if kind == "AAAA" and args.ipv6_sinkhole:
                    assert [str(record.address) for rr in r.answer for record in rr] == [str(args.ipv6_sinkhole)]
                elif r.answer:
                    raise ValueError(f"unexpected answer for unconfigured {kind}")
        if args.ipv6_sinkhole:
            return "unconfigured types return NOERROR/NODATA; configured AAAA returns its IPv6 sinkhole"
        return "unconfigured types, including AAAA, return NOERROR/NODATA"
    check("record types and IPv4/IPv6 behavior", unsupported)

    def edns():
        for size in (512, 1232, 4096):
            q, r = query(f"edns-{size}-{token}.invalid", use_edns=0, payload=size, want_dnssec=True)
            verify(q, r, server)
            if r.flags & dns.flags.AD:
                raise ValueError("synthetic answer incorrectly claims DNSSEC authentication")
        return "EDNS and DNSSEC-requesting clients receive unsigned sinkhole answers"
    check("EDNS client compatibility", edns)

    def persistent(pipeline):
        queries = [dns.message.make_query(f"stream-{i}-{token}.invalid", "A") for i in range(20)]
        frames = [struct.pack("!H", len(q.to_wire())) + q.to_wire() for q in queries]
        with socket.create_connection((server, args.port), timeout=args.timeout) as sock:
            if pipeline:
                sock.sendall(b"".join(frames))
            for q, frame in zip(queries, frames):
                if not pipeline:
                    sock.sendall(frame)
                response = dns.message.from_wire(exact(sock, struct.unpack("!H", exact(sock, 2))[0]))
                verify(q, response, server)
        return "20 correct replies on one TCP connection"
    check("TCP connection reuse", lambda: persistent(False))
    check("TCP pipelining", lambda: persistent(True))

    def malformed():
        header = b"\x12\x34\x01\0\0\x01\0\0\0\0\0\0"
        packets = [b"", b"\0", b"\0" * 11, header, header + b"\xc0\x0c\0\x01\0\x01",
                   header + b"\xff\xff", header + b"\x03ab", header + b"\x01\xff\0\0\x01\0\x01",
                   header + b"\x40" + b"a" * 64 + b"\0\0\x01\0\x01"]
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.settimeout(0.1)
            sock.connect((server, args.port))
            for packet in packets:
                sock.send(packet)
                try:
                    sock.recv(4096)
                except socket.timeout:
                    pass
                else:
                    raise ValueError("malformed UDP query received an answer")
        for data in (b"\0", b"\0\x20short", b"\0\0"):
            with socket.create_connection((server, args.port), timeout=args.timeout) as sock:
                sock.sendall(data)
                sock.shutdown(socket.SHUT_WR)
                try:
                    reply = sock.recv(4096)
                except ConnectionResetError:
                    reply = b""
                if reply:
                    raise ValueError("malformed TCP query received an answer")
        verify(*query(f"after-malformed-{token}.invalid"), server)
        return f"{len(packets)} malformed UDP messages and 3 broken TCP frames; valid queries still work"
    check("malformed input recovery", malformed)

    def os_resolver():
        def resolve(index):
            name = f"os-resolver-{index}-{token}.test"
            addresses = {entry[4][0] for entry in socket.getaddrinfo(name, 80, family=socket.AF_INET)}
            if addresses != {server}:
                raise ValueError(f"OS resolver returned {addresses} for {name}")
        with ThreadPoolExecutor(max_workers=8) as pool:
            list(pool.map(resolve, range(32)))
        return "32 unique nonexistent names resolved through the client's normal OS DNS path"
    check("normal OS resolver", os_resolver)

    if args.records:
        def records():
            expected = [("explicit.matrix.test", "A", "192.168.56.20"),
                        ("matrix.test", "MX", "10 mail.matrix.test."),
                        ("matrix.test", "TXT", '"v=spf1 -all"'),
                        ("alias.matrix.test", "CNAME", "matrix.test."),
                        ("matrix.test", "NS", "ns.matrix.test."),
                        ("_https._tcp.matrix.test", "SRV", "0 5 443 web.matrix.test.")]
            for name, kind, text in expected:
                for tcp in (False, True):
                    q, r = query(name, kind, tcp=tcp)
                    assert r.id == q.id and r.rcode() == dns.rcode.NOERROR
                    if [record.to_text() for rr in r.answer for record in rr] != [text]:
                        raise ValueError(f"wrong {kind} record for {name}: {r.answer}")
            return "A, MX, TXT, CNAME, NS and SRV checked over UDP and TCP"
        check("configured record matrix", records)

    if args.doh_url:
        def doh():
            parsed = urlsplit(args.doh_url)
            for method in ("GET", "POST"):
                q = dns.message.make_query(f"doh-{method.lower()}-{token}.invalid", "A")
                wire = q.to_wire()
                path = parsed.path or "/dns-query"
                if method == "GET":
                    path += "?dns=" + base64.urlsafe_b64encode(wire).decode().rstrip("=")
                cls = http.client.HTTPSConnection if parsed.scheme == "https" else http.client.HTTPConnection
                connection = cls(parsed.hostname, parsed.port, timeout=args.timeout)
                try:
                    connection.request(method, path, body=wire if method == "POST" else None,
                                       headers={"Content-Type": "application/dns-message"})
                    response = connection.getresponse()
                    if response.status != 200:
                        raise ValueError(f"DoH {method}: HTTP {response.status}")
                    verify(q, dns.message.from_wire(response.read()), server)
                finally:
                    connection.close()
            return "GET and POST preserve requested names; HTTPS uses default certificate verification"
        check("DNS-over-HTTP(S)", doh)

    async def load(tcp):
        count = args.tcp_queries if tcp else args.queries
        next_index = 0
        samples = []
        errors = []
        started = time.perf_counter()
        async def worker():
            nonlocal next_index
            while next_index < count:
                index = next_index
                next_index += 1
                q = dns.message.make_query(f"load-{int(tcp)}-{index}-{token}.invalid", "A")
                at = time.perf_counter()
                try:
                    fn = dns.asyncquery.tcp if tcp else dns.asyncquery.udp
                    r = await fn(q, server, port=args.port, timeout=args.timeout)
                    verify(q, r, server)
                    samples.append((time.perf_counter() - at) * 1000)
                except Exception as exc:
                    errors.append(f"{index}: {type(exc).__name__}: {exc}")
        await asyncio.gather(*(worker() for _ in range(min(args.concurrency, count))))
        elapsed = time.perf_counter() - started
        ordered = sorted(samples)
        result = {"queries": count, "concurrency": args.concurrency, "successes": len(samples),
                  "failures": len(errors), "seconds": round(elapsed, 3),
                  "queries_per_second": round(count / elapsed, 1), "first_errors": errors[:10]}
        if ordered:
            result.update({"median_ms": round(statistics.median(ordered), 3),
                           "p95_ms": round(ordered[min(len(ordered) - 1, int(len(ordered) * .95))], 3),
                           "max_ms": round(max(ordered), 3)})
        results["load"]["tcp" if tcp else "udp"] = result
        if errors:
            raise ValueError(json.dumps(result))
        return json.dumps(result)
    check("UDP concurrent unique-name load", lambda: asyncio.run(load(False)))
    check("TCP concurrent unique-name load", lambda: asyncio.run(load(True)))
    check("DNS still responds after load", lambda: verify(*query(f"after-load-{token}.invalid"), server))
    results["failed_checks"] = sum(not result["passed"] for result in results["checks"])
    if args.json:
        args.json.write_text(json.dumps(results, indent=2) + "\n")
    print(f"{results['failed_checks']} failed checks", flush=True)
    return bool(results["failed_checks"])


if __name__ == "__main__":
    raise SystemExit(main())
