#!/usr/bin/env python3
"""Download known harmless replacements; optionally execute them on this client."""
from __future__ import annotations

import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import platform
import shutil
import ssl
import subprocess
import sys
import tempfile
from urllib.parse import urlsplit
from urllib.request import HTTPSHandler, ProxyHandler, build_opener

from inetsim_py.services.http import fake_download_body


def execution_command(path: Path, kind: str, wine: bool) -> list[str] | None:
    suffix = path.suffix
    windows = os.name == "nt"
    x64_linux = sys.platform.startswith("linux") and platform.machine().lower() in {"x86_64", "amd64"}
    if kind == "linux_executable":
        return [str(path)] if x64_linux else None
    if kind.startswith("windows_executable"):
        return [str(path)] if windows else ["wine", str(path)] if wine and shutil.which("wine") else None
    if kind.startswith("windows_dll") and windows:
        # Match DLL and Python process architecture. Never load it into this validator.
        want64 = kind.endswith("x64")
        if want64 != (sys.maxsize > 2**32):
            return None
        code = ("import ctypes,sys; d=ctypes.WinDLL(sys.argv[1]); d.Run.restype=None; "
                "d.Run(None,None,None,0); "
                "assert d.DllRegisterServer()==0; assert d.DllUnregisterServer()==0")
        return [sys.executable, "-c", code, str(path)]
    if suffix == ".py" or kind == "python_script":
        return [sys.executable, str(path)]
    if suffix == ".sh" and not windows:
        return ["/bin/sh", str(path)]
    if suffix == ".js":
        if shutil.which("node"):
            return ["node", str(path)]
        if windows:
            return ["cscript.exe", "//nologo", str(path)]
    if suffix == ".vbs" and windows:
        return ["cscript.exe", "//nologo", str(path)]
    if suffix == ".ps1":
        powershell = shutil.which("pwsh") or shutil.which("powershell")
        if powershell:
            # This is a fresh process for an exact-verified harmless template;
            # do not change the client's persistent execution policy.
            return [powershell, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", str(path)]
    if suffix in {".bat", ".cmd"} and windows:
        return [os.environ.get("COMSPEC", "cmd.exe"), "/d", "/c", str(path)]
    if kind == "shellcode_x64" and x64_linux:
        # This is only reached after exact comparison with our fixed three-byte stub.
        code = ("import ctypes,mmap; m=mmap.mmap(-1,3,prot=mmap.PROT_READ|mmap.PROT_WRITE|mmap.PROT_EXEC); "
                "m.write(b'\\x31\\xc0\\xc3'); f=ctypes.CFUNCTYPE(ctypes.c_int)(ctypes.addressof(ctypes.c_char.from_buffer(m))); "
                "assert f()==0")
        return [sys.executable, "-c", code]
    return None


def verified_body(body: bytes, expected: bytes) -> None:
    if body != expected:
        raise ValueError("download differs from the known harmless template; execution refused")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("url", help="simulator base URL, e.g. https://example.test")
    parser.add_argument("--ca", type=Path, help="public lab CA; otherwise use client OS trust")
    parser.add_argument("--execute", action="store_true", help="run verified replacements on THIS client")
    parser.add_argument("--wine", action="store_true", help="also run Windows EXEs using installed Wine")
    parser.add_argument("--extended", action="store_true", help="check the documented /validation/ download routes")
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    parsed = urlsplit(args.url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.path not in {"", "/"} or parsed.query or parsed.fragment or parsed.username or parsed.password:
        parser.error("provide an HTTP(S) base URL without credentials, path or query")
    context = ssl.create_default_context(cafile=str(args.ca) if args.ca else None)
    # Do not inherit host proxy settings or disable certificate verification.
    opener = build_opener(ProxyHandler({}), HTTPSHandler(context=context))
    cases = [("/workflow." + ext, kind) for ext, kind in [
        ("exe", "windows_executable"), ("dll", "windows_dll"), ("scr", "windows_executable"),
        ("elf", "linux_executable"), ("sh", "script"), ("py", "script"), ("js", "script"),
        ("vbs", "script"), ("ps1", "script"), ("cmd", "script"), ("bat", "script")]]
    if args.extended:
        cases += [("/validation/windows-x64.exe", "windows_executable_x64"),
                  ("/validation/windows-x64.dll", "windows_dll_x64"),
                  ("/validation/stage", "python_script"),
                  ("/validation/return", "shellcode_x64")]
    results = {"url": args.url, "execute": args.execute, "checks": []}
    with tempfile.TemporaryDirectory(prefix="inetsim-download-check-") as temporary:
        for index, (route, kind) in enumerate(cases):
            result = {"path": route, "kind": kind, "passed": False, "execution": "not_requested"}
            try:
                with opener.open(args.url.rstrip("/") + route, timeout=10) as response:
                    body = response.read(1024 * 1024)
                    if response.status != 200:
                        raise ValueError(f"unexpected HTTP status {response.status}")
                verified_body(body, fake_download_body(route, kind)[0])
                result.update({"bytes": len(body), "sha256": sha256(body).hexdigest()})
                path = Path(temporary) / (str(index) + "-" + route.rsplit("/", 1)[-1])
                path.write_bytes(body)
                path.chmod(0o700)
                if args.execute:
                    command = execution_command(path, kind, args.wine)
                    if command:
                        result["execution"] = "failed"
                        run = subprocess.run(command, capture_output=True, timeout=30)
                        result.update({"execution": "passed" if run.returncode == 0 else "failed", "exit_code": run.returncode})
                        if run.returncode:
                            raise ValueError(f"execution exited {run.returncode}: {run.stderr.decode(errors='replace')[:500]}")
                    else:
                        result["execution"] = "skipped_unavailable_runtime_or_architecture"
                result["passed"] = True
                print(f"PASS {route} sha256={result['sha256']} execution={result['execution']}", flush=True)
            except Exception as exc:
                result["error"] = f"{type(exc).__name__}: {exc}"
                print(f"FAIL {route}: {result['error']}", flush=True)
            results["checks"].append(result)
    failures = sum(not check["passed"] for check in results["checks"])
    executed = sum(check["execution"] == "passed" for check in results["checks"])
    skipped = sum(check["execution"].startswith("skipped") for check in results["checks"])
    results.update({"failures": failures, "executed": executed, "skipped": skipped})
    if args.json:
        args.json.write_text(json.dumps(results, indent=2) + "\n")
    print(f"{failures} failed checks; {executed} executions passed; {skipped} executions skipped")
    return int(bool(failures))


if __name__ == "__main__":
    raise SystemExit(main())
