#!/usr/bin/env python3
"""Probe a running simulator from another VM using only Python's standard library."""
from __future__ import annotations

import argparse
import http.client
import ipaddress
from pathlib import Path
import secrets
import socket
import ssl
import struct
import sys


def receive_exact(sock: socket.socket, size: int) -> bytes:
    result = bytearray()
    while len(result) < size:
        part = sock.recv(size - len(result))
        if not part:
            raise ValueError("connection closed before the DNS response was complete")
        result.extend(part)
    return bytes(result)


def skip_name(packet: bytes, offset: int) -> int:
    while True:
        length = packet[offset]
        offset += 1
        if length == 0:
            return offset
        if length & 0xC0 == 0xC0:
            return offset + 1
        if length & 0xC0 or length > 63:
            raise ValueError("invalid DNS label")
        offset += length


def check_dns(server: str, port: int, host: str, transport: str) -> None:
    transaction = secrets.token_bytes(2)
    labels = b"".join(bytes([len(label)]) + label.encode("ascii") for label in host.split("."))
    query = transaction + struct.pack("!5H", 0x0100, 1, 0, 0, 0) + labels + b"\0" + struct.pack("!HH", 1, 1)
    if transport == "udp":
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.settimeout(8)
            sock.connect((server, port))
            sock.send(query)
            response = sock.recv(65535)
    else:
        with socket.create_connection((server, port), timeout=8) as sock:
            sock.sendall(struct.pack("!H", len(query)) + query)
            size = struct.unpack("!H", receive_exact(sock, 2))[0]
            response = receive_exact(sock, size)
    tx, flags, questions, answers, _, _ = struct.unpack_from("!2s5H", response)
    if tx != transaction or not flags & 0x8000 or flags & 0xF or flags & 0x0200:
        raise ValueError("invalid, truncated, or unsuccessful DNS response")
    offset = 12
    for _ in range(questions):
        offset = skip_name(response, offset) + 4
    addresses = []
    for _ in range(answers):
        offset = skip_name(response, offset)
        kind, family, _, size = struct.unpack_from("!HHIH", response, offset)
        offset += 10
        if kind == 1 and family == 1 and size == 4:
            addresses.append(socket.inet_ntoa(response[offset:offset + size]))
        offset += size
    if server not in addresses:
        raise ValueError(f"expected {server} in A answers, received {addresses}")


def request(server: str, port: int, host: str, path: str, context: ssl.SSLContext | None = None,
            body: bytes | None = None) -> tuple[int, bytes]:
    # Connect to the supplied IP without consulting client DNS, retaining Host and TLS SNI.
    connection = http.client.HTTPConnection(host, port, timeout=8)
    try:
        connection.sock = socket.create_connection((server, port), timeout=8)
        if context is not None:
            connection.sock = context.wrap_socket(connection.sock, server_hostname=host)
        connection.request("POST" if body is not None else "GET", path, body=body,
                           headers={"Connection": "close"})
        response = connection.getresponse()
        return response.status, response.read(2 * 1024 * 1024)
    finally:
        connection.close()


def require_response(result: tuple[int, bytes], expected: bytes) -> None:
    status, body = result
    if status != 200 or expected not in body:
        raise ValueError(f"unexpected HTTP response: status={status}, bytes={len(body)}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("server", type=ipaddress.IPv4Address, help="simulator's host-only IPv4 address")
    parser.add_argument("--ca", type=Path, required=True, help="public inetsim-ca.crt copied from REMnux")
    parser.add_argument("--host", default="example.test")
    parser.add_argument("--dns-port", type=int, default=53)
    parser.add_argument("--http-port", type=int, default=80)
    parser.add_argument("--https-port", type=int, default=443)
    parser.add_argument("--system-trust", action="store_true", help="also require the client OS to trust the CA")
    args = parser.parse_args()
    try:
        hostname = args.host.rstrip(".").encode("idna").decode("ascii")
        if not hostname or len(hostname) > 253 or any(not 0 < len(x) <= 63 for x in hostname.split(".")):
            parser.error("invalid hostname")
        if not args.ca.is_file():
            parser.error(f"CA file does not exist: {args.ca}")
        context = ssl.create_default_context(cafile=str(args.ca))
    except (UnicodeError, OSError, ssl.SSLError) as exc:
        parser.error(str(exc))
    server = str(args.server)
    failures = 0

    def check(label, operation):
        nonlocal failures
        try:
            operation()
            print(f"PASS {label}")
        except Exception as exc:
            failures += 1
            print(f"FAIL {label}: {type(exc).__name__}: {exc}")

    for transport in ("udp", "tcp"):
        check(f"DNS {transport.upper()} sinkholes {hostname} to {server}",
              lambda transport=transport: check_dns(server, args.dns_port, hostname, transport))
    check("HTTP login page", lambda: require_response(
        request(server, args.http_port, hostname, "/"), b"Enterprise sign in"))
    check("HTTP harmless executable", lambda: require_response(
        request(server, args.http_port, hostname, "/validation.exe"), b"MZ"))
    check("HTTPS validates the CA and hostname", lambda: require_response(
        request(server, args.https_port, hostname, "/", context), b"Enterprise sign in"))
    check("HTTPS harmless executable", lambda: require_response(
        request(server, args.https_port, hostname, "/validation.exe", context), b"MZ"))
    check("HTTP request-body submission (inspect server artifact)", lambda: require_response(
        request(server, args.http_port, hostname, "/validation-upload", body=b"inetsim-vm-validation\n"),
        b"Service unavailable"))
    if args.system_trust:
        check("HTTPS validates through the client OS trust store", lambda: require_response(
            request(server, args.https_port, hostname, "/", ssl.create_default_context()), b"Enterprise sign in"))
    print(f"{failures} failed checks")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
