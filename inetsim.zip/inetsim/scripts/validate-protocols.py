#!/usr/bin/env python3
"""Benign cross-VM protocol checks for the prepared validation profile."""
import argparse
import ftplib
import time
import http.client
import io
import poplib
import smtplib
import socket
import ssl
import struct

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("server", nargs="?", default="192.168.56.5")
parser.add_argument("--extended", action="store_true", help="also probe the expanded validation profile, including implicit TLS ports")
parser.add_argument("--ca", help="optional CA bundle; otherwise use the client OS trust store")
args = parser.parse_args()
SERVER = args.server
context = ssl.create_default_context(cafile=args.ca)
failures = 0


def check(name, fn):
    global failures
    try:
        fn()
        print('PASS ' + name, flush=True)
    except Exception as exc:
        failures += 1
        print(f'FAIL {name}: {type(exc).__name__}: {exc}', flush=True)


def exact(sock, size):
    data = b''
    while len(data) < size:
        part = sock.recv(size - len(data))
        if not part:
            raise ValueError('short response')
        data += part
    return data


def smtp():
    with smtplib.SMTP('mx01.corp.local', 25, timeout=5) as client:
        client.ehlo()
        client.starttls(context=context)
        client.ehlo()
        assert client.sendmail('analyst@example.test', ['sink@example.test'],
                               'Subject: VM validation\r\n\r\nBenign SMTP validation.\r\n') == {}


def pop3():
    client = poplib.POP3('mail.corp.local', 110, timeout=5)
    try:
        client.stls(context=context)
        client.user('analyst')
        client.pass_('vm-test-password')
        assert client.stat()[0] >= 1
        assert b'Your mailbox is active' in b'\n'.join(client.retr(1)[1])
    finally:
        client.quit()


def ftp():
    with ftplib.FTP(SERVER, timeout=5) as client:
        client.login('analyst', 'vm-test-password')
        result = bytearray()
        client.retrbinary('RETR /README.txt', result.extend)
        assert b'FTP service' in result
        payload = b'benign-vm-ftp-upload\n'
        client.storbinary('STOR /validation-upload.txt', io.BytesIO(payload))
        result.clear()
        client.retrbinary('RETR /validation-upload.txt', result.extend)
        assert result == payload


def ftp_tls():
    with ftplib.FTP_TLS('ftp.local', timeout=5, context=context) as client:
        client.login('analyst', 'vm-test-password')
        assert client.voidcmd('NOOP').startswith('200')


def smb(port, netbios=False):
    header = bytearray(64)
    header[:4] = b'\xfeSMB'
    header[4:6] = (64).to_bytes(2, 'little')
    header[24:32] = (7).to_bytes(8, 'little')
    body = bytearray(36)
    body[:2] = (36).to_bytes(2, 'little')
    body[2:4] = (3).to_bytes(2, 'little')
    frame = bytes(header + body) + struct.pack('<HHH', 0x0202, 0x0302, 0x0311)
    with socket.create_connection((SERVER, port), timeout=5) as sock:
        if netbios:
            sock.sendall(b'\x81\x00\x00\x02AA')
            assert exact(sock, 4) == b'\x82\x00\x00\x00'
        sock.sendall(len(frame).to_bytes(4, 'big') + frame)
        response = exact(sock, int.from_bytes(exact(sock, 4), 'big'))
        assert response.startswith(b'\xfeSMB') and response[8:12] == b'\0' * 4
        assert int.from_bytes(response[24:32], 'little') == 7


def udp(port, payload):
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.settimeout(5)
        sock.connect((SERVER, port))
        sock.send(payload)
        return sock.recv(4096)


def ntp():
    response = udp(123, b'\x23' + b'\0' * 47)
    assert len(response) == 48 and response[0] & 7 == 4 and response[1] == 1


def tftp():
    response = udp(69, b'\0\x01README.txt\0octet\0')
    assert response[:4] == b'\0\x03\0\x01' and b'TFTP service' in response
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.settimeout(5)
        sock.connect((SERVER, 69))
        sock.send(b'\0\x02validation-upload.txt\0octet\0')
        assert sock.recv(4096) == b'\0\x04\0\0'
        sock.send(b'\0\x03\0\x01benign-vm-tftp-upload\n')
        assert sock.recv(4096) == b'\0\x04\0\x01'


def quic():
    response = udp(443, b'\xc0\0\0\0\x01\x04DCID\x04SCID')
    assert response[1:5] == b'\0' * 4 and b'SCID' in response and b'DCID' in response


def tor_socks(tls=False):
    host = 'validation-example.onion'
    with socket.create_connection((SERVER, 9050), timeout=5) as raw:
        raw.sendall(b'\x05\x01\x00')
        assert exact(raw, 2) == b'\x05\x00'
        raw.sendall(b'\x05\x01\x00\x03' + bytes([len(host)]) + host.encode() + struct.pack('!H', 443 if tls else 80))
        assert exact(raw, 10)[:2] == b'\x05\x00'
        sock = context.wrap_socket(raw, server_hostname=host) if tls else raw
        try:
            sock.sendall(f'GET /validation.exe HTTP/1.1\r\nHost: {host}\r\nConnection: close\r\n\r\n'.encode())
            response = b''
            while part := sock.recv(4096):
                response += part
            assert b'200 OK' in response and b'MZ' in response
        finally:
            if tls:
                sock.close()


def tor_control():
    with socket.create_connection((SERVER, 9051), timeout=5) as sock:
        stream = sock.makefile('rb')
        for command in (b'AUTHENTICATE\r\n', b'GETINFO version\r\n', b'QUIT\r\n'):
            sock.sendall(command)
            lines = []
            while True:
                line = stream.readline()
                assert line.startswith(b'250')
                lines.append(line)
                if line[3:4] == b' ':
                    break
            if command.startswith(b'GETINFO'):
                assert b'0.4.8.10' in b''.join(lines)


def banner():
    with socket.create_connection((SERVER, 22), timeout=5) as sock:
        assert sock.recv(256).startswith(b'SSH-2.0-')


def dummy():
    with socket.create_connection((SERVER, 17), timeout=5) as sock:
        assert b'quick brown fox' in sock.recv(256)
    assert b'quick brown fox' in udp(17, b'benign-vm-probe')


def doh():
    name = b'\x07example\x04test\0'
    query = b'\x12\x34\x01\0\0\x01\0\0\0\0\0\0' + name + b'\0\x01\0\x01'
    client = http.client.HTTPSConnection('example.test', context=context, timeout=5)
    try:
        client.request('POST', '/dns-query', body=query, headers={'Content-Type': 'application/dns-message'})
        response = client.getresponse()
        assert response.status == 200 and response.read().endswith(socket.inet_aton(SERVER))
    finally:
        client.close()


def proxy(tls=False):
    client = http.client.HTTPSConnection(SERVER, 8080, context=context, timeout=8) if tls else http.client.HTTPConnection(SERVER, 8080, timeout=8)
    try:
        if tls:
            client.set_tunnel('example.test', 443)
        client.request('GET', '/validation.exe' if tls else 'http://example.test/validation.exe')
        response = client.getresponse()
        assert response.status == 200 and response.read().startswith(b'MZ')
    finally:
        client.close()


def implicit_mail():
    with smtplib.SMTP_SSL('mx01.corp.local', 465, context=context, timeout=5) as client:
        assert client.sendmail('analyst@example.test', ['sink@example.test'],
                               'Subject: Implicit TLS validation\r\n\r\nBenign implicit TLS mail.\r\n') == {}
    client = poplib.POP3_SSL('mail.corp.local', 995, context=context, timeout=5)
    try:
        client.user('analyst'); client.pass_('vm-test-password')
        assert client.stat()[0] == 1
        assert client.top(1, 1)[1]
        client.dele(1)
        assert client.stat()[0] == 0
        client.rset()
        assert client.stat()[0] == 1
    finally:
        client.quit()


def implicit_ftp():
    with socket.create_connection((SERVER, 990), timeout=5) as raw:
        with context.wrap_socket(raw, server_hostname='ftp.local') as sock:
            stream = sock.makefile('rb')
            assert stream.readline().startswith(b'220')
            for command, code in [(b'USER analyst', b'331'), (b'PASS guest', b'230'),
                                  (b'NOOP', b'200'), (b'QUIT', b'221')]:
                sock.sendall(command + b'\r\n')
                assert stream.readline().startswith(code)


def ftp_large(protected=False, epsv=False, implicit=False):
    class EpsvFtp(ftplib.FTP):
        def makepasv(self):
            return ftplib.parse229(self.sendcmd('EPSV'), self.sock.getpeername())
    class ImplicitFtp(ftplib.FTP_TLS):
        def connect(self, host, port=990):
            self.host = host
            self.port = port
            self.sock = self.context.wrap_socket(socket.create_connection((host, port), timeout=self.timeout), server_hostname=host)
            self.af = self.sock.family
            self.file = self.sock.makefile('r', encoding=self.encoding)
            self.welcome = self.getresp()
            return self.welcome
    if implicit:
        client = ImplicitFtp(context=context, timeout=8)
    else:
        client = ftplib.FTP_TLS(context=context, timeout=8) if protected else (EpsvFtp if epsv else ftplib.FTP)(timeout=8)
    with client:
        client.connect('ftp.local' if protected else SERVER)
        client.login('analyst', 'vm-test-password')
        if protected:
            client.prot_p()
        payload = b'0123456789abcdef' * 16384
        path = f'/fragmented-{int(protected)}-{int(epsv)}.bin'
        client.storbinary('STOR ' + path, io.BytesIO(payload), blocksize=1024,
                         callback=lambda block: time.sleep(.001))
        received = bytearray()
        client.retrbinary('RETR ' + path, received.extend)
        assert received == payload
        listing = []
        client.retrlines('LIST', listing.append)
        assert any(path[1:] in line for line in listing)
        assert client.size(path) == len(payload)


def tftp_blocks():
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.settimeout(5); sock.connect((SERVER, 69))
        sock.send(b'\0\x01large.txt\0octet\0')
        received = bytearray()
        block = 1
        while True:
            data = sock.recv(4096)
            assert data[:4] == struct.pack('!HH', 3, block)
            received.extend(data[4:])
            sock.send(struct.pack('!HH', 4, block))
            if len(data[4:]) < 512:
                break
            block += 1
        assert received == b'0123456789abcdef' * 256
        payload = b'multiblock-tftp-validation-' * 100
        sock.send(b'\0\x02multiblock-upload.bin\0octet\0')
        assert sock.recv(4096) == b'\0\x04\0\0'
        for offset in range(0, len(payload), 512):
            block = offset // 512 + 1
            sock.send(struct.pack('!HH', 3, block) + payload[offset:offset + 512])
            assert sock.recv(4096) == struct.pack('!HH', 4, block)


def socks_variants(socks4=False):
    host = b'validation-example.onion'
    with socket.create_connection((SERVER, 9050), timeout=5) as sock:
        if socks4:
            sock.sendall(b'\x04\x01\0\x50\0\0\0\x01analyst\0' + host + b'\0')
            assert exact(sock, 8)[:2] == b'\0\x5a'
        else:
            sock.sendall(b'\x05\x01\x02')
            assert exact(sock, 2) == b'\x05\x02'
            sock.sendall(b'\x01\x07analyst\x10vm-test-password')
            assert exact(sock, 2) == b'\x01\0'
            sock.sendall(b'\x05\x01\0\x03' + bytes([len(host)]) + host + b'\0\x50')
            assert exact(sock, 10)[:2] == b'\x05\0'
        sock.sendall(b'GET /validation.exe HTTP/1.1\r\nHost: validation-example.onion\r\nConnection: close\r\n\r\n')
        response = b''
        while chunk := sock.recv(4096):
            response += chunk
        assert b'200 OK' in response and b'MZ' in response


def smb_flow():
    with socket.create_connection((SERVER, 445), timeout=5) as sock:
        for message_id, command in enumerate((0, 1, 3, 5, 8, 9, 6, 13, 2), 1):
            header = bytearray(64)
            header[:4] = b'\xfeSMB'; header[4:6] = (64).to_bytes(2, 'little')
            header[12:14] = command.to_bytes(2, 'little')
            header[24:32] = message_id.to_bytes(8, 'little')
            body = bytearray(64)
            if command == 0:
                body[:2] = (36).to_bytes(2, 'little'); body[2:4] = (1).to_bytes(2, 'little')
                body[36:38] = (0x0202).to_bytes(2, 'little')
            frame = bytes(header + body)
            sock.sendall(len(frame).to_bytes(4, 'big') + frame)
            response = exact(sock, int.from_bytes(exact(sock, 4), 'big'))
            assert response[:4] == b'\xfeSMB' and response[8:12] == b'\0' * 4
            assert int.from_bytes(response[24:32], 'little') == message_id


def web_variants():
    extensions = ['exe', 'dll', 'scr', 'zip', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'msi', 'js', 'vbs', 'ps1', 'txt', 'sh', 'py', 'cmd', 'bat', 'elf']
    for tls in (False, True):
        client = http.client.HTTPSConnection('example.test', context=context, timeout=5) if tls else http.client.HTTPConnection('example.test', timeout=5)
        try:
            for extension in extensions:
                client.request('GET', '/validation.' + extension)
                response = client.getresponse()
                body = response.read()
                assert response.status == 200 and body
                assert 'validation.' + extension in response.getheader('Content-Disposition', '')
                if extension in ('exe', 'dll', 'scr'): assert body.startswith(b'MZ')
                if extension in ('zip', 'docx', 'xlsx'): assert body.startswith(b'PK')
                if extension == 'pdf': assert body.startswith(b'%PDF')
                if extension == 'elf': assert body.startswith(b'\x7fELF')
                assert client.sock is not None
            client.request('GET', '/generate_204')
            response = client.getresponse()
            assert response.status == 204 and response.read() == b''
        finally:
            client.close()


def all_banners():
    for port, expected in [(22, b'SSH-2.0-'), (1433, b'Microsoft SQL Server'), (3306, b'MySQL Community Server')]:
        with socket.create_connection((SERVER, port), timeout=5) as sock:
            assert expected in sock.recv(512)


def all_dummy():
    tcp = {7: b'', 9: b'', 13: b'Mon Jan', 17: b'quick brown fox', 19: b'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 113: b'USERID', 514: b''}
    for port, expected in tcp.items():
        with socket.create_connection((SERVER, port), timeout=5) as sock:
            sock.sendall(b'benign-matrix-probe')
            sock.shutdown(socket.SHUT_WR)
            response = sock.recv(512)
            assert expected in response if expected else response == b''
    for port in (7, 9, 13, 17, 19, 514):
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.settimeout(.15); sock.connect((SERVER, port)); sock.send(b'benign-matrix-probe')
            if tcp[port]: assert tcp[port] in sock.recv(512)
            else:
                try: sock.recv(512)
                except socket.timeout: pass
                else: raise ValueError(f'UDP discard port {port} unexpectedly replied')


def short_quic():
    assert len(udp(443, b'\x43benign-short-header')) == 20


for name, operation in [
    ('SMTP STARTTLS with trusted certificate and captured mail', smtp),
    ('POP3 STLS with trusted certificate and mailbox retrieval', pop3),
    ('FTP passive download, upload and retrieval', ftp),
    ('FTP AUTH TLS with trusted certificate', ftp_tls),
    ('SMB direct TCP negotiation', lambda: smb(445)),
    ('SMB NetBIOS negotiation', lambda: smb(139, True)),
    ('NTP reply', ntp), ('TFTP download and upload', tftp),
    ('QUIC sink version negotiation', quic),
    ('Tor SOCKS HTTP emulation', tor_socks),
    ('Tor SOCKS HTTPS with trusted certificate', lambda: tor_socks(True)),
    ('Tor control emulation', tor_control), ('SSH banner', banner),
    ('Dummy TCP and UDP responses', dummy), ('DNS-over-HTTPS', doh),
    ('mitmproxy HTTP synthetic download', proxy),
    ('mitmproxy HTTPS synthetic download with trusted certificate', lambda: proxy(True)),
]:
    check(name, operation)
if args.extended:
    for name, operation in [
        ('SMTP/POP3 implicit TLS and POP3 delete/reset', implicit_mail),
        ('FTP implicit TLS control channel', implicit_ftp),
        ('FTP fragmented 256 KiB upload/download', ftp_large),
        ('FTP EPSV fragmented upload/download', lambda: ftp_large(epsv=True)),
        ('FTPS protected data upload/download/listing', lambda: ftp_large(protected=True)),
        ('Implicit FTPS protected data upload/download/listing', lambda: ftp_large(protected=True, implicit=True)),
        ('TFTP multi-block download and upload', tftp_blocks),
        ('SOCKS4a HTTP emulation', lambda: socks_variants(True)),
        ('SOCKS5 username/password HTTP emulation', socks_variants),
        ('SMB controlled command sequence on one connection', smb_flow),
        ('HTTP/HTTPS keep-alive and all 19 fake download extensions', web_variants),
        ('All three configured TCP banners', all_banners),
        ('All 7 TCP and 6 UDP dummy listeners', all_dummy),
        ('QUIC short-header sink response', short_quic),
    ]:
        check(name, operation)
print(f'{failures} failed protocol checks')
raise SystemExit(bool(failures))
