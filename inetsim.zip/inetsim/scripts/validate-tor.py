#!/usr/bin/env python3
"""Independently probe a lab Tor SOCKS/control emulator, without real Tor circuits."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import http.client
import ipaddress
import json
from pathlib import Path
import platform
import shutil
import socket
import ssl
import struct
import subprocess
import tempfile
import time
import uuid

# RFC 8032 test-vector public key, encoded with Tor's v3 checksum and version.
# This test name is never looked up or contacted on the real Tor network.
ONION = "25njqamcweflpvkl73j4szahhihoc4xt3ktcgjnpaingr5yhkenl5sid.onion"


def exact(sock, count):
    data = bytearray()
    while len(data) < count:
        part = sock.recv(count - len(data))
        if not part:
            raise ValueError("SOCKS reply ended prematurely")
        data.extend(part)
    return bytes(data)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("server", type=ipaddress.IPv4Address)
    parser.add_argument("--socks-port", type=int, default=9050)
    parser.add_argument("--control-port", type=int, default=9051)
    parser.add_argument("--ca", type=Path, help="public lab CA; defaults to OS trust")
    parser.add_argument("--queries", type=int, default=400)
    parser.add_argument("--concurrency", type=int, default=16)
    parser.add_argument("--execute", action="store_true", help="execute the known harmless ELF in this Linux x64 client")
    parser.add_argument("--json", type=Path)
    parser.add_argument("--curl-revoke-best-effort", action="store_true",
                        help="allow missing/offline CRLs in Schannel curl probes; retains CA and hostname checks")
    args = parser.parse_args()
    if args.queries < 1 or args.concurrency < 1 or any(not 1 <= p <= 65535 for p in [args.socks_port, args.control_port]):
        parser.error("query counts, concurrency and ports must be positive and valid")
    if not shutil.which("curl"):
        parser.error("curl is required for independent SOCKS client checks")
    server = str(args.server)
    token = "tor-check-" + uuid.uuid4().hex[:16]
    download_path = "/" + token + ".elf"
    context = ssl.create_default_context(cafile=str(args.ca) if args.ca else None)
    report = {"server": server, "onion": ONION, "token": token, "checks": []}
    report["curl_revoke_best_effort"] = args.curl_revoke_best_effort

    def check(name, operation):
        result = {"name": name, "passed": False}
        try:
            detail = operation()
            result.update({"passed": True, "detail": detail})
            print(f"PASS {name}" + (f": {detail}" if detail else ""), flush=True)
        except Exception as exc:
            result["error"] = f"{type(exc).__name__}: {exc}"
            print(f"FAIL {name}: {result['error']}", flush=True)
        report["checks"].append(result)

    def connect(port=80, host=ONION, auth=False, command=1, optimistic=b"", fragmented=False):
        sock = socket.create_connection((server, args.socks_port), timeout=8)
        try:
            sock.sendall(b"\x05\x01" + (b"\x02" if auth else b"\x00"))
            assert exact(sock, 2) == b"\x05" + (b"\x02" if auth else b"\x00")
            if auth:
                username = (token + "-username").encode()
                password = (token + "-password").encode()
                sock.sendall(b"\x01" + bytes([len(username)]) + username + bytes([len(password)]) + password)
                assert exact(sock, 2) == b"\x01\x00"
            encoded = host.encode()
            request = b"\x05" + bytes([command, 0, 3, len(encoded)]) + encoded + struct.pack("!H", port)
            if fragmented:
                for char in request:
                    sock.sendall(bytes([char]))
                    time.sleep(.001)
            else:
                sock.sendall(request + optimistic)
            reply = exact(sock, 10)
            assert reply[:2] == (b"\x05\x00" if command == 1 else b"\x05\x07"), reply.hex()
            return sock
        except BaseException:
            sock.close()
            raise

    def http_request(tls=False, host=ONION, port=None, method="GET", body=None, path=download_path, auth=False, optimistic=False, fragmented=False):
        port = port if port is not None else 443 if tls else 80
        header = f"{method} {path} HTTP/1.1\r\nHost: {host}\r\nUser-Agent: {token}\r\nConnection: close\r\n"
        if body is not None:
            header += f"Content-Length: {len(body)}\r\n"
        request = (header + "\r\n").encode() + (body or b"")
        sock = connect(port, host, auth=auth, optimistic=request if optimistic else b"", fragmented=fragmented)
        try:
            if tls:
                sock = context.wrap_socket(sock, server_hostname=host)
            if not optimistic:
                sock.sendall(request)
            response = http.client.HTTPResponse(sock, method=method)
            response.begin()
            received = response.read()
            assert response.status == 200, response.status
            if method != "HEAD" and path.split("?", 1)[0].endswith(".elf"):
                assert received.startswith(b"\x7fELF")
            return received
        finally:
            sock.close()

    def curl_request(tls=False, socks4=False, host=ONION):
        url = ("https" if tls else "http") + "://" + host + download_path
        command = ["curl", "--silent", "--show-error", "--fail", "--noproxy", "",
                   "--socks4a" if socks4 else "--socks5-hostname", f"{server}:{args.socks_port}",
                   "--connect-timeout", "5", "--max-time", "15", "--user-agent", token, url]
        if args.ca:
            command += ["--cacert", str(args.ca)]
        if tls and args.curl_revoke_best_effort:
            command.append("--ssl-revoke-best-effort")
        result = subprocess.run(command, capture_output=True, timeout=20)
        if result.returncode:
            raise ValueError(result.stderr.decode(errors="replace").strip())
        assert result.stdout.startswith(b"\x7fELF")
        return result.stdout

    check("curl SOCKS5 remote-name HTTP v3 onion download", lambda: len(curl_request()))
    check("curl SOCKS5 trusted HTTPS v3 onion download", lambda: len(curl_request(tls=True)))
    check("curl SOCKS4a HTTP v3 onion download", lambda: len(curl_request(socks4=True)))
    check("curl SOCKS4a trusted HTTPS v3 onion download", lambda: len(curl_request(tls=True, socks4=True)))
    check("trusted HTTPS onion subdomain longer than CN limit", lambda: len(curl_request(tls=True, host="sub.deep." + ONION)))
    check("SOCKS5 username/password onion HTTP", lambda: len(http_request(auth=True)))
    check("fragmented SOCKS5 CONNECT handshake", lambda: len(http_request(fragmented=True)))
    check("optimistic HTTP sent with CONNECT on port 80", lambda: len(http_request(optimistic=True)))
    check("optimistic plaintext HTTP sent with CONNECT on port 443", lambda: len(http_request(port=443, optimistic=True)))
    check("onion HTTP on an alternate port", lambda: len(http_request(port=8088)))
    check("onion HTTP POST capture", lambda: len(http_request(method="POST", body=(token + "-body").encode(), path="/" + token + "-upload")))
    def head():
        assert http_request(method="HEAD") == b""
        return "empty response body"
    check("onion HTTP HEAD has no response body", head)

    def extensionless():
        body = http_request(path="/validation/stage?" + token)
        assert body == b"#!/usr/bin/env python3\n# Stage completed.\nraise SystemExit(0)\n"
        return sha256(body).hexdigest()
    check("extensionless onion download route", extensionless)

    def reject_untrusted():
        with connect(443) as raw:
            try:
                ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT).wrap_socket(raw, server_hostname=ONION)
            except ssl.SSLCertVerificationError:
                return "untrusted CA correctly rejected"
            raise ValueError("untrusted CA accepted")
    check("HTTPS rejection when CA is untrusted", reject_untrusted)

    for command, label in [(2, "BIND"), (3, "UDP ASSOCIATE"), (0xf0, "Tor RESOLVE extension")]:
        def unsupported(command=command):
            with connect(command=command) as sock:
                assert sock.recv(1) == b""
            return "unsupported command rejected with SOCKS5 code 07"
        check(label + " rejection", unsupported)

    def binary():
        payload = b"\x00\x01\x02" + token.encode()
        with connect(port=9001) as sock:
            sock.sendall(payload)
            assert sock.recv(32) == b""
        report["binary_sha256"] = sha256(payload).hexdigest()
        return "binary stream closed; verify initial payload hash in server log"
    check("unsupported binary stream closes without upstream connection", binary)

    def malformed():
        with socket.create_connection((server, args.socks_port), timeout=5) as sock:
            sock.sendall(b"\x05\x01\x01")
            assert exact(sock, 2) == b"\x05\xff"
        with connect() as sock:
            sock.sendall(b"GET /incomplete")
            sock.shutdown(socket.SHUT_WR)
            assert sock.recv(32) == b""
        assert http_request().startswith(b"\x7fELF")
        return "unsupported auth and truncated HTTP rejected; subsequent valid request succeeds"
    check("malformed connection recovery", malformed)

    def control():
        with socket.create_connection((server, args.control_port), timeout=5) as sock:
            stream = sock.makefile("rb")
            for command, status in [("PROTOCOLINFO 1", b"250"),
                                    ('AUTHENTICATE "' + token + '-control-secret"', b"250"),
                                    ("GETINFO version status/bootstrap-phase net/listeners/socks", b"250"),
                                    ("SIGNAL NEWNYM", b"250"), ("GETINFO unknown/" + token, b"552"), ("QUIT", b"250")]:
                sock.sendall((command + "\r\n").encode())
                while True:
                    line = stream.readline()
                    assert line.startswith(status), line
                    if line[3:4] == b" ":
                        break
        return "control health, authentication redaction input, status and unknown-key handling"
    check("Tor control emulator", control)

    if args.execute:
        def execute():
            if not (platform.system() == "Linux" and platform.machine() in {"x86_64", "amd64"}):
                raise ValueError("--execute requires a Linux x86-64 client")
            from inetsim_py.services.http import fake_download_body
            body = curl_request(tls=True)
            if body != fake_download_body(download_path, "linux_executable")[0]:
                raise ValueError("download differs from known harmless template; execution refused")
            with tempfile.TemporaryDirectory(prefix="onion-download-check-") as directory:
                path = Path(directory) / "stage.elf"
                path.write_bytes(body)
                path.chmod(0o700)
                result = subprocess.run([str(path)], capture_output=True, timeout=5)
                assert result.returncode == 0
            return "trusted HTTPS over SOCKS -> verified ELF -> executed with exit 0"
        check("onion download-and-execute workflow", execute)

    def load():
        started = time.monotonic()
        def one(index):
            try:
                http_request(tls=index % 4 == 0)
                return None
            except Exception as exc:
                return f"{type(exc).__name__}: {exc}"
        with ThreadPoolExecutor(max_workers=args.concurrency) as pool:
            errors = [error for error in pool.map(one, range(args.queries)) if error]
        result = {"queries": args.queries, "concurrency": args.concurrency,
                  "tls_queries": (args.queries + 3) // 4, "failures": len(errors),
                  "seconds": round(time.monotonic() - started, 3), "first_errors": errors[:5]}
        report["load"] = result
        if errors:
            raise ValueError(json.dumps(result))
        return json.dumps(result)
    check("concurrent onion HTTP/HTTPS sessions", load)
    check("onion HTTP still works after load", lambda: len(http_request()))
    failures = sum(not result["passed"] for result in report["checks"])
    report["failures"] = failures
    if args.json:
        args.json.write_text(json.dumps(report, indent=2) + "\n")
    print(f"{failures} failed Tor checks; token={token}")
    return int(bool(failures))


if __name__ == "__main__":
    raise SystemExit(main())
