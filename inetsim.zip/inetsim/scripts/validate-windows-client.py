#!/usr/bin/env python3
"""Validate native Windows networking through an isolated REMnux gateway.

Uses only benign probes. TEST-NET destinations must be intercepted inside the
lab; unsupported traffic must be blocked. Run with the prepared VM configuration.
"""
from __future__ import annotations

import argparse
import base64
from hashlib import sha256
import http.client
import json
import os
from pathlib import Path
import socket
import ssl
import struct
import subprocess
import uuid

from inetsim_py.services.http import fake_download_body


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--server', default='192.168.56.5')
    parser.add_argument('--client', default='192.168.56.20')
    parser.add_argument('--json', type=Path, required=True)
    parser.add_argument('--curl-revoke-best-effort', action='store_true',
                        help='allow missing/offline CRLs in this curl probe; retains CA and hostname verification')
    args = parser.parse_args()
    if os.name != 'nt':
        parser.error('run this validator inside the Windows lab client')
    # These addresses are deliberately fixed to documentation-only TEST-NETs.
    dns_target, http_target, https_target = '198.51.100.53', '198.51.100.77', '203.0.113.88'
    token = 'windows-' + uuid.uuid4().hex[:16]
    host = token + '.test'
    route = '/' + token + '.exe'
    context = ssl.create_default_context()
    report = {'token': token, 'server': args.server, 'client': args.client, 'checks': []}

    def check(name, operation):
        result = {'name': name, 'passed': False}
        try:
            result.update(passed=True, detail=operation())
            print('PASS ' + name, flush=True)
        except Exception as exc:
            result.update(passed=False, error=f'{type(exc).__name__}: {exc}')
            print('FAIL ' + name + ': ' + result['error'], flush=True)
        report['checks'].append(result)

    def powershell(command):
        encoded = base64.b64encode(command.encode('utf-16le')).decode('ascii')
        result = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-EncodedCommand', encoded],
                                capture_output=True, timeout=30)
        if result.returncode:
            raise ValueError(result.stderr.decode(errors='replace')[:1000])
        return result.stdout.decode(errors='replace').strip()

    def network():
        data = json.loads(powershell(
            "$ErrorActionPreference='Stop'; $n=@(Get-NetAdapter | Where-Object Status -eq 'Up'); "
            "$r=@(Get-NetRoute -AddressFamily IPv4 -DestinationPrefix '0.0.0.0/0'); "
            "@{adapters=$n.Count; addresses=@(Get-NetIPAddress -AddressFamily IPv4 | "
            "Where-Object InterfaceIndex -in $n.ifIndex | Select-Object -ExpandProperty IPAddress); "
            "gateways=@($r.NextHop); dns=@(Get-DnsClientServerAddress -AddressFamily IPv4 | "
            "Where-Object InterfaceIndex -in $n.ifIndex | Select-Object -ExpandProperty ServerAddresses)} | ConvertTo-Json -Compress"))
        assert data['adapters'] == 1, data
        assert data['addresses'] == [args.client], data
        assert data['gateways'] == [args.server], data
        assert data['dns'] == [args.server], data
        return data

    def os_dns():
        addresses = sorted({r[4][0] for r in socket.getaddrinfo(host, 80, socket.AF_INET)})
        assert addresses == [args.server], addresses
        return {'name': host, 'answers': addresses}

    def exact(sock, count):
        result = b''
        while len(result) < count:
            part = sock.recv(count - len(result))
            if not part:
                raise ValueError('short DNS response')
            result += part
        return result

    def external_dns(tcp):
        transaction = os.urandom(2)
        name = b''.join(bytes([len(label)]) + label.encode() for label in host.split('.')) + b'\0'
        query = transaction + struct.pack('!5H', 0x100, 1, 0, 0, 0) + name + struct.pack('!HH', 1, 1)
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM if tcp else socket.SOCK_DGRAM) as sock:
            sock.settimeout(5)
            sock.connect((dns_target, 53))
            sock.sendall(struct.pack('!H', len(query)) + query if tcp else query)
            response = exact(sock, int.from_bytes(exact(sock, 2), 'big')) if tcp else sock.recv(65535)
        assert response[:2] == transaction and int.from_bytes(response[6:8], 'big') == 1
        assert response[-4:] == socket.inet_aton(args.server), response.hex()
        return {'requested_dns': dns_target, 'sinkhole_answer': args.server}

    def web(destination, tls, path=route, body=None, trust=context):
        raw = socket.create_connection((destination, 443 if tls else 80), timeout=5)
        connection = http.client.HTTPConnection(host, timeout=5)
        try:
            connection.sock = trust.wrap_socket(raw, server_hostname=host) if tls else raw
            connection.request('POST' if body is not None else 'GET', path, body=body,
                               headers={'Connection': 'close', 'User-Agent': token})
            response = connection.getresponse()
            content = response.read()
            assert response.status == 200, response.status
            if body is None:
                assert content == fake_download_body(path, 'windows_executable')[0]
            return {'requested_ip': destination, 'host': host, 'path': path,
                    'response_sha256': sha256(content).hexdigest()}
        finally:
            connection.close()
            raw.close()

    def reject_untrusted():
        try:
            web(https_target, True, trust=ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT))
        except ssl.SSLCertVerificationError:
            return 'untrusted context rejected the intercepted TLS certificate'
        raise ValueError('untrusted TLS unexpectedly succeeded')

    def blocked(destination):
        try:
            sock = socket.create_connection((destination, 44444), timeout=2)
        except OSError as exc:
            if getattr(exc, 'winerror', None) == 10061:
                raise ValueError('destination answered with a TCP refusal instead of being unreachable') from exc
            return {'destination': destination, 'port': 44444, 'blocked': str(exc)}
        sock.close()
        raise ValueError('unsupported destination was reachable')

    def native_curl():
        command = ['curl.exe', '--noproxy', '*', '--fail', '--silent', '--show-error',
                   '--max-time', '15', '--resolve', f'{host}:443:{https_target}']
        if args.curl_revoke_best_effort:
            command.append('--ssl-revoke-best-effort')
        result = subprocess.run(command + ['https://' + host + route], capture_output=True, timeout=20)
        assert result.returncode == 0, result.stderr.decode(errors='replace')
        assert result.stdout == fake_download_body(route, 'windows_executable')[0]
        return {'sha256': sha256(result.stdout).hexdigest(),
                'curl_revoke_best_effort': args.curl_revoke_best_effort}

    def native_winhttp():
        result = powershell(
            "$ErrorActionPreference='Stop'; $r=New-Object -ComObject WinHttp.WinHttpRequest.5.1; "
            f"$r.SetProxy(1); $r.Open('GET','https://{host}/', $false); $r.Send(); "
            "if($r.Status -ne 200 -or -not $r.ResponseText.Contains('Enterprise sign in')) {throw 'Unexpected response'}; "
            "Write-Output 'WinHTTP TLS and hostname validation passed'")
        assert 'validation passed' in result, result
        return result

    check('one Windows NIC with REMnux as DNS and default gateway', network)
    check('Windows resolver sinkholes a fresh invented name', os_dns)
    check('hard-coded external DNS over UDP is intercepted', lambda: external_dns(False))
    check('hard-coded external DNS over TCP is intercepted', lambda: external_dns(True))
    check('hard-coded external HTTP is intercepted', lambda: web(http_target, False))
    check('hard-coded external HTTPS validates CA and SNI', lambda: web(https_target, True))
    check('untrusted TLS context rejects the lab certificate', reject_untrusted)
    check('Windows curl with Schannel validates intercepted HTTPS', native_curl)
    check('native Windows WinHTTP validates HTTPS through OS trust', native_winhttp)
    check('POST through gateway submits a capturable body',
          lambda: web(http_target, False, '/' + token + '-upload', (token + '-body').encode()))
    check('unsupported off-subnet traffic is blocked', lambda: blocked(http_target))
    check('host-only host address is unreachable from internal network', lambda: blocked('192.168.56.1'))
    report['failures'] = sum(not check['passed'] for check in report['checks'])
    args.json.write_text(json.dumps(report, indent=2) + '\n')
    print(f"{report['failures']} failed Windows client checks; token={token}", flush=True)
    return int(bool(report['failures']))


if __name__ == '__main__':
    raise SystemExit(main())
