#!/usr/bin/env python3
"""Verify Windows TLS revocation and pin enforcement against the managed lab CA."""
from __future__ import annotations

import argparse
import base64
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import socket
import ssl
import subprocess
import tempfile
import uuid

from inetsim_py.services.http import fake_download_body


def spki_der(certificate: bytes) -> bytes:
    """Read the public-key field from a bounded DER certificate, without an SDK."""
    def item(offset):
        start = offset
        if offset + 2 > len(certificate):
            raise ValueError('truncated DER')
        tag, length = certificate[offset:offset + 2]
        offset += 2
        if length & 0x80:
            count = length & 0x7f
            if not 1 <= count <= 4 or offset + count > len(certificate):
                raise ValueError('invalid DER length')
            length = int.from_bytes(certificate[offset:offset + count], 'big')
            offset += count
        end = offset + length
        if end > len(certificate):
            raise ValueError('truncated DER value')
        return tag, start, offset, end
    tag, _, body, end = item(0)
    if tag != 0x30 or end != len(certificate):
        raise ValueError('invalid certificate sequence')
    tag, _, body, _ = item(body)
    if tag != 0x30:
        raise ValueError('invalid certificate body')
    if certificate[body] == 0xa0:
        body = item(body)[3]
    # serial, signature, issuer, validity, subject; then SubjectPublicKeyInfo.
    for _ in range(5):
        body = item(body)[3]
    tag, start, _, end = item(body)
    if tag != 0x30:
        raise ValueError('invalid public-key sequence')
    return certificate[start:end]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--server', default='192.168.56.5')
    parser.add_argument('--host', default='revocation-' + uuid.uuid4().hex[:16] + '.test')
    parser.add_argument('--expect-revoked', action='store_true')
    parser.add_argument('--json', type=Path, required=True)
    args = parser.parse_args()
    if os.name != 'nt':
        parser.error('run this validator inside the native Windows client')
    if not re.fullmatch(r'[a-z0-9.-]+', args.host):
        parser.error('use an ASCII lab hostname')
    context = ssl.create_default_context()
    # Python's standard context verifies chain/name, not revocation. Windows
    # curl and certutil below independently enforce revocation with no bypass.
    with socket.create_connection((args.server, 443), timeout=10) as raw:
        with context.wrap_socket(raw, server_hostname=args.host) as tls:
            cert = tls.getpeercert(binary_form=True)
            serial = tls.getpeercert()['serialNumber']
    pin = 'sha256//' + base64.b64encode(sha256(spki_der(cert)).digest()).decode()
    crl_url = f'http://{args.server}/pki/lab-ca.crl'
    report = {'host': args.host, 'serial': serial, 'pin': pin, 'crl_url': crl_url,
              'expect_revoked': args.expect_revoked, 'checks': []}

    def check(name, operation):
        result = {'name': name, 'passed': False}
        try:
            result.update(passed=True, detail=operation())
            print('PASS ' + name, flush=True)
        except Exception as exc:
            result.update(passed=False, error=f'{type(exc).__name__}: {exc}')
            print('FAIL ' + name + ': ' + result['error'], flush=True)
        report['checks'].append(result)

    def curl(extra=()):
        return subprocess.run(['curl.exe', '--noproxy', '*', '--silent', '--show-error', '--fail',
                               '--max-time', '20', *extra, 'https://' + args.host + '/workflow.exe'],
                              capture_output=True, timeout=25)

    # Request fresh revocation information for the deliberate revoke test.
    subprocess.run(['certutil.exe', '-urlcache', crl_url, 'delete'], capture_output=True, timeout=20)

    def normal_curl():
        result = curl()
        error = result.stderr.decode(errors='replace')
        if args.expect_revoked:
            assert result.returncode != 0 and re.search(r'revoked|0x80092010|0x80090350|0x800b010c', error, re.I), error
            return {'exit_code': result.returncode, 'error': error.strip()}
        assert result.returncode == 0, error
        assert result.stdout == fake_download_body('/workflow.exe', 'windows_executable')[0]
        return {'exit_code': 0, 'sha256': sha256(result.stdout).hexdigest()}
    check('default Windows curl enforces revoked certificate' if args.expect_revoked else
          'default Windows curl validates HTTPS without revocation bypass flags', normal_curl)

    with tempfile.TemporaryDirectory(prefix='lab-revocation-') as directory:
        path = Path(directory) / 'leaf.cer'
        path.write_bytes(cert)
        def certutil():
            result = subprocess.run(['certutil.exe', '-verify', '-urlfetch', str(path)],
                                    capture_output=True, timeout=40)
            text = (result.stdout + result.stderr).decode(errors='replace')
            revoked = bool(re.search(r'Leaf certificate is REVOKED|Certificate is REVOKED|0x80092010', text, re.I))
            if args.expect_revoked:
                # certutil can report a revoked leaf yet return process exit 0.
                assert revoked, text[-2000:]
            else:
                assert result.returncode == 0 and not revoked, text[-2000:]
            return {'exit_code': result.returncode, 'output': text}
        check('Windows certutil rejects revoked leaf' if args.expect_revoked else
              'Windows certutil verifies chain and fetches valid revocation data', certutil)

    if not args.expect_revoked:
        def matching_pin():
            result = curl(['--pinnedpubkey', pin])
            assert result.returncode == 0, result.stderr.decode(errors='replace')
            return 'the owned lab key matches the explicit client pin'
        def mismatched_pin():
            bad = 'sha256//' + base64.b64encode(sha256(b'a different endpoint key').digest()).decode()
            result = curl(['--pinnedpubkey', bad])
            assert result.returncode == 90, (result.returncode, result.stderr.decode(errors='replace'))
            return 'curl rejected a different pinned key despite trusted CA and valid CRL'
        check('matching public-key pin succeeds with the owned lab identity', matching_pin)
        check('mismatched public-key pin remains enforced', mismatched_pin)
    report['failures'] = sum(not entry['passed'] for entry in report['checks'])
    args.json.write_text(json.dumps(report, indent=2) + '\n')
    print(f"{report['failures']} failed revocation checks; host={args.host}")
    return int(bool(report['failures']))


if __name__ == '__main__':
    raise SystemExit(main())
