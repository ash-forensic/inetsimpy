"""Modern, subnet-aware network service simulator."""

__version__ = "0.1.0"
