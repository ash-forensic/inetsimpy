from __future__ import annotations

from ipaddress import ip_address, ip_network


class SubnetAcl:
    """Small allow-list wrapper for client source IP checks."""

    def __init__(self, networks: list[str]) -> None:
        self._networks = [ip_network(item, strict=False) for item in networks]

    def allows(self, address: str) -> bool:
        ip = ip_address(address)
        if ip.version == 6 and ip.ipv4_mapped is not None:
            ip = ip.ipv4_mapped
        return any(ip in network for network in self._networks)
