from __future__ import annotations

from hashlib import sha256
from pathlib import Path
import contextlib
import re

SAFE_ARTIFACT_PART_RE = re.compile(r"^[A-Za-z0-9_.-]+$")


class ArtifactStore:
    def __init__(self, root: Path, max_bytes: int | None = None) -> None:
        self._root = root
        self._max_bytes = max_bytes
        self._root.mkdir(parents=True, exist_ok=True)
        _assert_writable_directory(self._root)

    def save(self, category: str, data: bytes, suffix: str = ".bin") -> dict[str, str | int | bool]:
        digest = sha256(data).hexdigest()
        size = len(data)
        if self._max_bytes is not None and size > self._max_bytes:
            return {"sha256": digest, "size": size, "captured": False, "limit": self._max_bytes}
        directory = artifact_category_path(self._root, category)
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / artifact_filename(digest, suffix)
        if not path.exists():
            path.write_bytes(data)
        return {"sha256": digest, "size": size, "captured": True, "path": str(path)}


def artifact_category_path(root: Path, category: str) -> Path:
    parts = safe_artifact_category_parts(category)
    return root.joinpath(*parts)


def safe_artifact_category_parts(category: str) -> list[str]:
    if not isinstance(category, str):
        raise ValueError("artifact category must be a string")
    parts = category.split("/")
    if not parts or any(not _safe_artifact_part(part) for part in parts):
        raise ValueError(f"invalid artifact category {category!r}")
    return parts


def artifact_filename(digest: str, suffix: str) -> str:
    if not isinstance(suffix, str) or not suffix.startswith(".") or "/" in suffix or "\\" in suffix:
        raise ValueError(f"invalid artifact suffix {suffix!r}")
    if not _safe_artifact_part(suffix[1:]):
        raise ValueError(f"invalid artifact suffix {suffix!r}")
    return f"{digest}{suffix}"


def _safe_artifact_part(value: str) -> bool:
    return value not in {"", ".", ".."} and bool(SAFE_ARTIFACT_PART_RE.fullmatch(value))


def _assert_writable_directory(path: Path) -> None:
    probe = path / ".write-test"
    try:
        with probe.open("a", encoding="utf-8"):
            pass
    finally:
        with contextlib.suppress(OSError):
            probe.unlink()
