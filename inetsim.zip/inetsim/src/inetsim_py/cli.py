from __future__ import annotations

import argparse
import asyncio
import contextlib
from dataclasses import dataclass, field
from ipaddress import ip_interface, ip_network
import json
from pathlib import Path
import shutil
import signal
import socket
import ssl
import struct
import subprocess
import sys

from . import __version__
from .config import DEFAULT_CONFIG_TOML, ConfigValidationError, load_config, validate_config
from .runner import InetSimPy


@dataclass(frozen=True, slots=True)
class InterfaceNetwork:
    name: str
    address: str
    cidr: str


class InterfaceDetectionError(Exception):
    pass


class DnsManagementError(Exception):
    pass


class TrustManagementError(Exception):
    pass


class TransparentProxyError(Exception):
    pass


@dataclass(frozen=True, slots=True)
class ResolvedDnsOverride:
    interface_name: str
    dns_server: str

    def apply(self) -> None:
        _run_resolvectl(["dns", self.interface_name, self.dns_server])
        _run_resolvectl(["domain", self.interface_name, "~."])
        _flush_resolved_caches()

    def revert(self) -> bool:
        _run_resolvectl(["revert", self.interface_name])
        _flush_resolved_caches()
        refreshed = _reapply_network_manager_device(self.interface_name)
        if refreshed:
            _flush_resolved_caches()
        return refreshed


@dataclass(slots=True)
class MitmCaTrustOverride:
    source_ca: Path
    trust_store_ca: Path = Path("/usr/local/share/ca-certificates/inetsim-py-mitmproxy.crt")
    update_command: str = "update-ca-certificates"
    wait_seconds: float = 10.0
    _original_bytes: bytes | None = field(default=None, init=False)
    _original_mode: int | None = field(default=None, init=False)
    _installed: bool = field(default=False, init=False)

    async def apply(self) -> None:
        source_ca = await _wait_for_file(self.source_ca, self.wait_seconds)
        update_command = _trust_update_command(self.update_command)
        self.trust_store_ca.parent.mkdir(parents=True, exist_ok=True)
        if self.trust_store_ca.exists():
            self._original_bytes = self.trust_store_ca.read_bytes()
            self._original_mode = self.trust_store_ca.stat().st_mode & 0o777
        else:
            self._original_bytes = None
            self._original_mode = None
        try:
            shutil.copyfile(source_ca, self.trust_store_ca)
            self.trust_store_ca.chmod(0o644)
            self._installed = True
            _run_trust_update(update_command)
        except Exception:
            with contextlib.suppress(Exception):
                self.revert()
            raise

    def revert(self) -> None:
        if not self._installed:
            return
        update_command = _trust_update_command(self.update_command)
        if self._original_bytes is None:
            self.trust_store_ca.unlink(missing_ok=True)
        else:
            self.trust_store_ca.write_bytes(self._original_bytes)
            if self._original_mode is not None:
                self.trust_store_ca.chmod(self._original_mode)
        _run_trust_update(update_command)
        self._installed = False


@dataclass(frozen=True, slots=True)
class TransparentProxyOverride:
    http_port: int
    https_port: int
    quic_port: int | None = None
    use_mitmproxy: bool = False
    router_mode: bool = False
    interface_name: str | None = None
    source_cidrs: tuple[str, ...] = ()

    def apply(self) -> None:
        applied: list[list[str]] = []
        try:
            for rule in self._rules("-A"):
                _run_iptables(rule)
                applied.append(rule)
        except Exception:
            for rule in reversed(applied):
                with contextlib.suppress(Exception):
                    _run_iptables(_delete_rule(rule), allow_missing=True)
            raise

    def revert(self) -> None:
        for rule in self._rules("-D"):
            _run_iptables(rule, allow_missing=True)

    def _rules(self, operation: str) -> list[list[str]]:
        chain = "PREROUTING" if self.router_mode else "OUTPUT"
        rules = [
            self._redirect_rules(operation, chain, "tcp", "80", self.http_port),
            self._redirect_rules(operation, chain, "tcp", "443", self.https_port),
        ]
        if self.quic_port is not None:
            rules.append(self._redirect_rules(operation, chain, "udp", "443", self.quic_port))
        return [rule for group in rules for rule in group]

    def _redirect_rules(self, operation: str, chain: str, protocol: str, dport: str, target_port: int) -> list[list[str]]:
        sources = self.source_cidrs or ("",)
        direction = "-i" if self.router_mode else "-o"
        rules = []
        for source in sources:
            rule = ["-t", "nat", operation, chain]
            if self.interface_name:
                rule.extend([direction, self.interface_name])
            if source:
                rule.extend(["-s", source])
            rule.extend(["-p", protocol, "--dport", dport, "-j", "REDIRECT", "--to-ports", str(target_port)])
            rules.append(rule)
        return rules




def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Subnet-aware network service simulator for analysis labs.")
    parser.add_argument("--config", "-c", help="Path to TOML config. Built-in safe loopback defaults are used when omitted.")
    parser.add_argument("--interface", "-i", help="Detect IPv4/CIDR from this interface and override listen_host, allowed_clients, and DNS sinkhole_ip.")
    parser.add_argument("--manage-dns", action="store_true", help="During run, point systemd-resolved DNS for --interface at the simulator and revert on exit.")
    parser.add_argument("--trust-mitm-ca", action="store_true", help="During run, install the managed mitmproxy CA into the local OS trust store and remove it on exit.")
    parser.add_argument("--trust-https-ca", action="store_true", help="During run, install the built-in HTTPS lab CA into the local OS trust store and remove it on exit.")
    parser.add_argument("--transparent-proxy", action="store_true", help="During run, redirect local outbound TCP/80 and TCP/443 to the simulator with iptables and revert on exit.")
    parser.add_argument("--transparent-router", action="store_true", help="During run, redirect forwarded TCP/80 and TCP/443 to the simulator with iptables PREROUTING rules and revert on exit.")
    parser.add_argument("--transparent-interface", help="Limit transparent iptables rules to this interface. Defaults to --interface when provided.")
    parser.add_argument("--transparent-source", action="append", default=[], metavar="CIDR", help="Limit transparent iptables rules to this IPv4 source CIDR. May be repeated.")
    subcommands = parser.add_subparsers(dest="command")
    subcommands.add_parser("run", help="Run enabled services.")
    subcommands.add_parser("doctor", help="Probe configured DNS, HTTP, and HTTPS listeners on this host.")
    subcommands.add_parser("restore-dns", help="Revert managed DNS for --interface and ask NetworkManager to refresh the link.")
    subcommands.add_parser("restore-transparent", help="Remove iptables transparent proxy rules for the current config.")
    subcommands.add_parser("check-config", help="Parse config and print enabled service summary.")
    subcommands.add_parser("print-default-config", help="Print the built-in TOML configuration.")
    parser.set_defaults(command="run")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command == "print-default-config":
        print(DEFAULT_CONFIG_TOML, end="")
        return 0

    try:
        config = load_config(args.config)
        if args.interface:
            apply_interface_network(config, detect_interface_network(args.interface))
        validate_config(config)
    except ConfigValidationError as exc:
        print("configuration is invalid:", file=sys.stderr)
        for error in exc.errors:
            print(f"- {error}", file=sys.stderr)
        return 2
    except InterfaceDetectionError as exc:
        print(f"interface detection failed: {exc}", file=sys.stderr)
        return 2
    except DnsManagementError as exc:
        print(f"dns management failed: {exc}", file=sys.stderr)
        return 2
    if args.command == "check-config":
        _print_summary(config)
        return 0
    if args.command == "doctor":
        return _doctor(config)
    if args.transparent_proxy and args.transparent_router:
        print("use only one of --transparent-proxy or --transparent-router", file=sys.stderr)
        return 2
    if args.command == "restore-dns":
        if not args.interface:
            print("restore-dns requires --interface", file=sys.stderr)
            return 2
        try:
            refreshed = ResolvedDnsOverride(args.interface, config.dns.sinkhole_ip).revert()
        except DnsManagementError as exc:
            print(f"dns management failed: {exc}", file=sys.stderr)
            return 2
        print(f"managed dns: reverted {args.interface}", file=sys.stderr)
        if refreshed:
            print(f"managed dns: refreshed NetworkManager settings for {args.interface}", file=sys.stderr)
        return 0
    if args.command == "restore-transparent":
        try:
            source_cidrs = _transparent_source_cidrs(args.transparent_source, config, args.transparent_router)
            _transparent_override_for_config(
                config,
                router_mode=args.transparent_router,
                interface_name=args.transparent_interface or args.interface,
                source_cidrs=source_cidrs,
            ).revert()
        except TransparentProxyError as exc:
            print(f"transparent proxy cleanup failed: {exc}", file=sys.stderr)
            return 2
        except ValueError as exc:
            print(f"transparent proxy cleanup failed: {exc}", file=sys.stderr)
            return 2
        print("transparent proxy: rules removed", file=sys.stderr)
        return 0

    dns_override = None
    if args.manage_dns:
        if not args.interface:
            print("--manage-dns requires --interface", file=sys.stderr)
            return 2
        dns_override = ResolvedDnsOverride(args.interface, config.dns.sinkhole_ip)

    ca_trust_override = None
    if args.trust_mitm_ca:
        if not config.mitmproxy.enabled:
            print("--trust-mitm-ca requires services.mitmproxy.enabled = true", file=sys.stderr)
            return 2
        ca_trust_override = MitmCaTrustOverride(config.global_.artifact_dir / "mitmproxy" / "conf" / "mitmproxy-ca-cert.pem")

    https_ca_trust_override = None
    if args.trust_https_ca:
        if not config.https.enabled:
            print("--trust-https-ca requires services.https.enabled = true", file=sys.stderr)
            return 2
        if config.https.cert_file is not None or config.https.key_file is not None or not config.https.auto_generate_cert:
            print("--trust-https-ca requires auto-generated HTTPS certificates; install your configured CA/cert manually for custom cert_file/key_file", file=sys.stderr)
            return 2
        https_ca_trust_override = MitmCaTrustOverride(
            config.global_.artifact_dir / "tls" / "inetsim-ca.crt",
            Path("/usr/local/share/ca-certificates/inetsim-py-https-ca.crt"),
        )

    transparent_sources: tuple[str, ...] = ()
    if args.transparent_proxy or args.transparent_router:
        try:
            transparent_sources = _transparent_source_cidrs(args.transparent_source, config, args.transparent_router)
        except ValueError as exc:
            print(f"transparent proxy failed: {exc}", file=sys.stderr)
            return 2
    transparent_override = (
        _transparent_override_for_config(
            config,
            router_mode=args.transparent_router,
            interface_name=args.transparent_interface or args.interface,
            source_cidrs=transparent_sources,
        )
        if (args.transparent_proxy or args.transparent_router)
        else None
    )
    if (args.transparent_proxy or args.transparent_router) and config.mitmproxy.enabled and config.mitmproxy.mode != "transparent":
        print(
            "transparent proxying with mitmproxy requires services.mitmproxy.mode = \"transparent\"; "
            "disable mitmproxy or use built-in HTTPS for TCP/443 redirection",
            file=sys.stderr,
        )
        return 2

    if args.interface:
        _warn_interface_lab_ports(config)
    try:
        return asyncio.run(_run(config, dns_override, ca_trust_override, https_ca_trust_override, transparent_override))
    except DnsManagementError as exc:
        print(f"dns management failed: {exc}", file=sys.stderr)
        return 2
    except TrustManagementError as exc:
        print(f"trust management failed: {exc}", file=sys.stderr)
        return 2
    except TransparentProxyError as exc:
        print(f"transparent proxy failed: {exc}", file=sys.stderr)
        return 2


async def _run(
    config,
    dns_override: ResolvedDnsOverride | None = None,
    ca_trust_override: MitmCaTrustOverride | None = None,
    https_ca_trust_override: MitmCaTrustOverride | None = None,
    transparent_override: TransparentProxyOverride | None = None,
) -> int:
    app = InetSimPy(config)
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    shutdown_reason = ""

    def request_shutdown(reason: str) -> None:
        nonlocal shutdown_reason
        if not shutdown_reason:
            shutdown_reason = reason
            print(f"received {reason}; shutting down", file=sys.stderr)
        stop.set()

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, request_shutdown, sig.name)
        except NotImplementedError:
            pass

    dns_applied = False
    dns_reverted = False
    ca_trust_applied = False
    ca_trust_reverted = False
    https_ca_trust_applied = False
    https_ca_trust_reverted = False
    transparent_applied = False
    transparent_reverted = False

    def revert_dns() -> None:
        nonlocal dns_reverted
        if dns_override is None or not dns_applied or dns_reverted:
            return
        try:
            refreshed = dns_override.revert()
            dns_reverted = True
            print(f"managed dns: reverted {dns_override.interface_name}", file=sys.stderr)
            if refreshed:
                print(f"managed dns: refreshed NetworkManager settings for {dns_override.interface_name}", file=sys.stderr)
        except DnsManagementError as exc:
            print(f"warning: failed to revert managed dns for {dns_override.interface_name}: {exc}", file=sys.stderr)

    def revert_ca_trust() -> None:
        nonlocal ca_trust_reverted
        if ca_trust_override is None or not ca_trust_applied or ca_trust_reverted:
            return
        try:
            ca_trust_override.revert()
            ca_trust_reverted = True
            print(f"managed trust: removed mitmproxy CA {ca_trust_override.trust_store_ca}", file=sys.stderr)
        except TrustManagementError as exc:
            print(f"warning: failed to remove managed mitmproxy CA {ca_trust_override.trust_store_ca}: {exc}", file=sys.stderr)

    def revert_https_ca_trust() -> None:
        nonlocal https_ca_trust_reverted
        if https_ca_trust_override is None or not https_ca_trust_applied or https_ca_trust_reverted:
            return
        try:
            https_ca_trust_override.revert()
            https_ca_trust_reverted = True
            print(f"managed trust: removed HTTPS lab CA {https_ca_trust_override.trust_store_ca}", file=sys.stderr)
        except TrustManagementError as exc:
            print(f"warning: failed to remove HTTPS lab CA {https_ca_trust_override.trust_store_ca}: {exc}", file=sys.stderr)

    def revert_transparent() -> None:
        nonlocal transparent_reverted
        if transparent_override is None or not transparent_applied or transparent_reverted:
            return
        try:
            transparent_override.revert()
            transparent_reverted = True
            print("transparent proxy: rules removed", file=sys.stderr)
        except TransparentProxyError as exc:
            print(f"warning: failed to remove transparent proxy rules: {exc}", file=sys.stderr)

    if dns_override is not None:
        try:
            dns_override.apply()
            dns_applied = True
            print(f"managed dns: {dns_override.interface_name} -> {dns_override.dns_server}", file=sys.stderr)
        except DnsManagementError:
            try:
                dns_override.revert()
            except DnsManagementError:
                pass
            raise
    try:
        if transparent_override is not None:
            transparent_override.apply()
            transparent_applied = True
            scope = "forwarded" if transparent_override.router_mode else "local outbound"
            print(f"transparent proxy: {scope} tcp/80 and tcp/443 redirects installed", file=sys.stderr)
        _print_startup_banner(config)
        running = await app.start()
        for service in running:
            _print_service_started(service)
            for note in service.notes:
                _print_service_note(note)
        if ca_trust_override is not None:
            await ca_trust_override.apply()
            ca_trust_applied = True
            _print_runtime_message(f"managed trust installed mitmproxy CA {ca_trust_override.trust_store_ca}")
        if https_ca_trust_override is not None:
            await https_ca_trust_override.apply()
            https_ca_trust_applied = True
            _print_runtime_message(f"managed trust installed HTTPS lab CA {https_ca_trust_override.trust_store_ca}")
        _print_runtime_message("simulation services ready")
        await stop.wait()
        revert_https_ca_trust()
        revert_ca_trust()
        revert_transparent()
        revert_dns()
        return 0
    finally:
        await app.stop()
        revert_https_ca_trust()
        revert_ca_trust()
        revert_transparent()
        revert_dns()
        cleanup_runtime_caches()


def _print_summary(config) -> None:
    print(f"listen_host={config.global_.listen_host}")
    print(f"allowed_clients={','.join(config.global_.allowed_clients)}")
    print(f"fake_time_utc={config.global_.fake_time_utc}")
    print(
        f"dns={config.dns.enabled} udp={config.dns.udp_port} tcp={config.dns.tcp_port} "
        f"sinkhole_ip={config.dns.sinkhole_ip} sinkhole_ipv4={config.dns.sinkhole_ipv4 or ''} sinkhole_ipv6={config.dns.sinkhole_ipv6 or ''}"
    )
    print(f"ntp={config.ntp.enabled} udp={config.ntp.port} stratum={config.ntp.stratum}")
    print(f"tftp={config.tftp.enabled} udp={config.tftp.port} files={len(config.tftp.files)} allow_uploads={config.tftp.allow_uploads}")
    print(f"http={config.http.enabled} port={config.http.port} fake_downloads={config.http.fake_downloads_enabled} fake_extensions={len(config.http.fake_download_extensions)}")
    print(f"https={config.https.enabled} port={config.https.port} auto_cert={config.https.auto_generate_cert}")
    print(f"smtp={config.smtp.enabled} port={config.smtp.port}")
    print(
        f"ftp={config.ftp.enabled} port={config.ftp.port} files={len(config.ftp.files)} "
        f"allow_uploads={config.ftp.allow_uploads} persist_uploads={config.ftp.persist_uploads} upload_index={config.ftp.upload_index}"
    )
    print(f"pop3={config.pop3.enabled} port={config.pop3.port} hostname={config.pop3.hostname}")
    print(f"smb={config.smb.enabled} port={config.smb.port} netbios_port={config.smb.netbios_port} server_name={config.smb.server_name} workgroup={config.smb.workgroup}")
    allow_hosts = ",".join(config.mitmproxy.allow_upstream_hosts)
    print(f"mitmproxy={config.mitmproxy.enabled} port={config.mitmproxy.port} block_upstream={config.mitmproxy.block_upstream} allow_upstream_hosts={allow_hosts}")
    print(f"quic={config.quic.enabled} udp={config.quic.port} send_close={config.quic.send_close} block={config.quic.block}")
    print(f"tor_socks={config.tor_socks.enabled} port={config.tor_socks.port}")
    print(f"tor_control={config.tor_control.enabled} port={config.tor_control.port} version={config.tor_control.version}")
    ports = ",".join(str(port) for port in sorted(config.tcp_banners.ports))
    print(f"tcp_banners={config.tcp_banners.enabled} ports={ports}")
    dummy_tcp = ",".join(str(port) for port in sorted(config.dummy.tcp_ports))
    dummy_udp = ",".join(str(port) for port in sorted(config.dummy.udp_ports))
    print(f"dummy={config.dummy.enabled} tcp_ports={dummy_tcp} udp_ports={dummy_udp}")


def _print_startup_banner(config) -> None:
    print("", file=sys.stderr)
    print("=== INetSim-Py ==================================================", file=sys.stderr)
    print(f"Version        : {__version__}", file=sys.stderr)
    print(f"Listen address : {config.global_.listen_host}", file=sys.stderr)
    print(f"Allowed clients: {','.join(config.global_.allowed_clients)}", file=sys.stderr)
    if config.global_.fake_time_utc:
        print(f"Fake time      : {config.global_.fake_time_utc}", file=sys.stderr)
    print(f"Log directory  : {config.global_.log_dir}", file=sys.stderr)
    print(f"Data directory : {config.global_.artifact_dir}", file=sys.stderr)
    print("Services       :", file=sys.stderr)


def _print_service_started(service) -> None:
    print(f"  {service.name:<14} started", file=sys.stderr)


def _print_service_note(note: str) -> None:
    print(f"    note: {note}", file=sys.stderr)


def _print_runtime_message(message: str) -> None:
    print(f"  {'runtime':<14} {message}", file=sys.stderr)


def _warn_interface_lab_ports(config) -> None:
    dns_standard = not config.dns.enabled or (config.dns.udp_port == 53 and config.dns.tcp_port == 53)
    http_standard = not config.http.enabled or config.http.port == 80
    https_standard = not config.https.enabled or config.https.port == 443
    if dns_standard and http_standard and https_standard:
        return

    mismatches = []
    if config.dns.enabled and not dns_standard:
        mismatches.append(f"dns udp/tcp={config.dns.udp_port}/{config.dns.tcp_port}")
    if config.http.enabled and not http_standard:
        mismatches.append(f"http={config.http.port}")
    if config.https.enabled and not https_standard:
        mismatches.append(f"https={config.https.port}")
    print(
        "warning: --interface detected the bind IP/CIDR, but this config is not using standard lab ports "
        f"({', '.join(mismatches)}). "
        "Browsers and specimens normally use DNS 53, HTTP 80, and HTTPS 443; use --config configs/lab-subnet.toml "
        "or set those ports if you expect normal client traffic to hit the simulator.",
        file=sys.stderr,
    )


def cleanup_runtime_caches() -> None:
    project_root = Path(__file__).resolve().parents[2]
    cache_dirs = [project_root / "__pycache__"]
    for child in (project_root / "src", project_root / "tests"):
        if child.exists():
            cache_dirs.extend(child.glob("**/__pycache__"))
    for cache_dir in cache_dirs:
        shutil.rmtree(cache_dir, ignore_errors=True)


def _run_resolvectl(args: list[str]) -> None:
    try:
        result = subprocess.run(["resolvectl", *args], check=False, capture_output=True, text=True)
    except FileNotFoundError as exc:
        raise DnsManagementError("could not find the 'resolvectl' command; systemd-resolved DNS management is unavailable") from exc
    if result.returncode != 0:
        reason = result.stderr.strip() or result.stdout.strip() or f"resolvectl exited with status {result.returncode}"
        raise DnsManagementError(f"resolvectl {' '.join(args)} failed: {reason}")


def _flush_resolved_caches() -> None:
    _run_resolvectl(["flush-caches"])


def _reapply_network_manager_device(interface_name: str) -> bool:
    nmcli = shutil.which("nmcli")
    if nmcli is None:
        return False
    result = subprocess.run([nmcli, "device", "reapply", interface_name], check=False, capture_output=True, text=True)
    return result.returncode == 0


async def _wait_for_file(path: Path, timeout_seconds: float) -> Path:
    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout_seconds
    while True:
        if path.is_file():
            return path
        if loop.time() >= deadline:
            raise TrustManagementError(f"timed out waiting for mitmproxy CA file {path}")
        await asyncio.sleep(0.1)


def _trust_update_command(command: str) -> str:
    path = shutil.which(command)
    if path is None:
        raise TrustManagementError(f"could not find {command!r}; this CA trust workflow currently requires Debian/Ubuntu update-ca-certificates")
    return path


def _run_trust_update(command: str) -> None:
    result = subprocess.run([command], check=False, capture_output=True, text=True)
    if result.returncode != 0:
        reason = result.stderr.strip() or result.stdout.strip() or f"{command} exited with status {result.returncode}"
        raise TrustManagementError(f"{command} failed: {reason}")


def _transparent_override_for_config(
    config,
    router_mode: bool = False,
    interface_name: str | None = None,
    source_cidrs: tuple[str, ...] = (),
) -> TransparentProxyOverride:
    use_mitmproxy = config.mitmproxy.enabled and config.mitmproxy.mode == "transparent"
    https_port = config.mitmproxy.port if use_mitmproxy else config.https.port
    quic_port = config.quic.port if getattr(config, "quic", None) and config.quic.enabled else None
    return TransparentProxyOverride(config.http.port, https_port, quic_port, use_mitmproxy, router_mode, interface_name, source_cidrs)


def _transparent_source_cidrs(explicit_sources: list[str], config, router_mode: bool) -> tuple[str, ...]:
    values = explicit_sources if explicit_sources else (_ipv4_allowed_clients(config) if router_mode else [])
    seen: set[str] = set()
    cidrs: list[str] = []
    for value in values:
        try:
            network = ip_network(value, strict=False)
        except ValueError as exc:
            raise ValueError(f"invalid --transparent-source {value!r}: {exc}") from exc
        if network.version != 4:
            raise ValueError(f"--transparent-source only supports IPv4 CIDRs with iptables: {value!r}")
        normalized = str(network)
        if normalized not in seen:
            seen.add(normalized)
            cidrs.append(normalized)
    return tuple(cidrs)


def _ipv4_allowed_clients(config) -> list[str]:
    values = []
    for value in config.global_.allowed_clients:
        with contextlib.suppress(ValueError):
            network = ip_network(value, strict=False)
            if network.version == 4:
                values.append(str(network))
    return values


def _run_iptables(args: list[str], allow_missing: bool = False) -> None:
    iptables = shutil.which("iptables")
    if iptables is None:
        raise TransparentProxyError("could not find the 'iptables' command")
    result = subprocess.run([iptables, *args], check=False, capture_output=True, text=True)
    if result.returncode == 0:
        return
    reason = result.stderr.strip() or result.stdout.strip() or f"iptables exited with status {result.returncode}"
    if allow_missing and ("No chain/target/match" in reason or "Bad rule" in reason or "does a matching rule exist" in reason):
        return
    raise TransparentProxyError(f"iptables {' '.join(args)} failed: {reason}")


def _delete_rule(rule: list[str]) -> list[str]:
    delete = list(rule)
    for index, value in enumerate(delete):
        if value == "-A":
            delete[index] = "-D"
            return delete
    return delete


def _doctor(config) -> int:
    issues = 0
    print("effective configuration:")
    _print_summary(config)
    print()

    if config.dns.enabled:
        issues += _probe_dns(config.global_.listen_host, config.dns.udp_port, "example.test")
    else:
        print("dns: disabled")

    if config.http.enabled:
        issues += _probe_http(config.global_.listen_host, config.http.port, "example.test")
    else:
        print("http: disabled")

    if config.https.enabled:
        issues += _probe_https(config.global_.listen_host, config.https.port, "example.test")
    else:
        print("https: disabled")

    if issues:
        print()
        print("doctor: one or more local probes failed. If services are not running, start them in another terminal and rerun doctor.")
        return 1

    print()
    print("doctor: local DNS, HTTP, and HTTPS probes passed. If a browser still fails, check the client DNS server, Firefox DNS-over-HTTPS, local firewall rules, and Wi-Fi client isolation.")
    return 0


def _probe_dns(host: str, port: int, query_name: str) -> int:
    try:
        response = _udp_dns_query(host, port, query_name)
        if len(response) < 12:
            raise OSError("short DNS response")
        rcode = response[3] & 0x0F
        ancount = struct.unpack("!H", response[6:8])[0]
        if rcode != 0 or ancount < 1:
            print(f"dns: failed query={query_name} rcode={rcode} answers={ancount}")
            return 1
        print(f"dns: ok udp={host}:{port} query={query_name} answers={ancount}")
        return 0
    except OSError as exc:
        print(f"dns: failed udp={host}:{port} query={query_name} error={exc}")
        return 1


def _udp_dns_query(host: str, port: int, query_name: str) -> bytes:
    query = _build_dns_query(query_name)
    family = socket.AF_INET6 if ":" in host else socket.AF_INET
    with socket.socket(family, socket.SOCK_DGRAM) as sock:
        sock.settimeout(2.0)
        sock.sendto(query, (host, port))
        response, _ = sock.recvfrom(2048)
    if response[:2] != query[:2]:
        raise OSError("mismatched DNS transaction id")
    return response


def _build_dns_query(name: str) -> bytes:
    labels = name.rstrip(".").split(".")
    qname = b"".join(bytes([len(label)]) + label.encode("ascii") for label in labels) + b"\x00"
    return b"\x49\x53" + b"\x01\x00" + struct.pack("!HHHH", 1, 0, 0, 0) + qname + struct.pack("!HH", 1, 1)


def _probe_http(host: str, port: int, host_header: str) -> int:
    try:
        with socket.create_connection((host, port), timeout=2.0) as sock:
            sock.settimeout(2.0)
            sock.sendall(f"GET / HTTP/1.1\r\nHost: {host_header}\r\nConnection: close\r\n\r\n".encode("ascii"))
            response = sock.recv(4096)
        if not response.startswith(b"HTTP/"):
            raise OSError("non-HTTP response")
        status = response.split(b"\r\n", 1)[0].decode("ascii", "replace")
        print(f"http: ok tcp={host}:{port} status={status}")
        return 0
    except OSError as exc:
        print(f"http: failed tcp={host}:{port} error={exc}")
        return 1


def _probe_https(host: str, port: int, host_header: str) -> int:
    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    try:
        with socket.create_connection((host, port), timeout=2.0) as raw_sock:
            raw_sock.settimeout(2.0)
            with context.wrap_socket(raw_sock, server_hostname=host_header) as sock:
                sock.sendall(f"GET / HTTP/1.1\r\nHost: {host_header}\r\nConnection: close\r\n\r\n".encode("ascii"))
                response = sock.recv(4096)
        if not response.startswith(b"HTTP/"):
            raise OSError("non-HTTP response")
        status = response.split(b"\r\n", 1)[0].decode("ascii", "replace")
        print(f"https: ok tcp={host}:{port} sni={host_header} status={status}")
        return 0
    except OSError as exc:
        print(f"https: failed tcp={host}:{port} sni={host_header} error={exc}")
        return 1


def detect_interface_network(interface_name: str) -> InterfaceNetwork:
    try:
        result = subprocess.run(
            ["ip", "-j", "-4", "addr", "show", "dev", interface_name],
            check=False,
            capture_output=True,
            text=True,
        )
    except FileNotFoundError as exc:
        raise InterfaceDetectionError("could not find the 'ip' command; install iproute2 or configure subnet values manually") from exc

    if result.returncode != 0:
        reason = result.stderr.strip() or result.stdout.strip() or f"ip exited with status {result.returncode}"
        raise InterfaceDetectionError(f"could not inspect interface {interface_name!r}: {reason}")

    try:
        payload = json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        raise InterfaceDetectionError(f"ip command returned invalid JSON for interface {interface_name!r}") from exc

    if not isinstance(payload, list) or not payload:
        raise InterfaceDetectionError(f"interface {interface_name!r} was not found")

    for item in payload:
        for address in item.get("addr_info", []) if isinstance(item, dict) else []:
            if address.get("family") != "inet":
                continue
            local = address.get("local")
            prefixlen = address.get("prefixlen")
            if not isinstance(local, str) or not isinstance(prefixlen, int):
                continue
            try:
                detected = ip_interface(f"{local}/{prefixlen}")
            except ValueError as exc:
                raise InterfaceDetectionError(f"interface {interface_name!r} has invalid IPv4 address data") from exc
            return InterfaceNetwork(interface_name, str(detected.ip), str(detected.network))

    raise InterfaceDetectionError(f"interface {interface_name!r} has no IPv4 address")


def apply_interface_network(config, network: InterfaceNetwork) -> None:
    config.global_.listen_host = network.address
    config.global_.allowed_clients = [network.cidr]
    config.dns.sinkhole_ip = network.address
    config.dns.sinkhole_ipv4 = network.address
