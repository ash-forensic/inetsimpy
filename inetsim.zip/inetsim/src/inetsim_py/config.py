from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field, fields
from ipaddress import ip_address, ip_network
from pathlib import Path, PurePath
from typing import Any
from .pki import crl_url_path
import math
import re
import socket
import tomllib

FAKE_DOWNLOAD_KINDS = {
    "windows_executable",
    "windows_dll",
    "windows_executable_x64",
    "windows_dll_x64",
    "linux_executable",
    "shellcode_x86",
    "shellcode_x64",
    "shell_script",
    "python_script",
    "powershell_script",
    "batch_script",
    "javascript",
    "vbscript",
    "zip",
    "pdf",
    "office_document",
    "msi",
    "script",
    "text",
}

DNS_HOST_LABEL_RE = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?$")


@dataclass(slots=True)
class GlobalConfig:
    listen_host: str = "127.0.0.1"
    allowed_clients: list[str] = field(default_factory=lambda: ["127.0.0.1/32", "::1/128"])
    log_dir: Path = Path("logs")
    artifact_dir: Path = Path("artifacts")
    read_timeout_seconds: float = 8.0
    max_body_bytes: int = 1048576
    max_command_count: int = 200
    max_artifact_bytes: int = 10485760
    fake_time_utc: str = ""
    tls_crl_url: str = ""


@dataclass(slots=True)
class DnsConfig:
    enabled: bool = True
    udp_port: int = 1053
    tcp_port: int = 1053
    sinkhole_ip: str = "127.0.0.1"
    sinkhole_ipv4: str | None = None
    sinkhole_ipv6: str | None = None
    ttl: int = 60
    wildcard: bool = True
    records: dict[str, str] = field(default_factory=dict)
    mx_records: dict[str, str] = field(default_factory=dict)
    txt_records: dict[str, str] = field(default_factory=dict)
    cname_records: dict[str, str] = field(default_factory=dict)
    ns_records: dict[str, str] = field(default_factory=dict)
    srv_records: dict[str, str] = field(default_factory=dict)


@dataclass(slots=True)
class NtpConfig:
    enabled: bool = False
    port: int = 10123
    stratum: int = 1


@dataclass(slots=True)
class TftpConfig:
    enabled: bool = False
    port: int = 10069
    allow_uploads: bool = True
    files: dict[str, str] = field(default_factory=lambda: {"/README.txt": "INetSim-Py TFTP service\n"})


@dataclass(slots=True)
class HttpConfig:
    enabled: bool = True
    port: int = 18080
    server_header: str = "nginx/1.24.0"
    default_status: int = 200
    default_body: str = "Service unavailable\n"
    login_page_enabled: bool = True
    login_page_path: str = "/"
    login_page_brand: str = "Contoso"
    login_page_title: str = "Enterprise sign in"
    login_page_realm: str = "Work or school account"
    fake_downloads_enabled: bool = True
    fake_download_extensions: dict[str, str] = field(
        default_factory=lambda: {
            ".exe": "windows_executable",
            ".dll": "windows_dll",
            ".scr": "windows_executable",
            ".zip": "zip",
            ".pdf": "pdf",
            ".doc": "office_document",
            ".docx": "zip",
            ".xls": "office_document",
            ".xlsx": "zip",
            ".msi": "msi",
            ".js": "script",
            ".vbs": "script",
            ".ps1": "script",
            ".bat": "script",
            ".cmd": "script",
            ".sh": "script",
            ".py": "script",
            ".elf": "linux_executable",
            ".txt": "text",
        }
    )
    fake_download_routes: dict[str, str] = field(default_factory=dict)
    routes: dict[str, str] = field(
        default_factory=lambda: {
            "/robots.txt": "User-agent: *\nDisallow:\n",
            "/generate_204": "",
            "/gen_204": "",
            "/hotspot-detect.html": "<HTML><HEAD><TITLE>Success</TITLE></HEAD><BODY>Success</BODY></HTML>\n",
            "/ncsi.txt": "Microsoft NCSI\n",
            "/connecttest.txt": "Microsoft Connect Test\n",
            "/success.txt": "success\n",
        }
    )
    route_statuses: dict[str, int] = field(default_factory=lambda: {"/generate_204": 204, "/gen_204": 204})


@dataclass(slots=True)
class HttpsConfig:
    enabled: bool = True
    port: int = 18443
    cert_file: Path | None = None
    key_file: Path | None = None
    auto_generate_cert: bool = True
    cert_common_name: str = "inetsim.local"
    prewarm_hosts: list[str] = field(default_factory=list)
    block_on_unknown_sni: bool = False


@dataclass(slots=True)
class SmtpConfig:
    enabled: bool = True
    port: int = 11025
    implicit_tls_port: int = 0
    hostname: str = "mx01.corp.local"
    banner: str = "ESMTP Postfix"


@dataclass(slots=True)
class FtpConfig:
    enabled: bool = True
    port: int = 11021
    implicit_tls_port: int = 0
    banner: str = "(vsFTPd 3.0.5)"
    pasv_advertise_ip: str | None = None
    allow_uploads: bool = True
    persist_uploads: bool = False
    upload_index: str = "ftp/uploads/index.json"
    files: dict[str, str] = field(default_factory=lambda: {"/README.txt": "INetSim-Py FTP service\n"})


@dataclass(slots=True)
class Pop3Config:
    enabled: bool = True
    port: int = 11110
    implicit_tls_port: int = 0
    hostname: str = "mail.corp.local"
    banner: str = "Dovecot ready"
    username: str = "user"
    message_from: str = "postmaster@mail.corp.local"
    message_subject: str = "Quarterly security update"
    message_body: str = "Your mailbox is active. No new action is required.\n"


@dataclass(slots=True)
class SmbConfig:
    enabled: bool = True
    port: int = 11445
    netbios_port: int = 10139
    server_name: str = "FILESRV01"
    workgroup: str = "CORP"
    max_request_bytes: int = 1048576


@dataclass(slots=True)
class MitmProxyConfig:
    enabled: bool = False
    port: int = 18088
    mode: str = "regular"
    executable: str = "mitmdump"
    block_upstream: bool = True
    allow_upstream_hosts: list[str] = field(default_factory=list)
    synthesize_downloads: bool = True
    ssl_insecure: bool = False
    body_capture_limit: int = 1048576
    synthetic_status: int = 200
    blocked_status: int = 502


@dataclass(slots=True)
class QuicConfig:
    enabled: bool = False
    port: int = 443
    send_close: bool = True
    block: bool = True


@dataclass(slots=True)
class TorSocksConfig:
    enabled: bool = False
    port: int = 19050


@dataclass(slots=True)
class TorControlConfig:
    enabled: bool = False
    port: int = 19051
    version: str = "0.4.8.10"


@dataclass(slots=True)
class TcpBannerConfig:
    enabled: bool = True
    ports: dict[int, str] = field(default_factory=lambda: {12222: "SSH-2.0-OpenSSH_8.9\r\n"})


@dataclass(slots=True)
class DummyConfig:
    enabled: bool = False
    tcp_ports: dict[int, str] = field(default_factory=dict)
    udp_ports: dict[int, str] = field(default_factory=dict)
    max_read_bytes: int = 4096


@dataclass(slots=True)
class AppConfig:
    global_: GlobalConfig = field(default_factory=GlobalConfig)
    dns: DnsConfig = field(default_factory=DnsConfig)
    ntp: NtpConfig = field(default_factory=NtpConfig)
    tftp: TftpConfig = field(default_factory=TftpConfig)
    http: HttpConfig = field(default_factory=HttpConfig)
    https: HttpsConfig = field(default_factory=HttpsConfig)
    smtp: SmtpConfig = field(default_factory=SmtpConfig)
    ftp: FtpConfig = field(default_factory=FtpConfig)
    pop3: Pop3Config = field(default_factory=Pop3Config)
    smb: SmbConfig = field(default_factory=SmbConfig)
    mitmproxy: MitmProxyConfig = field(default_factory=MitmProxyConfig)
    quic: QuicConfig = field(default_factory=QuicConfig)
    tor_socks: TorSocksConfig = field(default_factory=TorSocksConfig)
    tor_control: TorControlConfig = field(default_factory=TorControlConfig)
    tcp_banners: TcpBannerConfig = field(default_factory=TcpBannerConfig)
    dummy: DummyConfig = field(default_factory=DummyConfig)


class ConfigValidationError(ValueError):
    def __init__(self, errors: list[str]) -> None:
        self.errors = errors
        super().__init__("\n".join(errors))


def load_config(path: str | Path | None) -> AppConfig:
    if path is None:
        return AppConfig()
    config_path = Path(path)
    try:
        with config_path.open("rb") as file_obj:
            data = tomllib.load(file_obj)
    except OSError as exc:
        raise ConfigValidationError([f"could not read config {config_path}: {exc}"]) from exc
    except tomllib.TOMLDecodeError as exc:
        raise ConfigValidationError([f"invalid TOML in {config_path}: {exc}"]) from exc
    return config_from_dict(data)


def config_from_dict(data: dict[str, Any]) -> AppConfig:
    errors: list[str] = []
    _reject_unknown_keys("root", data, {"global", "services"}, errors)

    global_data = _table(data, "global", errors)
    _reject_unknown_keys("global", global_data, _dataclass_keys(GlobalConfig), errors)
    if "log_dir" in global_data:
        global_data["log_dir"] = _parse_path("global.log_dir", global_data["log_dir"], errors)
    if "artifact_dir" in global_data:
        global_data["artifact_dir"] = _parse_path("global.artifact_dir", global_data["artifact_dir"], errors)

    services = _table(data, "services", errors)
    service_keys = {"dns", "ntp", "tftp", "http", "https", "smtp", "ftp", "pop3", "smb", "mitmproxy", "quic", "tor_socks", "tor_control", "tcp_banners", "dummy"}
    _reject_unknown_keys("services", services, service_keys, errors)

    dns = _table(services, "dns", errors, "services")
    ntp = _table(services, "ntp", errors, "services")
    tftp = _table(services, "tftp", errors, "services")
    http = _table(services, "http", errors, "services")
    https = _table(services, "https", errors, "services")
    smtp = _table(services, "smtp", errors, "services")
    ftp = _table(services, "ftp", errors, "services")
    pop3 = _table(services, "pop3", errors, "services")
    smb = _table(services, "smb", errors, "services")
    mitmproxy = _table(services, "mitmproxy", errors, "services")
    quic = _table(services, "quic", errors, "services")
    tor_socks = _table(services, "tor_socks", errors, "services")
    tor_control = _table(services, "tor_control", errors, "services")
    tcp_banners = _table(services, "tcp_banners", errors, "services")
    dummy = _table(services, "dummy", errors, "services")

    _reject_unknown_keys("services.dns", dns, _dataclass_keys(DnsConfig), errors)
    _reject_unknown_keys("services.ntp", ntp, _dataclass_keys(NtpConfig), errors)
    _reject_unknown_keys("services.tftp", tftp, _dataclass_keys(TftpConfig), errors)
    _reject_unknown_keys("services.http", http, _dataclass_keys(HttpConfig), errors)
    _reject_unknown_keys("services.https", https, _dataclass_keys(HttpsConfig), errors)
    _reject_unknown_keys("services.smtp", smtp, _dataclass_keys(SmtpConfig), errors)
    _reject_unknown_keys("services.ftp", ftp, _dataclass_keys(FtpConfig), errors)
    _reject_unknown_keys("services.pop3", pop3, _dataclass_keys(Pop3Config), errors)
    _reject_unknown_keys("services.smb", smb, _dataclass_keys(SmbConfig), errors)
    _reject_unknown_keys("services.mitmproxy", mitmproxy, _dataclass_keys(MitmProxyConfig), errors)
    _reject_unknown_keys("services.quic", quic, _dataclass_keys(QuicConfig), errors)
    _reject_unknown_keys("services.tor_socks", tor_socks, _dataclass_keys(TorSocksConfig), errors)
    _reject_unknown_keys("services.tor_control", tor_control, _dataclass_keys(TorControlConfig), errors)
    _reject_unknown_keys("services.tcp_banners", tcp_banners, _dataclass_keys(TcpBannerConfig), errors)
    _reject_unknown_keys("services.dummy", dummy, _dataclass_keys(DummyConfig), errors)

    _validate_mapping("services.dns.records", dns.get("records"), errors, required=False)
    for key in ("mx_records", "txt_records", "cname_records", "ns_records", "srv_records"):
        _validate_mapping(f"services.dns.{key}", dns.get(key), errors, required=False)
    _validate_mapping("services.http.fake_download_extensions", http.get("fake_download_extensions"), errors, required=False)
    _validate_mapping("services.http.fake_download_routes", http.get("fake_download_routes"), errors, required=False)
    _validate_mapping("services.http.routes", http.get("routes"), errors, required=False)
    _validate_mapping("services.http.route_statuses", http.get("route_statuses"), errors, required=False)
    _validate_mapping("services.tftp.files", tftp.get("files"), errors, required=False)
    _validate_mapping("services.ftp.files", ftp.get("files"), errors, required=False)
    _validate_list("services.mitmproxy.allow_upstream_hosts", mitmproxy.get("allow_upstream_hosts"), errors, required=False)
    _validate_list("services.https.prewarm_hosts", https.get("prewarm_hosts"), errors, required=False)
    _validate_mapping("services.dummy.tcp_ports", dummy.get("tcp_ports"), errors, required=False)
    _validate_mapping("services.dummy.udp_ports", dummy.get("udp_ports"), errors, required=False)

    if isinstance(dns.get("records"), Mapping):
        dns["records"] = _normalize_dns_records(dns["records"], errors)
    for key in ("mx_records", "txt_records", "cname_records", "ns_records", "srv_records"):
        if isinstance(dns.get(key), Mapping):
            dns[key] = _normalize_dns_records(dns[key], errors)
    if isinstance(http.get("fake_download_extensions"), Mapping):
        http["fake_download_extensions"] = _normalize_fake_download_extensions(http["fake_download_extensions"], errors)
    if isinstance(http.get("route_statuses"), Mapping):
        http["route_statuses"] = _normalize_http_route_statuses(http["route_statuses"], errors)
    for key in ("sinkhole_ipv4", "sinkhole_ipv6"):
        if dns.get(key) == "":
            dns[key] = None
    if ftp.get("pasv_advertise_ip") == "":
        ftp["pasv_advertise_ip"] = None
    if "cert_file" in https:
        https["cert_file"] = _parse_optional_path("services.https.cert_file", https["cert_file"], errors)
    if "key_file" in https:
        https["key_file"] = _parse_optional_path("services.https.key_file", https["key_file"], errors)
    if "ports" in tcp_banners:
        tcp_banners["ports"] = _parse_tcp_banner_ports(tcp_banners["ports"], errors)
    if "tcp_ports" in dummy:
        dummy["tcp_ports"] = _parse_port_string_map("services.dummy.tcp_ports", dummy["tcp_ports"], errors)
    if "udp_ports" in dummy:
        dummy["udp_ports"] = _parse_port_string_map("services.dummy.udp_ports", dummy["udp_ports"], errors)

    if errors:
        raise ConfigValidationError(errors)

    return AppConfig(
        global_=GlobalConfig(**global_data),
        dns=DnsConfig(**dns),
        ntp=NtpConfig(**ntp),
        tftp=TftpConfig(**tftp),
        http=HttpConfig(**http),
        https=HttpsConfig(**https),
        smtp=SmtpConfig(**smtp),
        ftp=FtpConfig(**ftp),
        pop3=Pop3Config(**pop3),
        smb=SmbConfig(**smb),
        mitmproxy=MitmProxyConfig(**mitmproxy),
        quic=QuicConfig(**quic),
        tor_socks=TorSocksConfig(**tor_socks),
        tor_control=TorControlConfig(**tor_control),
        tcp_banners=TcpBannerConfig(**tcp_banners),
        dummy=DummyConfig(**dummy),
    )


def _table(data: dict[str, Any], key: str, errors: list[str], parent: str = "") -> dict[str, Any]:
    path = f"{parent}.{key}" if parent else key
    value = data.get(key, {})
    if isinstance(value, dict):
        return dict(value)
    errors.append(f"{path} must be a table")
    return {}


def _parse_path(path: str, value: Any, errors: list[str]) -> Path:
    if isinstance(value, (str, Path)):
        return Path(value)
    errors.append(f"{path} must be a string path")
    return Path(".")


def _parse_optional_path(path: str, value: Any, errors: list[str]) -> Path | None:
    if value is None or value == "":
        return None
    if isinstance(value, (str, Path)):
        return Path(value)
    errors.append(f"{path} must be a string path")
    return None


def _dataclass_keys(config_type: type) -> set[str]:
    return {item.name for item in fields(config_type)}


def _reject_unknown_keys(path: str, data: dict[str, Any], allowed: set[str], errors: list[str]) -> None:
    for key in data:
        if key not in allowed:
            errors.append(f"unknown config key {path}.{key}")


def _parse_tcp_banner_ports(value: Any, errors: list[str]) -> dict[int, str]:
    return _parse_port_string_map("services.tcp_banners.ports", value, errors)


def _parse_port_string_map(path: str, value: Any, errors: list[str]) -> dict[int, str]:
    if not isinstance(value, Mapping):
        errors.append(f"{path} must be a table")
        return {}
    ports: dict[int, str] = {}
    for port, banner in value.items():
        if isinstance(port, bool) or not isinstance(port, (int, str)):
            errors.append(f"{path} contains non-integer port {port!r}")
            continue
        if isinstance(port, int):
            numeric_port = port
        else:
            try:
                numeric_port = int(port)
            except ValueError:
                errors.append(f"{path} contains non-integer port {port!r}")
                continue
        ports[numeric_port] = banner
    return ports


def _normalize_dns_records(value: Mapping[Any, Any], errors: list[str]) -> dict[str, Any]:
    records: dict[str, Any] = {}
    for name, address in value.items():
        normalized = name.rstrip(".").lower() if isinstance(name, str) else name
        if isinstance(normalized, str) and normalized in records:
            errors.append(f"services.dns.records contains duplicate hostname after normalization: {normalized}")
            continue
        records[normalized] = address
    return records


def _normalize_fake_download_extensions(value: Mapping[Any, Any], errors: list[str]) -> dict[str, Any]:
    extensions: dict[str, Any] = {}
    for extension, kind in value.items():
        normalized = extension.lower() if isinstance(extension, str) else extension
        if isinstance(normalized, str) and normalized in extensions:
            errors.append(f"services.http.fake_download_extensions contains duplicate extension after normalization: {normalized}")
            continue
        extensions[normalized] = kind
    return extensions


def _normalize_http_route_statuses(value: Mapping[Any, Any], errors: list[str]) -> dict[str, Any]:
    statuses: dict[str, Any] = {}
    for route, status in value.items():
        if isinstance(route, str) and route in statuses:
            errors.append(f"services.http.route_statuses contains duplicate route: {route}")
            continue
        statuses[route] = status
    return statuses


def validate_config(config: AppConfig) -> None:
    errors: list[str] = []
    _validate_bool("services.dns.enabled", config.dns.enabled, errors)
    _validate_bool("services.dns.wildcard", config.dns.wildcard, errors)
    _validate_bool("services.ntp.enabled", config.ntp.enabled, errors)
    _validate_bool("services.tftp.enabled", config.tftp.enabled, errors)
    _validate_bool("services.tftp.allow_uploads", config.tftp.allow_uploads, errors)
    _validate_bool("services.http.enabled", config.http.enabled, errors)
    _validate_bool("services.http.login_page_enabled", config.http.login_page_enabled, errors)
    _validate_bool("services.http.fake_downloads_enabled", config.http.fake_downloads_enabled, errors)
    _validate_bool("services.https.enabled", config.https.enabled, errors)
    _validate_bool("services.https.auto_generate_cert", config.https.auto_generate_cert, errors)
    _validate_bool("services.https.block_on_unknown_sni", config.https.block_on_unknown_sni, errors)
    _validate_bool("services.smtp.enabled", config.smtp.enabled, errors)
    _validate_bool("services.ftp.enabled", config.ftp.enabled, errors)
    _validate_bool("services.ftp.allow_uploads", config.ftp.allow_uploads, errors)
    _validate_bool("services.ftp.persist_uploads", config.ftp.persist_uploads, errors)
    _validate_bool("services.pop3.enabled", config.pop3.enabled, errors)
    _validate_bool("services.smb.enabled", config.smb.enabled, errors)
    _validate_bool("services.mitmproxy.enabled", config.mitmproxy.enabled, errors)
    _validate_bool("services.mitmproxy.block_upstream", config.mitmproxy.block_upstream, errors)
    _validate_bool("services.mitmproxy.synthesize_downloads", config.mitmproxy.synthesize_downloads, errors)
    _validate_bool("services.mitmproxy.ssl_insecure", config.mitmproxy.ssl_insecure, errors)
    _validate_bool("services.quic.enabled", config.quic.enabled, errors)
    _validate_bool("services.quic.send_close", config.quic.send_close, errors)
    _validate_bool("services.quic.block", config.quic.block, errors)
    _validate_bool("services.tor_socks.enabled", config.tor_socks.enabled, errors)
    _validate_bool("services.tor_control.enabled", config.tor_control.enabled, errors)
    _validate_bool("services.tcp_banners.enabled", config.tcp_banners.enabled, errors)
    _validate_bool("services.dummy.enabled", config.dummy.enabled, errors)

    _validate_listen_host(config.global_.listen_host, errors)
    _validate_networks("global.allowed_clients", config.global_.allowed_clients, errors)
    _validate_positive_number("global.read_timeout_seconds", config.global_.read_timeout_seconds, errors)
    _validate_non_negative_int("global.max_body_bytes", config.global_.max_body_bytes, errors)
    _validate_non_negative_int("global.max_command_count", config.global_.max_command_count, errors)
    _validate_non_negative_int("global.max_artifact_bytes", config.global_.max_artifact_bytes, errors)
    _validate_fake_time("global.fake_time_utc", config.global_.fake_time_utc, errors)
    if config.global_.tls_crl_url:
        try:
            crl_url_path(config.global_.tls_crl_url)
        except (ValueError, TypeError) as exc:
            errors.append(f"global.tls_crl_url: {exc}")
        if not config.http.enabled:
            errors.append("global.tls_crl_url requires services.http.enabled")
    elif not isinstance(config.global_.tls_crl_url, str):
        errors.append("global.tls_crl_url must be a string")

    _validate_port("services.dns.udp_port", config.dns.udp_port, errors)
    _validate_port("services.dns.tcp_port", config.dns.tcp_port, errors)
    _validate_ip("services.dns.sinkhole_ip", config.dns.sinkhole_ip, errors)
    _validate_optional_ip("services.dns.sinkhole_ipv4", config.dns.sinkhole_ipv4, 4, errors)
    _validate_optional_ip("services.dns.sinkhole_ipv6", config.dns.sinkhole_ipv6, 6, errors)
    _validate_uint32("services.dns.ttl", config.dns.ttl, errors)
    for name, value in config.dns.records.items():
        if not isinstance(name, str) or not name.strip():
            errors.append("services.dns.records contains an empty hostname")
        elif not _valid_dns_name(name):
            errors.append(f"services.dns.records contains invalid hostname {name!r}")
        if not isinstance(value, str):
            errors.append(f"services.dns.records.{name} must be a string IP address")
            continue
        _validate_ip(f"services.dns.records.{name}", value, errors)
    _validate_dns_hostname_map("services.dns.mx_records", config.dns.mx_records, errors)
    _validate_dns_hostname_map("services.dns.cname_records", config.dns.cname_records, errors)
    _validate_dns_hostname_map("services.dns.ns_records", config.dns.ns_records, errors)
    _validate_dns_string_map("services.dns.txt_records", config.dns.txt_records, errors)
    _validate_dns_srv_map("services.dns.srv_records", config.dns.srv_records, errors)

    _validate_port("services.ntp.port", config.ntp.port, errors)
    _validate_positive_int("services.ntp.stratum", config.ntp.stratum, errors)
    if _is_int(config.ntp.stratum) and config.ntp.stratum > 15:
        errors.append("services.ntp.stratum must be from 1 to 15")
    _validate_port("services.tftp.port", config.tftp.port, errors)
    _validate_virtual_files("services.tftp.files", config.tftp.files, errors)

    _validate_port("services.http.port", config.http.port, errors)
    _validate_status("services.http.default_status", config.http.default_status, errors)
    _validate_header_value("services.http.server_header", config.http.server_header, errors)
    _validate_string_value("services.http.default_body", config.http.default_body, errors)
    _validate_path_only("services.http.login_page_path", config.http.login_page_path, errors)
    for path, value in {
        "services.http.login_page_brand": config.http.login_page_brand,
        "services.http.login_page_title": config.http.login_page_title,
        "services.http.login_page_realm": config.http.login_page_realm,
    }.items():
        _validate_display_text(path, value, errors)
    for extension, kind in config.http.fake_download_extensions.items():
        if not isinstance(extension, str) or not extension.startswith(".") or len(extension) < 2:
            errors.append(f"services.http.fake_download_extensions contains invalid extension {extension!r}")
        if not isinstance(kind, str) or not kind.strip():
            errors.append(f"services.http.fake_download_extensions.{extension} has an empty kind")
        elif kind not in FAKE_DOWNLOAD_KINDS:
            errors.append(f"services.http.fake_download_extensions.{extension} has unsupported kind {kind!r}")
    for route, kind in config.http.fake_download_routes.items():
        _validate_path_only(f"services.http.fake_download_routes.{route}", route, errors)
        if not isinstance(kind, str) or kind not in FAKE_DOWNLOAD_KINDS:
            errors.append(f"services.http.fake_download_routes.{route} has unsupported kind {kind!r}")
    for route, body in config.http.routes.items():
        _validate_path_only(f"services.http.routes.{route}", route, errors)
        if not isinstance(body, str):
            errors.append(f"services.http.routes.{route} must be a string response body")
    for route, status in config.http.route_statuses.items():
        _validate_path_only(f"services.http.route_statuses.{route}", route, errors)
        _validate_status(f"services.http.route_statuses.{route}", status, errors)

    _validate_port("services.https.port", config.https.port, errors)
    _validate_display_text("services.https.cert_common_name", config.https.cert_common_name, errors)
    if (
        isinstance(config.https.cert_common_name, str)
        and config.https.cert_common_name.strip()
        and not _valid_dns_name(config.https.cert_common_name)
    ):
        errors.append("services.https.cert_common_name must be a valid DNS hostname")
    _validate_optional_path_pair("services.https", config.https.cert_file, config.https.key_file, errors)
    _validate_string_list_items("services.https.prewarm_hosts", config.https.prewarm_hosts, errors)
    for index, host in enumerate(config.https.prewarm_hosts):
        if isinstance(host, str) and host.strip() and not _valid_dns_name(host):
            errors.append(f"services.https.prewarm_hosts[{index}] contains invalid hostname {host!r}")
    if config.https.enabled and not config.https.auto_generate_cert and (config.https.cert_file is None or config.https.key_file is None):
        errors.append("services.https requires cert_file and key_file when auto_generate_cert is false")

    _validate_port("services.smtp.port", config.smtp.port, errors)
    _validate_port("services.smtp.implicit_tls_port", config.smtp.implicit_tls_port, errors)
    _validate_header_value("services.smtp.hostname", config.smtp.hostname, errors)
    _validate_header_value("services.smtp.banner", config.smtp.banner, errors)
    _validate_port("services.ftp.port", config.ftp.port, errors)
    _validate_port("services.ftp.implicit_tls_port", config.ftp.implicit_tls_port, errors)
    _validate_optional_ip("services.ftp.pasv_advertise_ip", config.ftp.pasv_advertise_ip, 4, errors)
    _validate_header_value("services.ftp.banner", config.ftp.banner, errors)
    _validate_relative_safe_path("services.ftp.upload_index", config.ftp.upload_index, errors)
    _validate_virtual_files("services.ftp.files", config.ftp.files, errors)
    _validate_port("services.pop3.port", config.pop3.port, errors)
    _validate_port("services.pop3.implicit_tls_port", config.pop3.implicit_tls_port, errors)
    _validate_header_value("services.pop3.hostname", config.pop3.hostname, errors)
    _validate_header_value("services.pop3.banner", config.pop3.banner, errors)
    _validate_header_value("services.pop3.username", config.pop3.username, errors)
    _validate_header_value("services.pop3.message_from", config.pop3.message_from, errors)
    _validate_header_value("services.pop3.message_subject", config.pop3.message_subject, errors)
    _validate_string_value("services.pop3.message_body", config.pop3.message_body, errors)
    _validate_port("services.smb.port", config.smb.port, errors)
    _validate_port("services.smb.netbios_port", config.smb.netbios_port, errors)
    _validate_header_value("services.smb.server_name", config.smb.server_name, errors)
    _validate_header_value("services.smb.workgroup", config.smb.workgroup, errors)
    _validate_positive_int("services.smb.max_request_bytes", config.smb.max_request_bytes, errors)

    _validate_port("services.mitmproxy.port", config.mitmproxy.port, errors)
    _validate_non_negative_int("services.mitmproxy.body_capture_limit", config.mitmproxy.body_capture_limit, errors)
    _validate_status("services.mitmproxy.synthetic_status", config.mitmproxy.synthetic_status, errors)
    _validate_status("services.mitmproxy.blocked_status", config.mitmproxy.blocked_status, errors)
    _validate_display_text("services.mitmproxy.mode", config.mitmproxy.mode, errors)
    _validate_display_text("services.mitmproxy.executable", config.mitmproxy.executable, errors)
    _validate_list("services.mitmproxy.allow_upstream_hosts", config.mitmproxy.allow_upstream_hosts, errors)
    _validate_string_list_items("services.mitmproxy.allow_upstream_hosts", config.mitmproxy.allow_upstream_hosts, errors)
    for index, pattern in enumerate(config.mitmproxy.allow_upstream_hosts):
        if isinstance(pattern, str) and pattern.strip() and not _valid_host_pattern(pattern):
            errors.append(f"services.mitmproxy.allow_upstream_hosts[{index}] contains invalid host pattern {pattern!r}")

    _validate_port("services.quic.port", config.quic.port, errors)

    _validate_port("services.tor_socks.port", config.tor_socks.port, errors)
    _validate_port("services.tor_control.port", config.tor_control.port, errors)
    _validate_display_text("services.tor_control.version", config.tor_control.version, errors)

    for port in config.tcp_banners.ports:
        _validate_port(f"services.tcp_banners.ports.{port}", port, errors)
        _validate_tcp_banner_value(f"services.tcp_banners.ports.{port}", config.tcp_banners.ports[port], errors)
    for port, response in config.dummy.tcp_ports.items():
        _validate_port(f"services.dummy.tcp_ports.{port}", port, errors)
        _validate_string_value(f"services.dummy.tcp_ports.{port}", response, errors)
    for port, response in config.dummy.udp_ports.items():
        _validate_port(f"services.dummy.udp_ports.{port}", port, errors)
        _validate_string_value(f"services.dummy.udp_ports.{port}", response, errors)
    _validate_positive_int("services.dummy.max_read_bytes", config.dummy.max_read_bytes, errors)

    _validate_tcp_port_collisions(config, errors)
    _validate_udp_port_collisions(config, errors)

    if errors:
        raise ConfigValidationError(errors)


def _validate_listen_host(value: str, errors: list[str]) -> None:
    if not isinstance(value, str) or not value.strip():
        errors.append("global.listen_host must not be empty")
        return
    try:
        socket.getaddrinfo(value, None, type=socket.SOCK_STREAM)
    except socket.gaierror as exc:
        errors.append(f"global.listen_host {value!r} is not resolvable: {exc}")


def _validate_networks(path: str, values: list[str], errors: list[str]) -> None:
    if not isinstance(values, list):
        errors.append(f"{path} must be a list")
        return
    if not values:
        errors.append(f"{path} must contain at least one network")
        return
    for index, value in enumerate(values):
        if not isinstance(value, str):
            errors.append(f"{path}[{index}] must be a string network")
            continue
        try:
            ip_network(value, strict=False)
        except ValueError as exc:
            errors.append(f"{path} contains invalid network {value!r}: {exc}")


def _validate_ip(path: str, value: str, errors: list[str]) -> None:
    try:
        ip_address(value)
    except ValueError as exc:
        errors.append(f"{path} contains invalid IP address {value!r}: {exc}")


def _validate_optional_ip(path: str, value: str | None, version: int, errors: list[str]) -> None:
    if value is None:
        return
    if not isinstance(value, str):
        errors.append(f"{path} must be a string IP address")
        return
    try:
        parsed = ip_address(value)
    except ValueError as exc:
        errors.append(f"{path} contains invalid IP address {value!r}: {exc}")
        return
    if parsed.version != version:
        errors.append(f"{path} must be an IPv{version} address")


def _valid_dns_name(value: str) -> bool:
    labels = value.rstrip(".").split(".")
    if not labels or any(not label for label in labels):
        return False
    wire_length = 1
    for label in labels:
        try:
            label_length = len(label.encode("ascii"))
        except UnicodeEncodeError:
            return False
        if label_length > 63 or not DNS_HOST_LABEL_RE.fullmatch(label):
            return False
        wire_length += 1 + label_length
    return wire_length <= 255


def _valid_host_pattern(value: str) -> bool:
    normalized = value.rstrip(".")
    if normalized == "*":
        return True
    if normalized.startswith("*."):
        return _valid_dns_name(normalized[2:])
    return _valid_dns_name(normalized)


def _validate_dns_hostname_map(path: str, values: dict[str, str], errors: list[str]) -> None:
    for name, value in values.items():
        if not isinstance(name, str) or not name.strip() or not _valid_dns_name(name):
            errors.append(f"{path} contains invalid hostname {name!r}")
        if not isinstance(value, str) or not _valid_dns_name(value):
            errors.append(f"{path}.{name} must be a DNS hostname")


def _validate_dns_string_map(path: str, values: dict[str, str], errors: list[str]) -> None:
    for name, value in values.items():
        if not isinstance(name, str) or not name.strip() or not _valid_dns_owner_name(name):
            errors.append(f"{path} contains invalid hostname {name!r}")
        if not isinstance(value, str):
            errors.append(f"{path}.{name} must be a string")


def _validate_dns_srv_map(path: str, values: dict[str, str], errors: list[str]) -> None:
    for name, value in values.items():
        if not isinstance(name, str) or not name.strip() or not _valid_dns_owner_name(name):
            errors.append(f"{path} contains invalid hostname {name!r}")
        if not isinstance(value, str):
            errors.append(f"{path}.{name} must be a string")
            continue
        parts = value.split()
        if len(parts) == 1:
            if not _valid_dns_name(parts[0]):
                errors.append(f"{path}.{name} must contain a valid SRV target hostname")
            continue
        if len(parts) != 4 or not all(part.isdigit() for part in parts[:3]):
            errors.append(f"{path}.{name} must be either 'target.example' or 'priority weight port target.example'")
            continue
        priority, weight, port = (int(parts[0]), int(parts[1]), int(parts[2]))
        if priority > 65535 or weight > 65535 or port > 65535:
            errors.append(f"{path}.{name} priority, weight, and port must fit uint16")
        if not _valid_dns_name(parts[3]):
            errors.append(f"{path}.{name} must contain a valid SRV target hostname")


def _valid_dns_owner_name(value: str) -> bool:
    labels = value.rstrip(".").split(".")
    if not labels or any(not label for label in labels):
        return False
    wire_length = 1
    for label in labels:
        plain = label[1:] if label.startswith("_") else label
        try:
            label_length = len(label.encode("ascii"))
        except UnicodeEncodeError:
            return False
        if label_length > 63 or not DNS_HOST_LABEL_RE.fullmatch(plain):
            return False
        wire_length += 1 + label_length
    return wire_length <= 255


def _validate_port(path: str, value: int, errors: list[str]) -> None:
    if not _is_int(value) or value < 0 or value > 65535:
        errors.append(f"{path} must be an integer from 0 to 65535")


def _validate_bool(path: str, value: bool, errors: list[str]) -> None:
    if not isinstance(value, bool):
        errors.append(f"{path} must be a boolean")


def _validate_non_negative_int(path: str, value: int, errors: list[str]) -> None:
    if not _is_int(value):
        errors.append(f"{path} must be an integer")
        return
    if value < 0:
        errors.append(f"{path} must be greater than or equal to 0")


def _validate_uint32(path: str, value: int, errors: list[str]) -> None:
    if not _is_int(value):
        errors.append(f"{path} must be an integer")
        return
    if value < 0 or value > 0xFFFFFFFF:
        errors.append(f"{path} must be an integer from 0 to 4294967295")


def _validate_positive_int(path: str, value: int, errors: list[str]) -> None:
    if not _is_int(value):
        errors.append(f"{path} must be an integer")
        return
    if value <= 0:
        errors.append(f"{path} must be greater than 0")


def _validate_positive_number(path: str, value: int | float, errors: list[str]) -> None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        errors.append(f"{path} must be numeric")
        return
    if not math.isfinite(value):
        errors.append(f"{path} must be finite")
        return
    if value <= 0:
        errors.append(f"{path} must be greater than 0")


def _validate_status(path: str, value: int, errors: list[str]) -> None:
    if not _is_int(value) or value < 100 or value > 599:
        errors.append(f"{path} must be an HTTP status code from 100 to 599")


def _validate_header_value(path: str, value: str, errors: list[str]) -> None:
    if not isinstance(value, str) or not value.strip():
        errors.append(f"{path} must not be empty")
        return
    if any(char in value for char in "\r\n"):
        errors.append(f"{path} must not contain CR or LF characters")
    if not value.isascii():
        errors.append(f"{path} must contain only ASCII characters")


def _validate_string_value(path: str, value: str, errors: list[str]) -> None:
    if not isinstance(value, str):
        errors.append(f"{path} must be a string")


def _validate_fake_time(path: str, value: str, errors: list[str]) -> None:
    if not isinstance(value, str):
        errors.append(f"{path} must be a string")
        return
    if not value:
        return
    try:
        from .timeutils import parse_fake_time

        parse_fake_time(value)
    except ValueError as exc:
        errors.append(f"{path} must be an ISO-8601 UTC timestamp such as 2024-01-01T00:00:00Z: {exc}")


def _validate_virtual_files(path: str, values: dict[str, str], errors: list[str]) -> None:
    for name, body in values.items():
        if not isinstance(name, str) or not name.startswith("/") or "\\" in name or ".." in PurePath(name).parts:
            errors.append(f"{path} contains invalid virtual path {name!r}")
        if not isinstance(body, str):
            errors.append(f"{path}.{name} must be a string body")


def _validate_relative_safe_path(path: str, value: str, errors: list[str]) -> None:
    if not isinstance(value, str) or not value.strip():
        errors.append(f"{path} must be a non-empty relative path")
        return
    pure = PurePath(value)
    if pure.is_absolute() or "\\" in value or ".." in pure.parts:
        errors.append(f"{path} must be a safe relative path")


def _validate_tcp_banner_value(path: str, value: str, errors: list[str]) -> None:
    if not isinstance(value, str) or not value:
        errors.append(f"{path} must be a non-empty string banner")


def _validate_display_text(path: str, value: str, errors: list[str]) -> None:
    if not isinstance(value, str) or not value.strip():
        errors.append(f"{path} must not be empty")


def _validate_optional_path_pair(path: str, cert_file: Path | None, key_file: Path | None, errors: list[str]) -> None:
    if (cert_file is None) != (key_file is None):
        errors.append(f"{path}.cert_file and {path}.key_file must be configured together")


def _validate_path_only(path: str, value: str, errors: list[str]) -> None:
    if not isinstance(value, str) or not value.startswith("/"):
        errors.append(f"{path} must be an absolute path")
        return
    if "?" in value or "#" in value:
        errors.append(f"{path} must not contain a query string or fragment")
    if "://" in value:
        errors.append(f"{path} must be a path, not a URL")


def _validate_mapping(path: str, value: Any, errors: list[str], required: bool = True) -> None:
    if value is None and not required:
        return
    if not isinstance(value, Mapping):
        errors.append(f"{path} must be a table")


def _validate_list(path: str, value: Any, errors: list[str], required: bool = True) -> None:
    if value is None and not required:
        return
    if not isinstance(value, list):
        errors.append(f"{path} must be a list")


def _validate_string_list_items(path: str, value: Any, errors: list[str]) -> None:
    if not isinstance(value, list):
        return
    for index, item in enumerate(value):
        if not isinstance(item, str) or not item.strip():
            errors.append(f"{path}[{index}] must be a non-empty string")


def _is_int(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def _validate_tcp_port_collisions(config: AppConfig, errors: list[str]) -> None:
    listeners: dict[int, list[str]] = {}

    def add(enabled: bool, port: int, name: str) -> None:
        if not enabled:
            return
        listeners.setdefault(port, []).append(name)

    add(config.dns.enabled, config.dns.tcp_port, "dns.tcp")
    add(config.http.enabled, config.http.port, "http")
    add(config.https.enabled, config.https.port, "https")
    add(config.smtp.enabled, config.smtp.port, "smtp")
    if config.smtp.implicit_tls_port != config.smtp.port:
        add(config.smtp.enabled, config.smtp.implicit_tls_port, "smtp.implicit_tls")
    add(config.ftp.enabled, config.ftp.port, "ftp")
    if config.ftp.implicit_tls_port != config.ftp.port:
        add(config.ftp.enabled, config.ftp.implicit_tls_port, "ftp.implicit_tls")
    add(config.pop3.enabled, config.pop3.port, "pop3")
    if config.pop3.implicit_tls_port != config.pop3.port:
        add(config.pop3.enabled, config.pop3.implicit_tls_port, "pop3.implicit_tls")
    add(config.smb.enabled, config.smb.port, "smb.direct")
    if config.smb.netbios_port != config.smb.port:
        add(config.smb.enabled, config.smb.netbios_port, "smb.netbios")
    add(config.mitmproxy.enabled, config.mitmproxy.port, "mitmproxy")
    add(config.tor_socks.enabled, config.tor_socks.port, "tor_socks")
    add(config.tor_control.enabled, config.tor_control.port, "tor_control")
    if config.tcp_banners.enabled:
        for port in config.tcp_banners.ports:
            add(True, port, f"tcp_banners.{port}")
    if config.dummy.enabled:
        for port in config.dummy.tcp_ports:
            add(True, port, f"dummy.tcp.{port}")

    for port, names in sorted(listeners.items()):
        if port != 0 and len(names) > 1:
            errors.append(f"TCP port {port} is configured by multiple enabled services: {', '.join(names)}")


def _validate_udp_port_collisions(config: AppConfig, errors: list[str]) -> None:
    listeners: dict[int, list[str]] = {}

    def add(enabled: bool, port: int, name: str) -> None:
        if enabled:
            listeners.setdefault(port, []).append(name)

    add(config.dns.enabled, config.dns.udp_port, "dns.udp")
    add(config.ntp.enabled, config.ntp.port, "ntp")
    add(config.tftp.enabled, config.tftp.port, "tftp")
    add(config.quic.enabled, config.quic.port, "quic")
    if config.dummy.enabled:
        for port in config.dummy.udp_ports:
            add(True, port, f"dummy.udp.{port}")

    for port, names in sorted(listeners.items()):
        if port != 0 and len(names) > 1:
            errors.append(f"UDP port {port} is configured by multiple enabled services: {', '.join(names)}")


DEFAULT_CONFIG_TOML = """\
[global]
listen_host = "127.0.0.1"
allowed_clients = ["127.0.0.1/32", "::1/128"]
log_dir = "logs"
artifact_dir = "artifacts"
read_timeout_seconds = 8.0
max_body_bytes = 1048576
max_command_count = 200
max_artifact_bytes = 10485760
fake_time_utc = ""

[services.dns]
enabled = true
udp_port = 1053
tcp_port = 1053
sinkhole_ip = "127.0.0.1"
ttl = 60
wildcard = true

[services.dns.records]
"update.example.test" = "127.0.0.1"

[services.ntp]
enabled = false
port = 10123
stratum = 1

[services.tftp]
enabled = false
port = 10069
allow_uploads = true

[services.tftp.files]
"/README.txt" = "INetSim-Py TFTP service\\n"

[services.http]
enabled = true
port = 18080
server_header = "nginx/1.24.0"
default_status = 200
default_body = "Service unavailable\\n"
login_page_enabled = true
login_page_path = "/"
login_page_brand = "Contoso"
login_page_title = "Enterprise sign in"
login_page_realm = "Work or school account"
fake_downloads_enabled = true

[services.http.fake_download_extensions]
".exe" = "windows_executable"
".dll" = "windows_dll"
".scr" = "windows_executable"
".zip" = "zip"
".pdf" = "pdf"
".doc" = "office_document"
".docx" = "zip"
".xls" = "office_document"
".xlsx" = "zip"
".msi" = "msi"
".js" = "script"
".vbs" = "script"
".ps1" = "script"
".bat" = "script"
".cmd" = "script"
".sh" = "script"
".py" = "script"
".elf" = "linux_executable"
".txt" = "text"

# Exact paths for extensionless downloads; see docs/download-workflow.md.
[services.http.fake_download_routes]

[services.http.routes]
"/robots.txt" = "User-agent: *\\nDisallow:\\n"
"/generate_204" = ""
"/gen_204" = ""
"/hotspot-detect.html" = "<HTML><HEAD><TITLE>Success</TITLE></HEAD><BODY>Success</BODY></HTML>\\n"
"/ncsi.txt" = "Microsoft NCSI\\n"
"/connecttest.txt" = "Microsoft Connect Test\\n"
"/success.txt" = "success\\n"

[services.http.route_statuses]
"/generate_204" = 204
"/gen_204" = 204

[services.https]
enabled = true
port = 18443
cert_file = ""
key_file = ""
auto_generate_cert = true
cert_common_name = "inetsim.local"
prewarm_hosts = []
block_on_unknown_sni = false

[services.smtp]
enabled = true
port = 11025
implicit_tls_port = 0
hostname = "mx01.corp.local"
banner = "ESMTP Postfix"

[services.ftp]
enabled = true
port = 11021
implicit_tls_port = 0
banner = "(vsFTPd 3.0.5)"
pasv_advertise_ip = ""
allow_uploads = true
persist_uploads = false
upload_index = "ftp/uploads/index.json"

[services.ftp.files]
"/README.txt" = "INetSim-Py FTP service\\n"

[services.pop3]
enabled = true
port = 11110
implicit_tls_port = 0
hostname = "mail.corp.local"
banner = "Dovecot ready"
username = "user"
message_from = "postmaster@mail.corp.local"
message_subject = "Quarterly security update"
message_body = "Your mailbox is active. No new action is required.\\n"

[services.smb]
enabled = true
port = 11445
netbios_port = 10139
server_name = "FILESRV01"
workgroup = "CORP"
max_request_bytes = 1048576

[services.mitmproxy]
enabled = false
port = 18088
mode = "regular"
executable = "mitmdump"
block_upstream = true
allow_upstream_hosts = []
synthesize_downloads = true
ssl_insecure = false
body_capture_limit = 1048576
synthetic_status = 200
blocked_status = 502

[services.quic]
enabled = false
port = 443
send_close = true
block = true

[services.tor_socks]
enabled = false
port = 19050

[services.tor_control]
enabled = false
port = 19051
version = "0.4.8.10"

[services.tcp_banners]
enabled = true

[services.tcp_banners.ports]
"12222" = "SSH-2.0-OpenSSH_8.9\\r\\n"

[services.dummy]
enabled = false
max_read_bytes = 4096

[services.dummy.tcp_ports]

[services.dummy.udp_ports]
"""
