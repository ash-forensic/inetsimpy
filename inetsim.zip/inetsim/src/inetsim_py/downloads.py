"""Harmless, fixed download templates. No requested name is interpolated into code."""
from functools import lru_cache
from importlib.resources import files
from pathlib import PurePosixPath


BINARY_TEMPLATES = {
    "windows_executable": "windows-x86.exe",
    "windows_executable_x64": "windows-x64.exe",
    "windows_dll": "windows-x86.dll",
    "windows_dll_x64": "windows-x64.dll",
    "linux_executable": "linux-x64.elf",
}

SCRIPT_TEMPLATES = {
    ".js": b"// Stage completed.\nif (typeof WScript !== 'undefined') { WScript.Quit(0); }\n",
    ".vbs": b"' Stage completed.\r\nWScript.Quit 0\r\n",
    ".ps1": b"# Stage completed.\nexit 0\n",
    ".bat": b"@echo off\r\nrem Stage completed.\r\nexit /b 0\r\n",
    ".cmd": b"@echo off\r\nrem Stage completed.\r\nexit /b 0\r\n",
    ".sh": b"#!/bin/sh\n# Stage completed.\nexit 0\n",
    ".py": b"#!/usr/bin/env python3\n# Stage completed.\nraise SystemExit(0)\n",
}

# EAX/RAX=0; return to caller. Only suitable for a matching no-argument ABI.
# These templates are opt-in and are never selected for arbitrary .bin files.
RETURN_STUBS = {"shellcode_x86": b"\x31\xc0\xc3", "shellcode_x64": b"\x31\xc0\xc3"}

EXPLICIT_SCRIPTS = {
    "shell_script": ".sh", "python_script": ".py", "powershell_script": ".ps1",
    "batch_script": ".cmd", "javascript": ".js", "vbscript": ".vbs",
}


@lru_cache(maxsize=len(BINARY_TEMPLATES))
def binary_template(kind: str) -> bytes:
    return files("inetsim_py").joinpath("data", "downloads", BINARY_TEMPLATES[kind]).read_bytes()


def script_template(requested: str) -> bytes:
    suffix = PurePosixPath(requested).suffix.lower()
    # An ambiguous extension must be configured with an explicit script kind.
    # A JavaScript comment preserves the old generic 'script' fallback.
    return SCRIPT_TEMPLATES.get(suffix, b"// Stage completed.\n")
