from __future__ import annotations

from pathlib import Path
from typing import Any
import asyncio
import contextlib
import json
import uuid

from .timeutils import iso_now, real_now_utc


class EventLogger:
    def __init__(self, log_dir: Path) -> None:
        self._log_dir = log_dir
        self._log_dir.mkdir(parents=True, exist_ok=True)
        _assert_writable_directory(self._log_dir)
        self._lock = asyncio.Lock()
        self._started_at = iso_now()
        self._counts: dict[str, int] = {}

    async def write(self, protocol: str, event: dict[str, Any]) -> None:
        payload = {
            "timestamp": iso_now(),
            "protocol": protocol,
            **event,
        }
        line = json.dumps(payload, sort_keys=True, separators=(",", ":")) + "\n"
        path = self._log_dir / f"{protocol}.jsonl"
        async with self._lock:
            self._counts[protocol] = self._counts.get(protocol, 0) + 1
            await asyncio.to_thread(_append, path, line)

    async def write_session_report(self, services: list[Any], config: Any) -> Path:
        report = {
            "started_at": self._started_at,
            "stopped_at": iso_now(),
            "listen_host": config.global_.listen_host,
            "allowed_clients": config.global_.allowed_clients,
            "fake_time_utc": config.global_.fake_time_utc,
            "log_dir": str(config.global_.log_dir),
            "artifact_dir": str(config.global_.artifact_dir),
            "event_counts": dict(sorted(self._counts.items())),
            "services": [
                {
                    "name": service.name,
                    "tcp_servers": len(service.servers),
                    "udp_transports": len(service.transports),
                    "processes": len(service.processes),
                    "notes": service.notes,
                }
                for service in services
            ],
        }
        suffix = real_now_utc().isoformat().replace(":", "").replace("+", "Z").replace(".", "-")
        suffix = f"{suffix}-{uuid.uuid4().hex[:12]}"
        path = self._log_dir / f"session-{suffix}.json"
        async with self._lock:
            await asyncio.to_thread(_write_json, path, report)
        return path


def _append(path: Path, line: str) -> None:
    with path.open("a", encoding="utf-8") as file_obj:
        file_obj.write(line)


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    with path.open("w", encoding="utf-8") as file_obj:
        json.dump(payload, file_obj, indent=2, sort_keys=True)
        file_obj.write("\n")


def _assert_writable_directory(path: Path) -> None:
    probe = path / ".write-test"
    try:
        with probe.open("a", encoding="utf-8"):
            pass
    finally:
        with contextlib.suppress(OSError):
            probe.unlink()
