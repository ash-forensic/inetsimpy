from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
from ipaddress import ip_address, ip_network
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlsplit
import json
import os

try:
    from mitmproxy import http
except ImportError:  # pragma: no cover - mitmproxy imports this when the optional extra is installed.
    http = None

from inetsim_py.config import FAKE_DOWNLOAD_KINDS, HttpConfig
from inetsim_py.artifacts import artifact_category_path, artifact_filename
from inetsim_py.services.http import _normalize_target_path, fake_download_body, sanitize_header_filename, select_http_payload

_CONFIG: dict[str, Any] | None = None


def request(flow: Any) -> None:
    config = load_config()
    event = flow_event(flow, "request", config)

    if not client_allowed(event.get("client_ip", ""), config.get("allowed_clients", [])):
        body = b"Access denied by proxy policy\n"
        flow.response = http.Response.make(
            403,
            body,
            {
                "Content-Type": "text/plain; charset=utf-8",
                "Content-Length": str(len(body)),
                "Server": server_header(config),
            },
        )
        mark_internal_response(flow, "blocked_client_acl")
        event.update({"action": "blocked_client_acl", "response_status": 403})
        write_event(config, event)
        return

    request_body = bytes(flow.request.raw_content or b"")
    if request_body:
        event["request_body"] = save_artifact(config, "mitmproxy/request", request_body)

    kind = fake_download_kind(config, flow.request.path)
    if bool_setting(config, "synthesize_downloads", True) and kind:
        body, content_type = fake_download_body(_normalize_target_path(flow.request.url or flow.request.path), kind)
        filename = sanitize_header_filename(unquote(Path(urlsplit(flow.request.url).path).name)) or "download.bin"
        status = response_status(config, "synthetic_status", 200)
        flow.response = http.Response.make(
            status,
            body,
            {
                "Content-Type": content_type,
                "Content-Length": str(len(body)),
                "Content-Disposition": f'attachment; filename="{filename}"',
                "Server": server_header(config),
            },
        )
        mark_internal_response(flow, "synthesized")
        event.update(
            {
                "action": "synthesized",
                "response_kind": f"fake_download:{kind}",
                "response_sha256": sha256(body).hexdigest(),
                "response_status": status,
                "response_body": save_artifact(config, "mitmproxy/response", body),
            }
        )
        write_event(config, event)
        return

    if bool_setting(config, "block_upstream", True) and not host_allowed(flow.request.host, config.get("allow_upstream_hosts", [])):
        payload = select_http_payload(http_config(config), flow.request.url or flow.request.path)
        headers = {
            "Content-Type": payload.content_type,
            "Content-Length": str(len(payload.body)),
            "Server": server_header(config),
        }
        if payload.download_name:
            filename = sanitize_header_filename(payload.download_name)
            if filename:
                headers["Content-Disposition"] = f'attachment; filename="{filename}"'
        flow.response = http.Response.make(
            payload.status,
            payload.body,
            headers,
        )
        mark_internal_response(flow, "synthesized_blocked")
        event.update(
            {
                "action": "synthesized_blocked",
                "response_kind": payload.response_kind,
                "response_sha256": sha256(payload.body).hexdigest(),
                "response_status": payload.status,
                "response_body": save_artifact(config, "mitmproxy/response", payload.body),
            }
        )
        write_event(config, event)
        return

    event["action"] = "allowed_upstream"
    write_event(config, event)


def response(flow: Any) -> None:
    config = load_config()
    if is_internal_response(flow):
        return
    event = flow_event(flow, "response", config)
    response = flow.response
    event.update(
        {
            "action": "upstream_response",
            "response_status": getattr(response, "status_code", 0),
            "response_headers": headers_dict(getattr(response, "headers", {})),
        }
    )
    body = bytes(getattr(response, "raw_content", b"") or b"")
    if body:
        event["response_body"] = save_artifact(config, "mitmproxy/response", body)
    write_event(config, event)


def error(flow: Any) -> None:
    config = load_config()
    event = flow_event(flow, "error", config)
    event["error"] = str(getattr(flow, "error", ""))
    write_event(config, event)


def mark_internal_response(flow: Any, action: str) -> None:
    metadata = getattr(flow, "metadata", None)
    if isinstance(metadata, dict):
        metadata["inetsim_py_action"] = action
        return
    try:
        setattr(flow, "_inetsim_py_action", action)
    except Exception:
        return


def is_internal_response(flow: Any) -> bool:
    metadata = getattr(flow, "metadata", None)
    if isinstance(metadata, dict) and metadata.get("inetsim_py_action"):
        return True
    return bool(getattr(flow, "_inetsim_py_action", ""))


def load_config() -> dict[str, Any]:
    global _CONFIG
    if _CONFIG is not None:
        return _CONFIG
    config_path = os.environ.get("INETSIM_MITMPROXY_CONFIG")
    if not config_path:
        _CONFIG = default_config()
        return _CONFIG
    with Path(config_path).open("r", encoding="utf-8") as file_obj:
        loaded = json.load(file_obj)
    defaults = default_config()
    if isinstance(loaded, dict):
        defaults.update(loaded)
    _CONFIG = defaults
    return _CONFIG


def default_config() -> dict[str, Any]:
    return {
        "log_dir": "logs",
        "artifact_dir": "artifacts",
        "server_header": HttpConfig().server_header,
        "allowed_clients": ["127.0.0.1/32", "::1/128"],
        "block_upstream": True,
        "allow_upstream_hosts": [],
        "synthesize_downloads": True,
        "synthetic_status": 200,
        "blocked_status": 502,
        "body_capture_limit": 1048576,
        "fake_download_extensions": HttpConfig().fake_download_extensions,
        "default_status": HttpConfig().default_status,
        "default_body": HttpConfig().default_body,
        "login_page_enabled": HttpConfig().login_page_enabled,
        "login_page_path": HttpConfig().login_page_path,
        "login_page_brand": HttpConfig().login_page_brand,
        "login_page_title": HttpConfig().login_page_title,
        "login_page_realm": HttpConfig().login_page_realm,
        "routes": HttpConfig().routes,
        "route_statuses": HttpConfig().route_statuses,
    }


def server_header(config: dict[str, Any]) -> str:
    value = str(config.get("server_header", HttpConfig().server_header)).strip()
    if not value or any(char in value for char in "\r\n"):
        return HttpConfig().server_header
    if not value.isascii():
        return HttpConfig().server_header
    return value


def flow_event(flow: Any, event_type: str, config: dict[str, Any]) -> dict[str, Any]:
    request_obj = flow.request
    server_conn = getattr(flow, "server_conn", None)
    tls_established = bool(getattr(server_conn, "tls_established", False)) if server_conn else False
    return {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "protocol": "mitmproxy",
        "event_type": event_type,
        "client_ip": client_ip(flow),
        "scheme": getattr(request_obj, "scheme", ""),
        "method": getattr(request_obj, "method", ""),
        "host": getattr(request_obj, "host", ""),
        "port": getattr(request_obj, "port", 0),
        "path": getattr(request_obj, "path", ""),
        "url": getattr(request_obj, "url", ""),
        "http_version": getattr(request_obj, "http_version", ""),
        "request_headers": headers_dict(getattr(request_obj, "headers", {})),
        "tls_established": tls_established,
    }


def client_ip(flow: Any) -> str:
    client_conn = getattr(flow, "client_conn", None)
    for attr in ("peername", "address", "sockname"):
        value = getattr(client_conn, attr, None)
        host = _address_host(value)
        if host:
            return host
    return ""


def _address_host(value: Any) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, (tuple, list)) and value:
        return str(value[0])
    for attr in ("host", "ip", "address"):
        nested = getattr(value, attr, None)
        if nested:
            return str(nested)
    return ""


def client_allowed(address: str, networks: list[str]) -> bool:
    try:
        ip = ip_address(address)
    except ValueError:
        return False
    if ip.version == 6 and ip.ipv4_mapped is not None:
        ip = ip.ipv4_mapped
    if not isinstance(networks, list):
        return False
    for network in networks:
        if not isinstance(network, str):
            continue
        try:
            if ip in ip_network(network, strict=False):
                return True
        except ValueError:
            continue
    return False


def fake_download_kind(config: dict[str, Any], path: str) -> str:
    path = _normalize_target_path(path)
    text_routes = config.get("routes", {})
    if isinstance(text_routes, dict) and path in text_routes:
        return ""
    suffix = Path(path).suffix.lower()
    extensions = config.get("fake_download_extensions", {})
    routes = config.get("fake_download_routes", {})
    kind = routes.get(path, "") if isinstance(routes, dict) else ""
    if not kind and isinstance(extensions, dict):
        kind = extensions.get(suffix, "")
    if not isinstance(kind, str) or kind not in FAKE_DOWNLOAD_KINDS:
        return ""
    return kind


def http_config(config: dict[str, Any]) -> HttpConfig:
    defaults = HttpConfig()
    routes = config.get("routes", defaults.routes)
    route_statuses = config.get("route_statuses", defaults.route_statuses)
    fake_download_extensions = config.get("fake_download_extensions", defaults.fake_download_extensions)
    return HttpConfig(
        server_header=server_header(config),
        default_status=response_status(config, "default_status", defaults.default_status),
        default_body=string_setting(config, "default_body", defaults.default_body),
        login_page_enabled=bool_setting(config, "login_page_enabled", defaults.login_page_enabled),
        login_page_path=string_setting(config, "login_page_path", defaults.login_page_path),
        login_page_brand=string_setting(config, "login_page_brand", defaults.login_page_brand),
        login_page_title=string_setting(config, "login_page_title", defaults.login_page_title),
        login_page_realm=string_setting(config, "login_page_realm", defaults.login_page_realm),
        fake_downloads_enabled=bool_setting(config, "synthesize_downloads", defaults.fake_downloads_enabled),
        fake_download_extensions=fake_download_extensions if isinstance(fake_download_extensions, dict) else defaults.fake_download_extensions,
        fake_download_routes=config.get("fake_download_routes", {}) if isinstance(config.get("fake_download_routes"), dict) else {},
        routes=routes if isinstance(routes, dict) else defaults.routes,
        route_statuses=route_statuses if isinstance(route_statuses, dict) else defaults.route_statuses,
    )


def host_allowed(host: str, patterns: list[str]) -> bool:
    if not isinstance(patterns, list):
        return False
    host = host.rstrip(".").lower()
    for pattern in patterns:
        if not isinstance(pattern, str):
            continue
        value = pattern.rstrip(".").lower()
        if value == "*" or host == value:
            return True
        if value.startswith("*.") and host.endswith(value[1:]):
            return True
    return False


def headers_dict(headers: Any) -> dict[str, str]:
    result: dict[str, str] = {}
    if not hasattr(headers, "items"):
        return result
    try:
        items = headers.items(multi=True)
    except TypeError:
        items = headers.items()
    for key, value in items:
        existing = result.get(str(key))
        result[str(key)] = f"{existing}, {value}" if existing is not None else str(value)
    return result


def response_status(config: dict[str, Any], key: str, default: int) -> int:
    if isinstance(config.get(key, default), bool):
        return default
    try:
        status = int(config.get(key, default))
    except (TypeError, ValueError):
        return default
    if status < 100 or status > 599:
        return default
    return status


def body_capture_limit(config: dict[str, Any]) -> int:
    if isinstance(config.get("body_capture_limit", 1048576), bool):
        return 1048576
    try:
        limit = int(config.get("body_capture_limit", 1048576))
    except (TypeError, ValueError):
        return 1048576
    return max(0, limit)


def bool_setting(config: dict[str, Any], key: str, default: bool) -> bool:
    value = config.get(key, default)
    if not isinstance(value, bool):
        return default
    return value


def string_setting(config: dict[str, Any], key: str, default: str) -> str:
    value = config.get(key, default)
    if not isinstance(value, str):
        return default
    return value


def path_setting(config: dict[str, Any], key: str, default: str) -> Path:
    value = config.get(key, default)
    if not isinstance(value, (str, os.PathLike)):
        return Path(default)
    return Path(value)


def save_artifact(config: dict[str, Any], category: str, data: bytes) -> dict[str, str | int | bool]:
    digest = sha256(data).hexdigest()
    size = len(data)
    limit = body_capture_limit(config)
    if size > limit:
        return {"sha256": digest, "size": size, "captured": False, "limit": limit}
    root = artifact_category_path(path_setting(config, "artifact_dir", "artifacts"), category)
    root.mkdir(parents=True, exist_ok=True)
    path = root / artifact_filename(digest, ".bin")
    if not path.exists():
        path.write_bytes(data)
    return {"sha256": digest, "size": size, "captured": True, "path": str(path)}


def write_event(config: dict[str, Any], event: dict[str, Any]) -> None:
    log_dir = path_setting(config, "log_dir", "logs")
    log_dir.mkdir(parents=True, exist_ok=True)
    with (log_dir / "mitmproxy.jsonl").open("a", encoding="utf-8") as file_obj:
        file_obj.write(json.dumps(event, sort_keys=True, separators=(",", ":")) + "\n")
