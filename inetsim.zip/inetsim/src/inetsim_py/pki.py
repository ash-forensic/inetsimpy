"""Signed, locally served CRLs for the simulator's own CA only."""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from functools import lru_cache
import os
from pathlib import Path
import re
import ssl
import subprocess
import tempfile
import threading
import time
from urllib.parse import urlsplit

_LOCK = threading.RLock()


def crl_url_path(url: str) -> str:
    if not isinstance(url, str) or not re.fullmatch(r'[A-Za-z0-9:/._~\-\[\]]+', url):
        raise ValueError('CRL URL must be an ASCII HTTP URL without credentials, query, fragment or escapes')
    parsed = urlsplit(url)
    if parsed.scheme != 'http' or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError('CRL URL must use plain HTTP so certificate validation does not require another TLS handshake')
    if parsed.port is not None and not 1 <= parsed.port <= 65535:
        raise ValueError('CRL URL port must be between 1 and 65535')
    if not parsed.path.startswith('/') or parsed.path == '/' or '..' in parsed.path.split('/'):
        raise ValueError('CRL URL requires a non-root path without parent traversal')
    return parsed.path


def openssl(*arguments: str) -> str:
    try:
        result = subprocess.run(['openssl', *map(str, arguments)], capture_output=True,
                                text=True, timeout=30)
    except FileNotFoundError as exc:
        raise RuntimeError('managed CRLs require OpenSSL') from exc
    if result.returncode:
        raise RuntimeError(result.stderr.strip() or result.stdout.strip() or 'OpenSSL failed')
    return result.stdout


def certificate_needs_crl(cert: Path, key: Path, url: str) -> bool:
    if not cert.is_file() or not key.is_file():
        return True
    if not url:
        return False
    crl_url_path(url)
    stat = cert.stat()
    return not _has_crl(str(cert.resolve()), url, stat.st_mtime_ns, stat.st_size)


@lru_cache(maxsize=4096)
def _has_crl(cert: str, url: str, mtime: int, size: int) -> bool:
    output = openssl('x509', '-in', cert, '-noout', '-ext', 'crlDistributionPoints')
    return any(line.strip() == 'URI:' + url for line in output.splitlines())


class LabCrl:
    """Manage the CA's signed revocation list, retaining explicit revocations."""

    def __init__(self, artifact_dir: Path):
        tls = Path(artifact_dir).resolve() / 'tls'
        self.ca = tls / 'inetsim-ca.crt'
        self.key = tls / 'inetsim-ca.key'
        self.directory = tls / 'pki'
        self.path = self.directory / 'lab-ca.crl'

    @contextmanager
    def _locked(self):
        self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        with _LOCK, (self.directory / 'lock').open('a+b') as lock:
            if os.name == 'nt':
                import msvcrt
                lock.seek(0, os.SEEK_END)
                if not lock.tell():
                    lock.write(b'0')
                    lock.flush()
                lock.seek(0)
                msvcrt.locking(lock.fileno(), msvcrt.LK_LOCK, 1)
            else:
                import fcntl
                fcntl.flock(lock, fcntl.LOCK_EX)
            try:
                yield
            finally:
                if os.name == 'nt':
                    lock.seek(0)
                    msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    fcntl.flock(lock, fcntl.LOCK_UN)

    def _configuration(self, temporary: Path) -> Path:
        if not self.ca.is_file() or not self.key.is_file():
            raise RuntimeError('start the lab TLS services before managing their CRL')
        for filename, content in [('index.txt', ''), ('crlnumber', '01\n')]:
            path = self.directory / filename
            if not path.exists():
                path.write_text(content)
        # OpenSSL config paths are quoted; reject control characters rather
        # than allowing a path to introduce another config directive.
        def quoted(path):
            value = str(path)
            if any(char in value for char in '\r\n\x00'):
                raise ValueError('invalid PKI path')
            return '"' + value.replace('\\', '/').replace('"', '\\"').replace('$', '\\$') + '"'
        config = temporary / 'ca.cnf'
        config.write_text('\n'.join([
            '[ca]', 'default_ca = lab', '[lab]',
            'database = ' + quoted(self.directory / 'index.txt'),
            'certificate = ' + quoted(self.ca), 'private_key = ' + quoted(self.key),
            'crlnumber = ' + quoted(self.directory / 'crlnumber'),
            'default_md = sha256', 'default_crl_days = 7', 'crl_extensions = crl_ext',
            '[crl_ext]', 'authorityKeyIdentifier = keyid:always', '',
        ]))
        return config

    def refresh(self, force: bool = False) -> bool:
        with self._locked():
            return self._refresh_locked(force)

    def _refresh_locked(self, force: bool) -> bool:
        if self.path.is_file() and not force:
            try:
                output = openssl('crl', '-inform', 'DER', '-in', str(self.path), '-verify',
                                 '-CAfile', str(self.ca), '-noout', '-nextupdate')
                expiration = output.partition('nextUpdate=')[2].strip()
                if ssl.cert_time_to_seconds(expiration) > time.time() + 86400:
                    return False
            except (RuntimeError, ValueError):
                pass
        with tempfile.TemporaryDirectory(dir=self.directory) as directory:
            temporary = Path(directory)
            config = self._configuration(temporary)
            now = datetime.now(timezone.utc)
            pem, der = temporary / 'crl.pem', temporary / 'crl.der'
            openssl('ca', '-batch', '-config', str(config), '-gencrl',
                    '-crl_lastupdate', (now - timedelta(minutes=5)).strftime('%Y%m%d%H%M%SZ'),
                    '-crl_nextupdate', (now + timedelta(days=7)).strftime('%Y%m%d%H%M%SZ'),
                    '-out', str(pem))
            openssl('crl', '-in', str(pem), '-outform', 'DER', '-out', str(der))
            openssl('crl', '-inform', 'DER', '-in', str(der), '-verify', '-CAfile', str(self.ca), '-noout')
            # Never expose a partially written CRL to an HTTP client.
            der.replace(self.path)
        return True

    def revoke(self, certificate: Path) -> None:
        certificate = certificate.resolve()
        with self._locked(), tempfile.TemporaryDirectory(dir=self.directory) as directory:
            openssl('verify', '-no_check_time', '-CAfile', str(self.ca), str(certificate))
            fingerprint = openssl('x509', '-in', str(certificate), '-noout', '-fingerprint', '-sha256')
            if fingerprint == openssl('x509', '-in', str(self.ca), '-noout', '-fingerprint', '-sha256'):
                raise ValueError('this command revokes leaf certificates, not the trust anchor')
            config = self._configuration(Path(directory))
            openssl('ca', '-batch', '-config', str(config), '-revoke', str(certificate))
            self._refresh_locked(True)
