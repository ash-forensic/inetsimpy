from __future__ import annotations

import asyncio
import contextlib

from .acl import SubnetAcl
from .artifacts import ArtifactStore
from .config import AppConfig
from .logger import EventLogger
from .services import DnsService, DummyService, FtpService, HttpService, HttpsService, MitmProxyService, NtpService, Pop3Service, QuicService, SmbService, SmtpService, TcpBannerService, TftpService, TorControlService, TorSocksService
from .services.base import RunningService
from .timeutils import configure_fake_time


class InetSimPy:
    def __init__(self, config: AppConfig) -> None:
        self._config = config
        configure_fake_time(config.global_.fake_time_utc)
        self._acl = SubnetAcl(config.global_.allowed_clients)
        self._logger = EventLogger(config.global_.log_dir)
        self._artifacts = ArtifactStore(config.global_.artifact_dir, config.global_.max_artifact_bytes)
        self._running: list[RunningService] = []

    async def start(self) -> list[RunningService]:
        try:
            if self._config.dns.enabled:
                self._running.append(await DnsService(self._config.dns, self._config.global_, self._logger, self._acl).start())
            if self._config.ntp.enabled:
                self._running.append(await NtpService(self._config.ntp, self._config.global_, self._logger, self._acl).start())
            if self._config.tftp.enabled:
                self._running.append(await TftpService(self._config.tftp, self._config.global_, self._logger, self._artifacts, self._acl).start())
            if self._config.http.enabled:
                self._running.append(await HttpService(self._config.http, self._config.global_, self._logger, self._artifacts, self._acl, self._config.dns if self._config.dns.enabled else None).start())
            if self._config.https.enabled:
                self._running.append(await HttpsService(self._config.https, self._config.http, self._config.global_, self._logger, self._artifacts, self._acl, self._config.dns if self._config.dns.enabled else None).start())
            if self._config.smtp.enabled:
                self._running.append(await SmtpService(self._config.smtp, self._config.global_, self._logger, self._artifacts, self._acl).start())
            if self._config.ftp.enabled:
                self._running.append(await FtpService(self._config.ftp, self._config.global_, self._logger, self._artifacts, self._acl).start())
            if self._config.pop3.enabled:
                self._running.append(await Pop3Service(self._config.pop3, self._config.global_, self._logger, self._acl).start())
            if self._config.smb.enabled:
                self._running.append(await SmbService(self._config.smb, self._config.global_, self._logger, self._acl).start())
            if self._config.mitmproxy.enabled:
                self._running.append(await MitmProxyService(self._config.mitmproxy, self._config.http, self._config.global_).start())
            if self._config.quic.enabled:
                self._running.append(await QuicService(self._config.quic, self._config.global_, self._logger, self._acl).start())
            if self._config.tor_socks.enabled:
                self._running.append(await TorSocksService(self._config.tor_socks, self._config.http, self._config.global_, self._logger, self._artifacts, self._acl).start())
            if self._config.tor_control.enabled:
                self._running.append(await TorControlService(self._config.tor_control, self._config.tor_socks, self._config.global_, self._logger, self._acl).start())
            if self._config.tcp_banners.enabled:
                self._running.append(await TcpBannerService(self._config.tcp_banners, self._config.global_, self._logger, self._acl).start())
            if self._config.dummy.enabled:
                self._running.append(await DummyService(self._config.dummy, self._config.global_, self._logger, self._acl).start())
        except Exception:
            await self.stop()
            raise
        return self._running

    async def stop(self) -> None:
        for service in self._running:
            service.close()
        for service in self._running:
            with contextlib.suppress(Exception):
                await service.wait_closed()
        if self._running:
            with contextlib.suppress(Exception):
                await self._logger.write_session_report(self._running, self._config)
        self._running.clear()

    async def serve_forever(self) -> None:
        await self.start()
        try:
            await asyncio.Event().wait()
        finally:
            await self.stop()
