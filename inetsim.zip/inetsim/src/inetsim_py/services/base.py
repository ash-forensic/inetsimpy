from __future__ import annotations

import asyncio
import contextlib
from dataclasses import dataclass, field


@dataclass(slots=True)
class RunningService:
    name: str
    servers: list[asyncio.AbstractServer]
    transports: list[asyncio.DatagramTransport]
    processes: list[asyncio.subprocess.Process] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    tasks: list[asyncio.Task] = field(default_factory=list)

    def close(self) -> None:
        for task in self.tasks:
            task.cancel()
        for server in self.servers:
            server.close()
        for transport in self.transports:
            transport.close()
        for process in self.processes:
            if process.returncode is None:
                process.terminate()

    async def wait_closed(self) -> None:
        for task in self.tasks:
            with contextlib.suppress(asyncio.CancelledError):
                await task
        for server in self.servers:
            await server.wait_closed()
        for transport in self.transports:
            protocol = getattr(transport, "get_protocol", lambda: None)()
            service = getattr(protocol, "_service", None)
            cleanup_task = getattr(service, "_cleanup_task", None)
            if cleanup_task is not None:
                cleanup_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await cleanup_task
        for process in self.processes:
            if process.returncode is not None:
                continue
            with contextlib.suppress(asyncio.TimeoutError):
                await asyncio.wait_for(process.wait(), timeout=3)
            if process.returncode is None:
                process.kill()
                await process.wait()


async def close_writer(writer: asyncio.StreamWriter) -> None:
    writer.close()
    with contextlib.suppress(OSError):
        await writer.wait_closed()
