from __future__ import annotations

from dataclasses import dataclass
from ipaddress import ip_address
from typing import Any
import asyncio
import struct

from ..acl import SubnetAcl
from ..config import DnsConfig, GlobalConfig
from ..logger import EventLogger
from .base import RunningService, close_writer

QTYPE_A = 1
QTYPE_NS = 2
QTYPE_CNAME = 5
QTYPE_SOA = 6
QTYPE_MX = 15
QTYPE_TXT = 16
QTYPE_AAAA = 28
QTYPE_SRV = 33
QCLASS_IN = 1


@dataclass(slots=True)
class DnsQuestion:
    name: str
    labels: list[str]
    qtype: int
    qclass: int
    question_end: int


class DnsService:
    def __init__(self, config: DnsConfig, global_config: GlobalConfig, logger: EventLogger, acl: SubnetAcl) -> None:
        self._config = config
        self._global = global_config
        self._logger = logger
        self._acl = acl

    async def start(self) -> RunningService:
        loop = asyncio.get_running_loop()
        transport, _ = await loop.create_datagram_endpoint(lambda: _DnsUdpProtocol(self), local_addr=(self._global.listen_host, self._config.udp_port))
        try:
            tcp_server = await asyncio.start_server(self._handle_tcp, self._global.listen_host, self._config.tcp_port)
        except BaseException:
            transport.close()
            raise
        return RunningService("dns", [tcp_server], [transport])

    async def handle_udp(self, data: bytes, peer: tuple[str, int], transport: asyncio.DatagramTransport) -> None:
        if not self._acl.allows(peer[0]):
            return
        response, event = self._build_response(data, peer[0], "udp")
        await self._logger.write("dns", event)
        if response:
            transport.sendto(response, peer)

    async def _handle_tcp(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        peer_info = writer.get_extra_info("peername")
        peer = str(peer_info[0]) if peer_info else ""
        if not peer or not self._acl.allows(peer):
            await close_writer(writer)
            return
        try:
            for _ in range(max(1, self._global.max_command_count)):
                try:
                    size_bytes = await asyncio.wait_for(reader.readexactly(2), timeout=self._global.read_timeout_seconds)
                except asyncio.IncompleteReadError as exc:
                    if not exc.partial:
                        break
                    raise
                size = struct.unpack("!H", size_bytes)[0]
                if size > self._global.max_body_bytes:
                    raise ValueError("DNS TCP frame exceeds global.max_body_bytes")
                data = await asyncio.wait_for(reader.readexactly(size), timeout=self._global.read_timeout_seconds)
                response, event = self._build_response(data, peer, "tcp")
                await self._logger.write("dns", event)
                if not response:
                    break
                writer.write(struct.pack("!H", len(response)) + response)
                await writer.drain()
        except Exception as exc:
            await self._logger.write("dns", {"client_ip": peer, "transport": "tcp", "error": exc.__class__.__name__})
        finally:
            await close_writer(writer)

    def _build_response(self, data: bytes, client_ip: str, transport: str) -> tuple[bytes, dict[str, Any]]:
        event: dict[str, Any] = {"client_ip": client_ip, "transport": transport}
        try:
            question = parse_question(data)
            event.update({"query": question.name, "qtype": question.qtype, "qclass": question.qclass})
            answer = self._answer_record(question)
            known_name = self._known_name(question.name)
            event["answer"] = answer.text if answer else ""
            return build_record_response(data, question, answer, self._config.ttl, rcode=0 if known_name else 3), event
        except Exception as exc:
            event["error"] = exc.__class__.__name__
            return b"", event

    def _known_name(self, name: str) -> bool:
        normalized = name.rstrip(".").lower()
        return (
            normalized in self._config.records
            or normalized in self._config.mx_records
            or normalized in self._config.txt_records
            or normalized in self._config.cname_records
            or normalized in self._config.ns_records
            or normalized in self._config.srv_records
            or self._config.wildcard
        )

    def _answer_record(self, question: DnsQuestion) -> "DnsAnswer | None":
        if question.qclass != QCLASS_IN:
            return None
        name = question.name.rstrip(".").lower()
        if question.qtype in {QTYPE_A, QTYPE_AAAA}:
            answer = self._config.records.get(name)
            if answer is None and self._config.wildcard:
                answer = self._wildcard_answer(question.qtype)
            if answer is None:
                return None
            ip = ip_address(answer)
            if question.qtype == QTYPE_A and ip.version == 4:
                return DnsAnswer(QTYPE_A, ip.packed, answer)
            if question.qtype == QTYPE_AAAA and ip.version == 6:
                return DnsAnswer(QTYPE_AAAA, ip.packed, answer)
            return None
        if question.qtype == QTYPE_CNAME and name in self._config.cname_records:
            target = self._config.cname_records[name]
            return DnsAnswer(QTYPE_CNAME, encode_name(target), target)
        if question.qtype == QTYPE_NS and name in self._config.ns_records:
            target = self._config.ns_records[name]
            return DnsAnswer(QTYPE_NS, encode_name(target), target)
        if question.qtype == QTYPE_MX and name in self._config.mx_records:
            target = self._config.mx_records[name]
            return DnsAnswer(QTYPE_MX, struct.pack("!H", 10) + encode_name(target), target)
        if question.qtype == QTYPE_TXT and name in self._config.txt_records:
            text = self._config.txt_records[name].encode("utf-8", "replace")[:255]
            return DnsAnswer(QTYPE_TXT, bytes([len(text)]) + text, self._config.txt_records[name])
        if question.qtype == QTYPE_SRV and name in self._config.srv_records:
            target = self._config.srv_records[name]
            priority, weight, port, host = _parse_srv_value(target)
            return DnsAnswer(QTYPE_SRV, struct.pack("!HHH", priority, weight, port) + encode_name(host), target)
        return None

    def _wildcard_answer(self, qtype: int) -> str | None:
        legacy_ip = ip_address(self._config.sinkhole_ip)
        if qtype == QTYPE_A:
            if self._config.sinkhole_ipv4:
                return self._config.sinkhole_ipv4
            if legacy_ip.version == 4:
                return self._config.sinkhole_ip
        if qtype == QTYPE_AAAA:
            if self._config.sinkhole_ipv6:
                return self._config.sinkhole_ipv6
            if legacy_ip.version == 6:
                return self._config.sinkhole_ip
        return None


@dataclass(slots=True)
class DnsAnswer:
    rr_type: int
    rdata: bytes
    text: str


class _DnsUdpProtocol(asyncio.DatagramProtocol):
    def __init__(self, service: DnsService) -> None:
        self._service = service
        self._transport: asyncio.DatagramTransport | None = None

    def connection_made(self, transport: asyncio.BaseTransport) -> None:
        self._transport = transport  # type: ignore[assignment]

    def datagram_received(self, data: bytes, addr: tuple[str, int]) -> None:
        if self._transport is None:
            return
        asyncio.create_task(self._service.handle_udp(data, addr, self._transport))


def parse_question(data: bytes) -> DnsQuestion:
    if len(data) < 12:
        raise ValueError("short DNS message")
    qdcount = struct.unpack("!H", data[4:6])[0]
    if qdcount != 1:
        raise ValueError("only one question is supported")
    labels, offset = _read_name(data, 12)
    if offset + 4 > len(data):
        raise ValueError("truncated question")
    qtype, qclass = struct.unpack("!HH", data[offset : offset + 4])
    return DnsQuestion(".".join(labels).lower(), labels, qtype, qclass, offset + 4)


def _read_name(data: bytes, offset: int) -> tuple[list[str], int]:
    labels: list[str] = []
    end_offset = offset
    jumped = False
    seen_offsets: set[int] = set()
    wire_length = 1
    while True:
        if offset >= len(data):
            raise ValueError("truncated name")
        if offset in seen_offsets:
            raise ValueError("compressed name loop")
        seen_offsets.add(offset)
        length = data[offset]
        offset += 1
        if length == 0:
            if not jumped:
                end_offset = offset
            break
        if length & 0xC0 == 0xC0:
            if offset >= len(data):
                raise ValueError("truncated compression pointer")
            pointer = ((length & 0x3F) << 8) | data[offset]
            offset += 1
            if not jumped:
                end_offset = offset
            offset = pointer
            jumped = True
            continue
        if length & 0xC0:
            raise ValueError("invalid DNS label")
        if length > 63:
            raise ValueError("DNS label exceeds 63 octets")
        if offset + length > len(data):
            raise ValueError("truncated label")
        wire_length += 1 + length
        if wire_length > 255:
            raise ValueError("DNS name exceeds 255 octets")
        labels.append(_decode_label(data[offset : offset + length]))
        offset += length
        if not jumped:
            end_offset = offset
    return labels, end_offset


def _decode_label(value: bytes) -> str:
    try:
        return value.decode("ascii")
    except UnicodeDecodeError as exc:
        raise ValueError("DNS label contains non-ASCII bytes") from exc


def build_response(query: bytes, question: DnsQuestion, answer_ip: str | None, ttl: int, rcode: int = 3) -> bytes:
    answer = None
    if answer_ip:
        ip = ip_address(answer_ip)
        answer = DnsAnswer(QTYPE_A if ip.version == 4 else QTYPE_AAAA, ip.packed, answer_ip)
    return build_record_response(query, question, answer, ttl, rcode)


def build_record_response(query: bytes, question: DnsQuestion, answer: DnsAnswer | None, ttl: int, rcode: int = 3) -> bytes:
    query_id = query[:2]
    question_bytes = encode_question(question)
    flags = b"\x81" + bytes([0x80 | (rcode & 0x0F)])
    ancount = 1 if answer else 0
    header = query_id + flags + struct.pack("!HHHH", 1, ancount, 0, 0)
    if answer is None:
        return header + question_bytes

    rr = b"\xc0\x0c" + struct.pack("!HHIH", answer.rr_type, QCLASS_IN, ttl, len(answer.rdata)) + answer.rdata
    return header + question_bytes + rr


def encode_question(question: DnsQuestion) -> bytes:
    name = b"".join(bytes([len(label)]) + label.encode("ascii") for label in question.labels)
    return name + b"\x00" + struct.pack("!HH", question.qtype, question.qclass)


def encode_name(name: str) -> bytes:
    return b"".join(bytes([len(label)]) + label.encode("ascii") for label in name.rstrip(".").split(".")) + b"\x00"


def _parse_srv_value(value: str) -> tuple[int, int, int, str]:
    parts = value.split()
    if len(parts) == 4 and all(part.isdigit() for part in parts[:3]):
        return int(parts[0]), int(parts[1]), int(parts[2]), parts[3]
    return 0, 0, 443, value
