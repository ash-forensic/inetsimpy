from __future__ import annotations

from hashlib import sha256
from typing import Any
import asyncio
import errno

from ..acl import SubnetAcl
from ..config import DummyConfig, GlobalConfig
from ..logger import EventLogger
from .base import RunningService, close_writer


class DummyService:
    def __init__(self, config: DummyConfig, global_config: GlobalConfig, logger: EventLogger, acl: SubnetAcl) -> None:
        self._config = config
        self._global = global_config
        self._logger = logger
        self._acl = acl

    async def start(self) -> RunningService:
        servers = []
        notes = ["dummy service logs unknown redirected TCP/UDP traffic and returns configured static responses"]
        for port, response in self._config.tcp_ports.items():
            try:
                servers.append(await asyncio.start_server(lambda r, w, port=port, response=response: self._handle_tcp(port, response, r, w), self._global.listen_host, port))
            except OSError as exc:
                if exc.errno == errno.EADDRINUSE:
                    notes.append(f"dummy tcp port {port} was in use; skipped")
                    continue
                raise
        transports = []
        loop = asyncio.get_running_loop()
        for port, response in self._config.udp_ports.items():
            try:
                transport, _ = await loop.create_datagram_endpoint(lambda port=port, response=response: _DummyUdpProtocol(self, port, response), local_addr=(self._global.listen_host, port))
                transports.append(transport)
            except OSError as exc:
                if exc.errno == errno.EADDRINUSE:
                    notes.append(f"dummy udp port {port} was in use; skipped")
                    continue
                raise
        return RunningService("dummy", servers, transports, notes=notes)

    async def _handle_tcp(self, port: int, response: str, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        peer = _peer(writer)
        if peer is None or not self._acl.allows(peer):
            await close_writer(writer)
            return
        event: dict[str, Any] = {"client_ip": peer, "transport": "tcp", "port": port}
        try:
            if response:
                writer.write(response.encode("utf-8", "replace"))
                await writer.drain()
                data = await _read_available(reader, self._config.max_read_bytes)
            else:
                data = await asyncio.wait_for(reader.read(self._config.max_read_bytes), timeout=self._global.read_timeout_seconds)
            if data:
                event["client_bytes"] = len(data)
                event["client_sha256"] = sha256(data).hexdigest()
        except Exception as exc:
            event["error"] = exc.__class__.__name__
        finally:
            await self._logger.write("dummy", event)
            await close_writer(writer)

    async def handle_udp(self, port: int, response: str, data: bytes, peer: tuple[str, int], transport: asyncio.DatagramTransport) -> None:
        if not self._acl.allows(peer[0]):
            return
        event = {"client_ip": peer[0], "client_port": peer[1], "transport": "udp", "port": port, "client_bytes": len(data), "client_sha256": sha256(data).hexdigest()}
        if response:
            transport.sendto(response.encode("utf-8", "replace"), peer)
            event["response_size"] = len(response.encode("utf-8", "replace"))
        await self._logger.write("dummy", event)


class _DummyUdpProtocol(asyncio.DatagramProtocol):
    def __init__(self, service: DummyService, port: int, response: str) -> None:
        self._service = service
        self._port = port
        self._response = response
        self._transport: asyncio.DatagramTransport | None = None

    def connection_made(self, transport: asyncio.BaseTransport) -> None:
        self._transport = transport  # type: ignore[assignment]

    def datagram_received(self, data: bytes, addr: tuple[str, int]) -> None:
        if self._transport is not None:
            asyncio.create_task(self._service.handle_udp(self._port, self._response, data, addr, self._transport))


def _peer(writer: asyncio.StreamWriter) -> str | None:
    peer = writer.get_extra_info("peername")
    if not peer:
        return None
    return str(peer[0])


async def _read_available(reader: asyncio.StreamReader, limit: int) -> bytes:
    try:
        return await asyncio.wait_for(reader.read(limit), timeout=0.05)
    except asyncio.TimeoutError:
        return b""
