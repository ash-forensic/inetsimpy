from __future__ import annotations

from hashlib import sha256
from pathlib import Path, PurePosixPath
from typing import Any
import asyncio
import contextlib
import json
import ssl

from ..acl import SubnetAcl
from ..artifacts import ArtifactStore
from ..config import FtpConfig, GlobalConfig
from ..logger import EventLogger
from .base import RunningService, close_writer
from .smtp import _service_tls_context


class FtpService:
    def __init__(self, config: FtpConfig, global_config: GlobalConfig, logger: EventLogger, artifacts: ArtifactStore, acl: SubnetAcl) -> None:
        self._config = config
        self._global = global_config
        self._logger = logger
        self._artifacts = artifacts
        self._acl = acl
        self._files = {path: body.encode("utf-8") for path, body in config.files.items()}
        self._artifact_files: dict[str, str] = {}

    async def start(self) -> RunningService:
        self._load_persisted_uploads()
        servers = [await asyncio.start_server(lambda r, w: self._handle_client(r, w, implicit_tls=False), self._global.listen_host, self._config.port)]
        if self._config.implicit_tls_port:
            servers.append(
                await asyncio.start_server(
                    lambda r, w: self._handle_client(r, w, implicit_tls=True),
                    self._global.listen_host,
                    self._config.implicit_tls_port,
                    ssl=_service_tls_context(self._global.artifact_dir, "ftp.local", self._global.tls_crl_url),
                )
            )
        return RunningService("ftp", servers, [])

    async def _handle_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter, implicit_tls: bool = False) -> None:
        peer = _peer(writer)
        if peer is None or not self._acl.allows(peer):
            await close_writer(writer)
            return

        event: dict[str, Any] = {"client_ip": peer, "commands": []}
        if implicit_tls:
            event["tls_established"] = True
            event["implicit_tls"] = True
        data_server: asyncio.AbstractServer | None = None
        data_state: dict[str, Any] = {"mode": "", "payload": b"", "client_ip": peer, "tls_context": None}
        data_upload: dict[str, Any] = {}
        cwd = "/"
        writer.write(f"220 {self._config.banner}\r\n".encode("ascii"))
        await writer.drain()
        try:
            while True:
                line = await asyncio.wait_for(reader.readline(), timeout=self._global.read_timeout_seconds)
                if not line:
                    break
                text = line.decode("utf-8", "replace").rstrip("\r\n")
                if not text:
                    continue
                command, argument = _split_command(text)
                _record_command(event, _sanitize_command(command, argument), self._global.max_command_count)
                if command == "PASS":
                    event["password_length"] = len(argument)
                    event["password_sha256"] = sha256(argument.encode("utf-8", "replace")).hexdigest()

                if command == "USER":
                    event["username"] = argument
                    writer.write(b"331 password required\r\n")
                elif command == "PASS":
                    writer.write(b"230 logged in\r\n")
                elif command == "SYST":
                    writer.write(b"215 UNIX Type: L8\r\n")
                elif command == "PWD":
                    writer.write(f'257 "{cwd}" is current directory\r\n'.encode("ascii"))
                elif command == "CWD":
                    cwd = _normalize_ftp_path(argument or "/", cwd)
                    event["cwd"] = cwd
                    writer.write(b"250 directory changed\r\n")
                elif command == "CDUP":
                    cwd = _parent_dir(cwd)
                    event["cwd"] = cwd
                    writer.write(b"250 directory changed\r\n")
                elif command in {"MKD", "RMD", "DELE"}:
                    path = _normalize_ftp_path(argument, cwd)
                    if command == "DELE":
                        self._files.pop(path, None)
                        self._artifact_files.pop(path, None)
                        if self._config.persist_uploads:
                            _write_upload_index(self._upload_index_path(), self._artifact_files)
                    event["filesystem_command"] = command.lower()
                    event["filesystem_path"] = path
                    writer.write(b"250 file action completed\r\n")
                elif command == "TYPE":
                    writer.write(b"200 type set\r\n")
                elif command == "AUTH" and argument.upper() == "TLS":
                    event["tls_requested"] = True
                    writer.write(b"234 proceed with negotiation\r\n")
                    await writer.drain()
                    try:
                        await asyncio.wait_for(writer.start_tls(_service_tls_context(self._global.artifact_dir, "ftp.local", self._global.tls_crl_url)), timeout=min(self._global.read_timeout_seconds, 1.0))
                        event["tls_established"] = True
                    except (AttributeError, ssl.SSLError, OSError) as exc:
                        event["tls_error"] = exc.__class__.__name__
                        break
                elif command == "PBSZ":
                    writer.write(b"200 protection command accepted\r\n")
                elif command == "PROT":
                    if argument.upper() == "P" and event.get("tls_established"):
                        data_state["tls_context"] = _service_tls_context(self._global.artifact_dir, "ftp.local", self._global.tls_crl_url)
                        writer.write(b"200 private data protection enabled\r\n")
                    elif argument.upper() == "C":
                        data_state["tls_context"] = None
                        writer.write(b"200 clear data protection enabled\r\n")
                    else:
                        writer.write(b"536 unsupported data protection level\r\n")
                elif command == "CCC":
                    writer.write(b"534 clear command channel is not enabled\r\n")
                elif command in {"PASV", "EPSV"}:
                    if data_server is not None:
                        data_server.close()
                        await data_server.wait_closed()
                    data_server, data_port = await _start_data_server(self._global.listen_host, data_state, data_upload, self._global.read_timeout_seconds, self._global.max_body_bytes)
                    event["data_port"] = data_port
                    local_host = self._config.pasv_advertise_ip or _local_host(writer)
                    if command == "EPSV":
                        writer.write(f"229 entering extended passive mode (|||{data_port}|)\r\n".encode("ascii"))
                    else:
                        writer.write(_pasv_response(local_host, data_port))
                elif command in {"LIST", "NLST"}:
                    list_path = _normalize_ftp_path(argument, cwd) if argument else cwd
                    data_state["mode"] = "download"
                    data_state["payload"] = _list_payload(self._virtual_files(), list_path, long_format=command == "LIST")
                    data_state["done"] = asyncio.Event()
                    data_state["ok"] = False
                    if data_server is None:
                        data_server, data_port = await _start_data_server(self._global.listen_host, data_state, data_upload, self._global.read_timeout_seconds, self._global.max_body_bytes)
                        event["data_port"] = data_port
                    writer.write(b"150 opening data connection\r\n")
                    await writer.drain()
                    ok = await _wait_transfer_done(data_state, self._global.read_timeout_seconds)
                    writer.write(b"226 transfer complete\r\n" if ok else b"425 can't open data connection\r\n")
                    event["data_transfer"] = command.lower()
                    event["data_path"] = list_path
                    event["data_complete"] = ok
                    if data_server is not None:
                        data_server.close()
                        await data_server.wait_closed()
                        data_server = None
                elif command == "RETR":
                    path = _normalize_ftp_path(argument or "README.txt", cwd)
                    if path in self._artifact_files and not self._resolve_artifact_path(self._artifact_files[path]).is_file():
                        self._artifact_files.pop(path, None)
                        if self._config.persist_uploads:
                            _write_upload_index(self._upload_index_path(), self._artifact_files)
                        writer.write(b"550 file not found\r\n")
                        await writer.drain()
                        continue
                    data_state["mode"] = "download"
                    data_state["payload"] = self._file_payload(path)
                    data_state["done"] = asyncio.Event()
                    data_state["ok"] = False
                    if data_server is None:
                        data_server, data_port = await _start_data_server(self._global.listen_host, data_state, data_upload, self._global.read_timeout_seconds, self._global.max_body_bytes)
                        event["data_port"] = data_port
                    writer.write(b"150 opening data connection\r\n")
                    await writer.drain()
                    ok = await _wait_transfer_done(data_state, self._global.read_timeout_seconds)
                    writer.write(b"226 transfer complete\r\n" if ok else b"425 can't open data connection\r\n")
                    event["data_transfer"] = "retr"
                    event["data_path"] = path
                    event["data_complete"] = ok
                    if data_server is not None:
                        data_server.close()
                        await data_server.wait_closed()
                        data_server = None
                elif command == "STOR":
                    path = _normalize_ftp_path(argument or "upload.bin", cwd)
                    if not self._config.allow_uploads:
                        writer.write(b"550 uploads disabled\r\n")
                        await writer.drain()
                        continue
                    data_state["mode"] = "upload"
                    data_state["payload"] = b""
                    data_state["done"] = asyncio.Event()
                    data_state["ok"] = False
                    data_upload.clear()
                    data_upload["path"] = path
                    data_upload["complete"] = False
                    if data_server is None:
                        data_server, data_port = await _start_data_server(self._global.listen_host, data_state, data_upload, self._global.read_timeout_seconds, self._global.max_body_bytes)
                        event["data_port"] = data_port
                    writer.write(b"150 opening data connection\r\n")
                    await writer.drain()
                    ok = await _wait_transfer_done(data_state, self._global.read_timeout_seconds)
                    if ok and "data" in data_upload:
                        _finalize_upload(data_upload, self._files, self._artifact_files, self._artifacts, self._global.artifact_dir, self._config.persist_uploads, self._upload_index_path(), event)
                        writer.write(b"226 transfer complete\r\n" if data_upload.get("complete") else b"552 upload exceeds configured limit\r\n")
                    else:
                        writer.write(b"425 can't open data connection\r\n")
                    event["data_transfer"] = "stor"
                    event["data_path"] = path
                    event["data_complete"] = ok
                    if data_server is not None:
                        data_server.close()
                        await data_server.wait_closed()
                        data_server = None
                elif command == "SIZE":
                    path = _normalize_ftp_path(argument, cwd)
                    if path in self._files:
                        writer.write(f"213 {len(self._files[path])}\r\n".encode("ascii"))
                    elif path in self._artifact_files:
                        try:
                            writer.write(f"213 {self._resolve_artifact_path(self._artifact_files[path]).stat().st_size}\r\n".encode("ascii"))
                        except OSError:
                            self._artifact_files.pop(path, None)
                            if self._config.persist_uploads:
                                _write_upload_index(self._upload_index_path(), self._artifact_files)
                            writer.write(b"550 file not found\r\n")
                    else:
                        writer.write(f"213 {len(_file_payload(self._files, path))}\r\n".encode("ascii"))
                elif command == "MDTM":
                    writer.write(b"213 20240101000000\r\n")
                elif command == "FEAT":
                    writer.write(b"211-Features\r\n AUTH TLS\r\n PBSZ\r\n PROT\r\n PASV\r\n EPSV\r\n SIZE\r\n MDTM\r\n MLST type*;size*;modify*;\r\n211 end\r\n")
                elif command == "QUIT":
                    writer.write(b"221 bye\r\n")
                    await writer.drain()
                    break
                else:
                    writer.write(b"200 ok\r\n")
                await writer.drain()
        except Exception as exc:
            event["error"] = exc.__class__.__name__
        finally:
            if data_upload and "data" in data_upload and "data_upload_size" not in event:
                _finalize_upload(data_upload, self._files, self._artifact_files, self._artifacts, self._global.artifact_dir, self._config.persist_uploads, self._upload_index_path(), event)
            if data_server is not None:
                data_server.close()
                with contextlib.suppress(Exception):
                    await data_server.wait_closed()
            await self._logger.write("ftp", event)
            await close_writer(writer)

    def _upload_index_path(self) -> Any:
        return self._global.artifact_dir / self._config.upload_index

    def _virtual_files(self) -> dict[str, bytes]:
        merged = dict(self._files)
        stale = []
        for path, artifact_path in self._artifact_files.items():
            try:
                size = self._resolve_artifact_path(artifact_path).stat().st_size
            except OSError:
                stale.append(path)
                continue
            merged.setdefault(path, b"\x00" * size)
        for path in stale:
            self._artifact_files.pop(path, None)
        if stale and self._config.persist_uploads:
            _write_upload_index(self._upload_index_path(), self._artifact_files)
        return merged

    def _file_payload(self, path: str) -> bytes:
        if path in self._artifact_files:
            try:
                return self._resolve_artifact_path(self._artifact_files[path]).read_bytes()
            except OSError:
                self._artifact_files.pop(path, None)
                if self._config.persist_uploads:
                    _write_upload_index(self._upload_index_path(), self._artifact_files)
                return b""
        return _file_payload(self._files, path)

    def _load_persisted_uploads(self) -> None:
        if not self._config.persist_uploads:
            return
        index_path = self._upload_index_path()
        try:
            payload = json.loads(index_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return
        entries = payload.get("files") if isinstance(payload, dict) else None
        if not isinstance(entries, dict):
            return
        for virtual_path, metadata in entries.items():
            if not isinstance(virtual_path, str) or not isinstance(metadata, dict):
                continue
            artifact_path = metadata.get("path")
            if not isinstance(artifact_path, str):
                continue
            if not _valid_virtual_path(virtual_path):
                continue
            try:
                resolved = self._resolve_artifact_path(artifact_path)
            except ValueError:
                continue
            if resolved.is_file():
                self._artifact_files[virtual_path] = _artifact_relative_path(self._global.artifact_dir, resolved)

    def _resolve_artifact_path(self, artifact_path: str) -> Any:
        root = self._global.artifact_dir.resolve()
        candidate = Path(artifact_path)
        if candidate.is_absolute():
            resolved = candidate.resolve()
        elif candidate.parts and candidate.parts[0] == self._global.artifact_dir.name:
            resolved = (self._global.artifact_dir / Path(*candidate.parts[1:])).resolve()
        else:
            resolved = (self._global.artifact_dir / candidate).resolve()
        resolved.relative_to(root)
        return resolved


def _split_command(text: str) -> tuple[str, str]:
    parts = text.split(None, 1)
    return parts[0].upper(), parts[1] if len(parts) == 2 else ""


def _sanitize_command(command: str, argument: str) -> str:
    if command == "PASS":
        return "PASS <redacted>" if argument else "PASS"
    return f"{command} {argument}".rstrip()


def _record_command(event: dict[str, Any], command: str, limit: int) -> None:
    commands = event["commands"]
    if len(commands) < limit:
        commands.append(command)
    else:
        event["commands_truncated"] = True


def _peer(writer: asyncio.StreamWriter) -> str | None:
    peer = writer.get_extra_info("peername")
    if not peer:
        return None
    return str(peer[0])


async def _start_data_server(listen_host: str, state: dict[str, Any], upload: dict[str, Any], timeout: float, max_upload_bytes: int) -> tuple[asyncio.AbstractServer, int]:
    async def handle(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        if _peer(writer) != state.get("client_ip"):
            await close_writer(writer)
            return
        try:
            deadline = asyncio.get_running_loop().time() + timeout
            while not state.get("mode") and asyncio.get_running_loop().time() < deadline:
                await asyncio.sleep(0.01)
            if state.get("mode") == "upload":
                payload = bytearray()
                async with asyncio.timeout(timeout):
                    while len(payload) <= max_upload_bytes:
                        chunk = await reader.read(min(65536, max_upload_bytes + 1 - len(payload)))
                        if not chunk:
                            break
                        payload.extend(chunk)
                upload["complete"] = len(payload) <= max_upload_bytes
                upload["data"] = bytes(payload[:max_upload_bytes])
                state["ok"] = True
            else:
                payload = state.get("payload", b"")
                if isinstance(payload, bytes) and payload:
                    writer.write(payload)
                    await writer.drain()
                state["ok"] = True
        except (TimeoutError, OSError):
            state["ok"] = False
        finally:
            done = state.get("done")
            if isinstance(done, asyncio.Event):
                done.set()
            await close_writer(writer)

    bind_host = listen_host
    context = state.get("tls_context")
    server = await asyncio.start_server(handle, bind_host, 0, ssl=context, ssl_handshake_timeout=timeout if context else None)
    port = int(server.sockets[0].getsockname()[1])
    return server, port


async def _wait_transfer_done(state: dict[str, Any], timeout: float) -> bool:
    done = state.get("done")
    completed = False
    if isinstance(done, asyncio.Event):
        with contextlib.suppress(asyncio.TimeoutError):
            await asyncio.wait_for(done.wait(), timeout=timeout)
            completed = True
    ok = completed and bool(state.get("ok"))
    state["mode"] = ""
    state["payload"] = b""
    state["ok"] = False
    state.pop("done", None)
    return ok


def _finalize_upload(
    upload: dict[str, Any],
    files: dict[str, bytes],
    artifact_files: dict[str, str],
    artifacts: ArtifactStore,
    artifact_root: Path,
    persist_uploads: bool,
    index_path: Any,
    event: dict[str, Any],
) -> None:
    uploaded = upload.get("data", b"")
    path = str(upload.get("path", "/upload.bin"))
    event["data_upload_size"] = len(uploaded)
    event["data_upload_sha256"] = sha256(uploaded).hexdigest()
    event["data_upload_path"] = path
    event["data_upload"] = artifacts.save("ftp", uploaded)
    if upload.get("complete"):
        files[path] = uploaded
        if persist_uploads and isinstance(event["data_upload"], dict) and event["data_upload"].get("captured"):
            saved_path = _artifact_relative_path(artifact_root, Path(str(event["data_upload"].get("path", ""))))
            artifact_files[path] = saved_path
            _write_upload_index(index_path, artifact_files)


def _write_upload_index(index_path: Any, artifact_files: dict[str, str]) -> None:
    index_path.parent.mkdir(parents=True, exist_ok=True)
    files: dict[str, dict[str, str]] = {}
    for virtual_path, artifact_path in sorted(artifact_files.items()):
        if _valid_virtual_path(virtual_path):
            files[virtual_path] = {"path": artifact_path}
    tmp_path = index_path.with_suffix(index_path.suffix + ".tmp")
    tmp_path.write_text(json.dumps({"files": files}, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    tmp_path.replace(index_path)


def _artifact_relative_path(root: Path, path: Path) -> str:
    resolved_root = root.resolve()
    resolved_path = path.resolve()
    return resolved_path.relative_to(resolved_root).as_posix()


def _normalize_ftp_path(path: str, cwd: str) -> str:
    raw = path.strip() or cwd
    if raw.startswith("-"):
        parts = raw.split()
        raw = parts[-1] if parts else cwd
    base = PurePosixPath("/") if raw.startswith("/") else PurePosixPath(cwd)
    normalized = PurePosixPath(base, raw)
    clean: list[str] = []
    for part in normalized.parts:
        if part in {"", "/"}:
            continue
        if part == ".":
            continue
        if part == "..":
            if clean:
                clean.pop()
            continue
        clean.append(part)
    return "/" + "/".join(clean)


def _parent_dir(path: str) -> str:
    parent = str(PurePosixPath(path).parent)
    return parent if parent != "." else "/"


def _list_payload(files: dict[str, bytes], directory: str, long_format: bool) -> bytes:
    names = []
    prefix = directory.rstrip("/") + "/"
    seen: set[str] = set()
    for path, body in sorted(files.items()):
        if directory != "/" and not path.startswith(prefix):
            continue
        relative = path[1:] if directory == "/" else path[len(prefix) :]
        if not relative:
            continue
        first = relative.split("/", 1)[0]
        name = first + ("/" if "/" in relative else "")
        if not name:
            continue
        if name in seen:
            continue
        seen.add(name)
        if long_format:
            is_dir = name.endswith("/")
            mode = "drwxr-xr-x" if is_dir else "-rw-r--r--"
            size = 0 if is_dir else len(body)
            names.append(f"{mode} 1 ftp ftp {size:>8} Jan 01 00:00 {name.rstrip('/')}\r\n")
        else:
            names.append(f"{name.rstrip('/')}\r\n")
    if not names and long_format:
        names.append("-rw-r--r-- 1 ftp ftp       24 Jan 01 00:00 README.txt\r\n")
    if not names:
        names.append("README.txt\r\n")
    return "".join(names).encode("utf-8")


def _file_payload(files: dict[str, bytes], path: str) -> bytes:
    if path in files:
        return files[path]
    name = PurePosixPath(path).name or "file.bin"
    return f"File: {name}\r\nStatus: available\r\n".encode("utf-8")


def _valid_virtual_path(path: str) -> bool:
    return isinstance(path, str) and path.startswith("/") and "\\" not in path and ".." not in PurePosixPath(path).parts


def _pasv_response(host: str, port: int) -> bytes:
    parts = host.split(".")
    if len(parts) != 4 or not all(part.isdigit() for part in parts):
        parts = ["127", "0", "0", "1"]
    return f"227 entering passive mode ({','.join(parts)},{port // 256},{port % 256})\r\n".encode("ascii")


def _local_host(writer: asyncio.StreamWriter) -> str:
    sockname = writer.get_extra_info("sockname")
    if isinstance(sockname, (tuple, list)) and sockname:
        return str(sockname[0])
    return "127.0.0.1"
