from __future__ import annotations

from dataclasses import dataclass
from http import HTTPStatus
from pathlib import PurePosixPath
from typing import Any
from urllib.parse import unquote, unquote_plus, urlsplit
import asyncio
import base64
import io
import zipfile
from hashlib import sha256

from ..acl import SubnetAcl
from ..artifacts import ArtifactStore
from ..config import DnsConfig, GlobalConfig, HttpConfig
from ..downloads import BINARY_TEMPLATES, EXPLICIT_SCRIPTS, RETURN_STUBS, SCRIPT_TEMPLATES, binary_template, script_template
from ..logger import EventLogger
from ..pki import LabCrl, crl_url_path
from ..timeutils import http_date
from .base import RunningService, close_writer
from .dns import DnsService


@dataclass(slots=True)
class HttpPayload:
    status: int
    body: bytes
    content_type: str
    response_kind: str
    normalized_path: str
    download_name: str = ""


@dataclass(slots=True)
class DohPayload:
    status: int
    body: bytes
    content_type: str
    response_kind: str


class HttpService:
    def __init__(self, config: HttpConfig, global_config: GlobalConfig, logger: EventLogger, artifacts: ArtifactStore, acl: SubnetAcl, dns_config: DnsConfig | None = None) -> None:
        self._config = config
        self._global = global_config
        self._logger = logger
        self._artifacts = artifacts
        self._acl = acl
        self._dns_config = dns_config

    async def start(self) -> RunningService:
        crl = None
        if self._global.tls_crl_url:
            from .https import _ensure_lab_ca
            crl = LabCrl(self._global.artifact_dir)
            _ensure_lab_ca(crl.ca, crl.key)
            await asyncio.to_thread(crl.refresh)
        server = await asyncio.start_server(self._handle_client, self._global.listen_host, self._config.port)
        tasks = [asyncio.create_task(self._refresh_crl(crl))] if crl else []
        return RunningService("http", [server], [], tasks=tasks)

    async def _refresh_crl(self, crl: LabCrl) -> None:
        while True:
            await asyncio.sleep(1800)
            try:
                await asyncio.to_thread(crl.refresh)
            except Exception as exc:
                await self._logger.write('pki', {'error': type(exc).__name__, 'operation': 'crl_refresh'})

    def _crl_payload(self, method: str, target: str) -> HttpPayload | None:
        url = self._global.tls_crl_url
        if not url or urlsplit(target).path != crl_url_path(url):
            return None
        path = crl_url_path(url)
        if method not in {'GET', 'HEAD'}:
            return HttpPayload(405, b'', 'application/pkix-crl', 'lab_crl', path)
        try:
            body = LabCrl(self._global.artifact_dir).path.read_bytes()
        except OSError:
            return HttpPayload(503, b'', 'application/pkix-crl', 'lab_crl_unavailable', path)
        return HttpPayload(200, body, 'application/pkix-crl', 'lab_crl', path)

    async def _handle_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        peer = _peer(writer)
        if peer is None or not self._acl.allows(peer):
            await close_writer(writer)
            return

        try:
            for _ in range(max(1, self._global.max_command_count)):
                keep_open = await self._handle_one_request(reader, writer, peer)
                if not keep_open:
                    break
        finally:
            await close_writer(writer)

    async def _handle_one_request(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter, peer: str) -> bool:
        event: dict[str, Any] = {"client_ip": peer}
        try:
            raw_head = await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"), timeout=self._global.read_timeout_seconds)
        except asyncio.IncompleteReadError:
            return False
        except Exception as exc:
            event["error"] = exc.__class__.__name__
            await self._logger.write("http", event)
            return False
        try:
            request_line, headers = _parse_head(raw_head)
            parts = request_line.split()
            if len(parts) != 3 or not all(parts):
                await _write_error(writer, self._config.server_header, 400, "Bad Request", "bad request\n")
                event.update({"target": request_line, "status": 400, "error": "MalformedRequestLine"})
                return False
            method, target, version = parts
            try:
                content_length = int(headers.get("content-length", "0"))
            except ValueError:
                await _write_error(writer, self._config.server_header, 400, "Bad Request", "bad content length\n")
                event.update({"method": method, "target": target, "version": version, "status": 400, "error": "InvalidContentLength"})
                return False
            if content_length < 0:
                await _write_error(writer, self._config.server_header, 400, "Bad Request", "bad content length\n")
                event.update({"method": method, "target": target, "version": version, "status": 400, "error": "InvalidContentLength"})
                return False
            if content_length > self._global.max_body_bytes:
                response_body = b"request body too large\n"
                writer.write(_response(413, "Payload Too Large", self._config.server_header, response_body, "text/plain; charset=utf-8"))
                await writer.drain()
                event.update({"method": method, "target": target, "version": version, "status": 413, "request_body_size": content_length})
                return False
            if content_length:
                body = await asyncio.wait_for(reader.readexactly(content_length), timeout=self._global.read_timeout_seconds)
                event["request_body"] = self._artifacts.save("http", body)

            doh_response = self._doh_response(method, target, headers, body if content_length else b"", peer)
            if doh_response is not None:
                close_after = _should_close(version, headers)
                reason = HTTPStatus(doh_response.status).phrase if doh_response.status in HTTPStatus._value2member_map_ else "OK"
                writer.write(_response(doh_response.status, reason, self._config.server_header, doh_response.body, doh_response.content_type, include_body=method != "HEAD", close_after=close_after))
                await writer.drain()
                event.update({"method": method, "target": target, "path": "/dns-query", "version": version, "status": doh_response.status, "response_size": len(doh_response.body), "response_kind": doh_response.response_kind})
                return not close_after

            host = _request_host(target, headers.get("host", ""))
            payload = self._crl_payload(method, target) or select_http_payload(self._config, target)
            reason = HTTPStatus(payload.status).phrase if payload.status in HTTPStatus._value2member_map_ else "OK"
            include_body = method != "HEAD"
            close_after = _should_close(version, headers)
            writer.write(_response(payload.status, reason, self._config.server_header, payload.body, payload.content_type, payload.download_name, include_body, close_after=close_after))
            await writer.drain()
            event.update(
                {
                    "method": method,
                    "target": target,
                    "path": payload.normalized_path,
                    "version": version,
                    "host": host,
                    "user_agent": headers.get("user-agent", ""),
                    "status": payload.status,
                    "response_size": len(payload.body) if include_body else 0,
                    "response_kind": payload.response_kind,
                }
            )
            if payload.download_name:
                event["download_name"] = payload.download_name
            if payload.download_name or payload.response_kind == 'lab_crl':
                event["response_sha256"] = sha256(payload.body).hexdigest()
            return not close_after
        except Exception as exc:
            event["error"] = exc.__class__.__name__
            return False
        finally:
            await self._logger.write("http", event)

    def _doh_response(self, method: str, target: str, headers: dict[str, str], body: bytes, peer: str) -> DohPayload | None:
        if self._dns_config is None:
            return None
        parsed = urlsplit(target)
        path = parsed.path if parsed.scheme and parsed.netloc else target.split("?", 1)[0]
        if path != "/dns-query":
            return None
        if method not in {"GET", "POST", "HEAD"}:
            return DohPayload(405, b"method not allowed\n", "text/plain; charset=utf-8", "dns_over_https:error")
        if method == "POST" and headers.get("content-type", "").split(";", 1)[0].strip().lower() != "application/dns-message":
            return DohPayload(415, b"unsupported media type\n", "text/plain; charset=utf-8", "dns_over_https:error")
        query = body if method == "POST" else _doh_get_query(parsed.query if parsed.query else target.partition("?")[2])
        if not query:
            return DohPayload(400, b"bad dns query\n", "text/plain; charset=utf-8", "dns_over_https:error")
        response, _ = DnsService(self._dns_config, self._global, self._logger, self._acl)._build_response(query, peer, "doh")
        if not response:
            return DohPayload(400, b"bad dns query\n", "text/plain; charset=utf-8", "dns_over_https:error")
        return DohPayload(200, response, "application/dns-message", "dns_over_https")


def select_http_payload(config: HttpConfig, target: str) -> HttpPayload:
    path = _normalize_target_path(target)
    if path in config.routes:
        body = config.routes[path].encode("utf-8")
        return HttpPayload(config.route_statuses.get(path, config.default_status), body, _content_type_for_path(path, body), "configured_route", path)

    if config.login_page_enabled and path == config.login_page_path:
        return HttpPayload(config.default_status, enterprise_login_body(config), "text/html; charset=utf-8", "enterprise_login", path)

    suffix = PurePosixPath(path).suffix.lower()
    if config.fake_downloads_enabled and (path in config.fake_download_routes or suffix in config.fake_download_extensions):
        kind = config.fake_download_routes.get(path) or config.fake_download_extensions[suffix]
        body, content_type = fake_download_body(path, kind)
        return HttpPayload(config.default_status, body, content_type, f"fake_download:{kind}", path, _download_name(path))

    body = config.default_body.encode("utf-8")
    return HttpPayload(config.default_status, body, _content_type_for_path(path, body), "default", path)


def enterprise_login_body(config: HttpConfig) -> bytes:
    brand = _html_escape(config.login_page_brand)
    brand_initial = _html_escape((config.login_page_brand.strip() or "C")[0].upper())
    title = _html_escape(config.login_page_title)
    realm = _html_escape(config.login_page_realm)
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{title}</title>
  <style>
    * {{ box-sizing: border-box; }}
    body {{ margin: 0; font-family: Arial, Helvetica, sans-serif; background: #f4f6f9; color: #182230; }}
    nav {{ height: 64px; display: flex; align-items: center; justify-content: space-between; padding: 0 32px; background: #fff; border-bottom: 1px solid #d9e0e8; }}
    .brand {{ display: flex; align-items: center; gap: 10px; font-size: 18px; font-weight: 700; color: #111827; }}
    .brand-mark {{ width: 28px; height: 28px; display: grid; place-items: center; border-radius: 6px; background: #0f62b3; color: #fff; font-size: 15px; }}
    .nav-links {{ display: flex; gap: 22px; font-size: 13px; color: #52606d; }}
    main {{ min-height: calc(100vh - 112px); display: grid; place-items: center; padding: 40px 24px; }}
    section {{ width: 100%; max-width: 432px; background: #fff; border: 1px solid #d7dce2; box-shadow: 0 18px 45px rgba(16, 24, 40, 0.10); padding: 34px; }}
    h1 {{ font-size: 25px; font-weight: 700; margin: 0 0 8px; color: #111827; }}
    p {{ margin: 0 0 24px; color: #52606d; line-height: 1.45; }}
    label {{ display: block; font-size: 13px; color: #344054; margin: 18px 0 7px; font-weight: 600; }}
    .field {{ position: relative; }}
    .field svg {{ position: absolute; left: 13px; top: 50%; transform: translateY(-50%); width: 18px; height: 18px; color: #667085; pointer-events: none; }}
    input {{ width: 100%; border: 1px solid #b8c2cc; padding: 12px 12px 12px 42px; font-size: 15px; min-height: 44px; color: #111827; background: #fff; outline: none; }}
    input:focus {{ border-color: #0f62b3; box-shadow: 0 0 0 3px rgba(15, 98, 179, 0.14); }}
    input::placeholder {{ color: #8a95a3; }}
    button {{ width: 100%; margin-top: 22px; border: 0; background: #0f62b3; color: #fff; min-height: 44px; padding: 12px; font-size: 15px; font-weight: 700; cursor: pointer; }}
    button:hover {{ background: #0b539b; }}
    .help {{ font-size: 12px; margin-top: 18px; color: #667085; line-height: 1.45; }}
    footer {{ min-height: 48px; display: flex; align-items: center; justify-content: center; padding: 12px 24px; border-top: 1px solid #d9e0e8; color: #667085; font-size: 12px; background: #fff; }}
    @media (max-width: 560px) {{
      nav {{ padding: 0 18px; }}
      .nav-links {{ display: none; }}
      main {{ padding: 26px 16px; }}
      section {{ padding: 26px; }}
    }}
  </style>
</head>
<body>
  <nav>
    <div class="brand"><span class="brand-mark">{brand_initial}</span><span>{brand}</span></div>
    <div class="nav-links"><span>Account</span><span>Support</span><span>Status</span></div>
  </nav>
  <main>
    <section>
      <h1>{title}</h1>
      <p>{realm}</p>
      <form>
        <label for="user">Email or username</label>
        <div class="field">
          <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M4 4h16v16H4z"></path>
            <path d="m22 6-10 7L2 6"></path>
          </svg>
          <input id="user" autocomplete="username" placeholder="name@company.com">
        </div>
        <label for="pass">Password</label>
        <div class="field">
          <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect x="4" y="11" width="16" height="9" rx="2"></rect>
            <path d="M8 11V8a4 4 0 0 1 8 0v3"></path>
          </svg>
          <input id="pass" type="password" autocomplete="current-password" placeholder="Password">
        </div>
        <button type="button">Sign in</button>
      </form>
      <div class="help">Access is limited to authorized users.</div>
    </section>
  </main>
  <footer>Secure access portal</footer>
</body>
</html>
""".encode("utf-8")


def fake_download_body(path: str, kind: str) -> tuple[bytes, str]:
    requested = _download_name(path) or "download.bin"
    if kind in BINARY_TEMPLATES:
        body = binary_template(kind)
        if kind.startswith("windows_"):
            return body + _binary_note(requested), "application/vnd.microsoft.portable-executable"
        return body, "application/x-executable"
    if kind in RETURN_STUBS:
        return RETURN_STUBS[kind], "application/octet-stream"
    if kind in EXPLICIT_SCRIPTS:
        return SCRIPT_TEMPLATES[EXPLICIT_SCRIPTS[kind]], "text/plain; charset=utf-8"
    if kind == "zip":
        return _fake_zip(requested, _text_note(requested)), "application/zip"
    if kind == "pdf":
        return _fake_pdf(requested), "application/pdf"
    if kind in {"office_document", "msi"}:
        return b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1" + b"\x00" * 504 + _binary_note(requested), "application/octet-stream"
    if kind == "script":
        return script_template(requested), "text/plain; charset=utf-8"
    if kind == "text":
        return _text_note(requested), "text/plain; charset=utf-8"
    return _binary_note(requested), "application/octet-stream"


def _binary_note(requested: str) -> bytes:
    return f"File: {requested}\r\nStatus: staged\r\n".encode("utf-8")


def _text_note(requested: str) -> bytes:
    return f"File: {requested}\nStatus: available\n".encode("utf-8")


def _fake_zip(requested: str, note: bytes) -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("manifest.txt", note)
    return buffer.getvalue()


def _fake_pdf(requested: str) -> bytes:
    text = _pdf_string_escape(f"Document: {requested}")
    stream = f"BT /F1 12 Tf 72 720 Td ({text}) Tj ET"
    return (
        "%PDF-1.4\n"
        "1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n"
        "2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj\n"
        "3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R >> endobj\n"
        f"4 0 obj << /Length {len(stream)} >> stream\n{stream}\nendstream endobj\n"
        "trailer << /Root 1 0 R >>\n%%EOF\n"
    ).encode("ascii", "replace")


def _pdf_string_escape(value: str) -> str:
    return value.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def _normalize_target_path(target: str) -> str:
    parsed = urlsplit(target)
    path = parsed.path if parsed.scheme and parsed.netloc else target.split("?", 1)[0]
    if not path.startswith("/"):
        path = "/" + path
    return unquote(path) or "/"


def _request_host(target: str, host_header: str) -> str:
    parsed = urlsplit(target)
    if parsed.scheme and parsed.netloc:
        return parsed.netloc
    return host_header


def _download_name(path: str) -> str:
    return sanitize_download_name(PurePosixPath(path).name) or "download.bin"


def sanitize_download_name(name: str) -> str:
    cleaned = []
    for char in name:
        if ord(char) < 32 or ord(char) == 127 or char in {'/', '\\', '"'}:
            continue
        cleaned.append(char)
    value = "".join(cleaned).strip().strip(".")
    return value[:128]


def sanitize_header_filename(name: str) -> str:
    cleaned = []
    for char in sanitize_download_name(name):
        if 32 <= ord(char) <= 126:
            cleaned.append(char)
    value = "".join(cleaned).strip().strip(".")
    return value[:128]


def _content_type_for_path(path: str, body: bytes) -> str:
    suffix = PurePosixPath(path).suffix.lower()
    if suffix in {".html", ".htm"} or body.lstrip().lower().startswith((b"<!doctype html", b"<html")):
        return "text/html; charset=utf-8"
    if suffix in {".txt", ".log"}:
        return "text/plain; charset=utf-8"
    return "application/octet-stream"


def _html_escape(value: str) -> str:
    return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def _peer(writer: asyncio.StreamWriter) -> str | None:
    peer = writer.get_extra_info("peername")
    if not peer:
        return None
    return str(peer[0])


def _parse_head(data: bytes) -> tuple[str, dict[str, str]]:
    lines = data.decode("iso-8859-1").split("\r\n")
    request_line = lines[0]
    headers: dict[str, str] = {}
    for line in lines[1:]:
        if not line or ":" not in line:
            continue
        key, value = line.split(":", 1)
        headers[key.strip().lower()] = value.strip()
    return request_line, headers


async def _write_error(writer: asyncio.StreamWriter, server: str, status: int, reason: str, body: str) -> None:
    writer.write(_response(status, reason, server, body.encode("utf-8"), "text/plain; charset=utf-8"))
    await writer.drain()


def _response(status: int, reason: str, server: str, body: bytes, content_type: str, download_name: str = "", include_body: bool = True, close_after: bool = True) -> bytes:
    headers = [
        f"HTTP/1.1 {status} {reason}",
        f"Date: {http_date()}",
        f"Server: {server}",
        f"Content-Type: {content_type}",
        f"Content-Length: {len(body)}",
    ]
    if download_name:
        safe_name = sanitize_header_filename(download_name)
        if safe_name:
            headers.append(f'Content-Disposition: attachment; filename="{safe_name}"')
    headers.extend([f"Connection: {'close' if close_after else 'keep-alive'}", "", ""])
    response = "\r\n".join(headers).encode("ascii")
    if include_body:
        return response + body
    return response


def _should_close(version: str, headers: dict[str, str]) -> bool:
    connection = headers.get("connection", "").lower()
    if "close" in connection:
        return True
    if version.upper() == "HTTP/1.0" and "keep-alive" not in connection:
        return True
    return False


def _doh_get_query(query_string: str) -> bytes:
    for part in query_string.split("&"):
        key, _, value = part.partition("=")
        if key != "dns" or not value:
            continue
        value = unquote_plus(value)
        padded = value + ("=" * (-len(value) % 4))
        try:
            return base64.urlsafe_b64decode(padded.encode("ascii"))
        except Exception:
            return b""
    return b""
