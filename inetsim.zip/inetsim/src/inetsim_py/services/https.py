from __future__ import annotations

from hashlib import sha256

from http import HTTPStatus
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit
import asyncio
import contextlib
import ssl
import subprocess
import tempfile
import weakref

from ..acl import SubnetAcl
from ..artifacts import ArtifactStore
from ..config import DnsConfig, GlobalConfig, HttpConfig, HttpsConfig
from ..logger import EventLogger
from ..pki import certificate_needs_crl, crl_url_path
from .base import RunningService, close_writer
from .dns import DnsService
from .http import DohPayload, _doh_get_query, _parse_head, _peer, _request_host, _response, _should_close, select_http_payload


class HttpsService:
    def __init__(self, config: HttpsConfig, http_config: HttpConfig, global_config: GlobalConfig, logger: EventLogger, artifacts: ArtifactStore, acl: SubnetAcl, dns_config: DnsConfig | None = None) -> None:
        self._config = config
        self._http_config = http_config
        self._global = global_config
        self._logger = logger
        self._artifacts = artifacts
        self._acl = acl
        self._dns_config = dns_config
        self._sni_by_ssl_object: weakref.WeakKeyDictionary[ssl.SSLObject, str] = weakref.WeakKeyDictionary()
        self._dynamic_ca_cert: Path | None = None
        self._dynamic_ca_key: Path | None = None
        self._host_cert_dir: Path | None = None
        self._contexts_by_name: dict[str, ssl.SSLContext] = {}
        self._pending_contexts: set[str] = set()

    async def start(self) -> RunningService:
        cert_file, key_file, notes = self._certificate_paths()
        context = _server_context(cert_file, key_file)
        context.set_servername_callback(self._select_sni_context)
        server = await asyncio.start_server(
            self._handle_client,
            self._global.listen_host,
            self._config.port,
            ssl=context,
            ssl_handshake_timeout=self._global.read_timeout_seconds,
        )
        return RunningService("https", [server], [], notes=notes)

    def _certificate_paths(self) -> tuple[Path, Path, list[str]]:
        if self._config.cert_file is not None and self._config.key_file is not None:
            return self._config.cert_file, self._config.key_file, []
        if not self._config.auto_generate_cert:
            raise RuntimeError("HTTPS certificate generation is disabled and no cert/key pair is configured")

        cert_dir = self._global.artifact_dir / "tls"
        cert_dir.mkdir(parents=True, exist_ok=True)
        ca_cert = cert_dir / "inetsim-ca.crt"
        ca_key = cert_dir / "inetsim-ca.key"
        ca_created = _ensure_lab_ca(ca_cert, ca_key)
        self._dynamic_ca_cert = ca_cert
        self._dynamic_ca_key = ca_key
        self._host_cert_dir = cert_dir / "hosts"
        self._host_cert_dir.mkdir(parents=True, exist_ok=True)

        cert_file = cert_dir / "inetsim-https.crt"
        key_file = cert_dir / "inetsim-https.key"
        if ca_created or certificate_needs_crl(cert_file, key_file, self._global.tls_crl_url):
            _generate_signed_leaf_cert(cert_file, key_file, ca_cert, ca_key, self._config.cert_common_name, self._global.tls_crl_url)
            notes = _certificate_notes("generated lab CA-signed certificate", cert_file, ca_cert)
        else:
            notes = _certificate_notes("using existing lab certificate", cert_file, ca_cert)
        for host in self._config.prewarm_hosts:
            with contextlib.suppress(Exception):
                self._context_for_server_name(host)
        if self._config.prewarm_hosts:
            notes.append(f"https prewarmed {len(self._config.prewarm_hosts)} host certificates")
        return cert_file, key_file, notes

    def _select_sni_context(self, ssl_object: ssl.SSLObject, server_name: str | None, context: ssl.SSLContext) -> None:
        if server_name:
            self._sni_by_ssl_object[ssl_object] = server_name
            with contextlib.suppress(Exception):
                ssl_object.context = self._context_for_server_name(server_name, generate_if_missing=self._config.block_on_unknown_sni)

    def _context_for_server_name(self, server_name: str, generate_if_missing: bool = True) -> ssl.SSLContext:
        normalized = _normalize_sni_name(server_name)
        if not normalized:
            raise ValueError("invalid SNI hostname")
        cached = self._contexts_by_name.get(normalized)
        if cached is not None:
            return cached
        if self._dynamic_ca_cert is None or self._dynamic_ca_key is None or self._host_cert_dir is None:
            raise RuntimeError("dynamic HTTPS certificate CA is unavailable")
        cert_file = self._host_cert_dir / f"{normalized}.crt"
        key_file = self._host_cert_dir / f"{normalized}.key"
        if certificate_needs_crl(cert_file, key_file, self._global.tls_crl_url):
            if not generate_if_missing:
                self._schedule_context_generation(normalized, cert_file, key_file)
                raise RuntimeError("SNI certificate is being generated asynchronously")
            _generate_signed_leaf_cert(cert_file, key_file, self._dynamic_ca_cert, self._dynamic_ca_key, normalized, self._global.tls_crl_url)
        context = _server_context(cert_file, key_file)
        self._contexts_by_name[normalized] = context
        return context

    def _schedule_context_generation(self, normalized: str, cert_file: Path, key_file: Path) -> None:
        if normalized in self._pending_contexts or self._dynamic_ca_cert is None or self._dynamic_ca_key is None:
            return
        self._pending_contexts.add(normalized)

        async def generate() -> None:
            try:
                await asyncio.to_thread(_generate_signed_leaf_cert, cert_file, key_file, self._dynamic_ca_cert, self._dynamic_ca_key, normalized, self._global.tls_crl_url)
                self._contexts_by_name[normalized] = _server_context(cert_file, key_file)
            finally:
                self._pending_contexts.discard(normalized)

        try:
            asyncio.get_running_loop().create_task(generate())
        except RuntimeError:
            self._pending_contexts.discard(normalized)

    async def _handle_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        peer = _peer(writer)
        ssl_object = writer.get_extra_info("ssl_object")
        sni = self._sni_by_ssl_object.pop(ssl_object, "") if ssl_object is not None else ""
        if peer is None or not self._acl.allows(peer):
            await close_writer(writer)
            return

        event: dict[str, Any] = {
            "client_ip": peer,
            "tls": True,
            "sni": sni,
            "tls_version": ssl_object.version() if ssl_object is not None else "",
            "cipher": _cipher_name(ssl_object),
        }
        try:
            for _ in range(max(1, self._global.max_command_count)):
                keep_open = await self._handle_one_request(reader, writer, dict(event))
                if not keep_open:
                    break
        finally:
            await close_writer(writer)

    async def _handle_one_request(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter, event: dict[str, Any]) -> bool:
        try:
            raw_head = await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"), timeout=self._global.read_timeout_seconds)
        except asyncio.IncompleteReadError:
            return False
        except Exception as exc:
            event["error"] = exc.__class__.__name__
            await self._logger.write("https", event)
            return False
        try:
            request_line, headers = _parse_head(raw_head)
            parts = request_line.split()
            if len(parts) != 3 or not all(parts):
                await _write_tls_error(writer, self._http_config.server_header, 400, "Bad Request", "bad request\n")
                event.update({"target": request_line, "status": 400, "error": "MalformedRequestLine"})
                return False
            method, target, version = parts
            try:
                content_length = int(headers.get("content-length", "0"))
            except ValueError:
                await _write_tls_error(writer, self._http_config.server_header, 400, "Bad Request", "bad content length\n")
                event.update({"method": method, "target": target, "version": version, "status": 400, "error": "InvalidContentLength"})
                return False
            if content_length < 0:
                await _write_tls_error(writer, self._http_config.server_header, 400, "Bad Request", "bad content length\n")
                event.update({"method": method, "target": target, "version": version, "status": 400, "error": "InvalidContentLength"})
                return False
            if content_length > self._global.max_body_bytes:
                response_body = b"request body too large\n"
                writer.write(_response(413, "Payload Too Large", self._http_config.server_header, response_body, "text/plain; charset=utf-8"))
                await writer.drain()
                event.update({"method": method, "target": target, "version": version, "status": 413, "request_body_size": content_length})
                return False
            if content_length:
                body = await asyncio.wait_for(reader.readexactly(content_length), timeout=self._global.read_timeout_seconds)
                event["request_body"] = self._artifacts.save("https", body)

            doh_response = self._doh_response(method, target, headers, body if content_length else b"", event.get("client_ip", ""))
            if doh_response is not None:
                close_after = _should_close(version, headers)
                reason = HTTPStatus(doh_response.status).phrase if doh_response.status in HTTPStatus._value2member_map_ else "OK"
                writer.write(_response(doh_response.status, reason, self._http_config.server_header, doh_response.body, doh_response.content_type, include_body=method != "HEAD", close_after=close_after))
                await writer.drain()
                event.update({"method": method, "target": target, "path": "/dns-query", "version": version, "status": doh_response.status, "response_size": len(doh_response.body), "response_kind": doh_response.response_kind})
                return not close_after

            host = _request_host(target, headers.get("host", ""))
            payload = select_http_payload(self._http_config, target)
            reason = HTTPStatus(payload.status).phrase if payload.status in HTTPStatus._value2member_map_ else "OK"
            include_body = method != "HEAD"
            close_after = _should_close(version, headers)
            writer.write(_response(payload.status, reason, self._http_config.server_header, payload.body, payload.content_type, payload.download_name, include_body, close_after=close_after))
            await writer.drain()
            event.update(
                {
                    "method": method,
                    "target": target,
                    "path": payload.normalized_path,
                    "version": version,
                    "host": host,
                    "user_agent": headers.get("user-agent", ""),
                    "status": payload.status,
                    "response_size": len(payload.body) if include_body else 0,
                    "response_kind": payload.response_kind,
                }
            )
            if payload.download_name:
                event["download_name"] = payload.download_name
                event["response_sha256"] = sha256(payload.body).hexdigest()
            return not close_after
        except Exception as exc:
            event["error"] = exc.__class__.__name__
            return False
        finally:
            await self._logger.write("https", event)

    def _doh_response(self, method: str, target: str, headers: dict[str, str], body: bytes, peer: str) -> DohPayload | None:
        if self._dns_config is None:
            return None
        parsed = urlsplit(target)
        path = parsed.path if parsed.scheme and parsed.netloc else target.split("?", 1)[0]
        if path != "/dns-query":
            return None
        if method not in {"GET", "POST", "HEAD"}:
            return DohPayload(405, b"method not allowed\n", "text/plain; charset=utf-8", "dns_over_https:error")
        if method == "POST" and headers.get("content-type", "").split(";", 1)[0].strip().lower() != "application/dns-message":
            return DohPayload(415, b"unsupported media type\n", "text/plain; charset=utf-8", "dns_over_https:error")
        query = body if method == "POST" else _doh_get_query(parsed.query if parsed.query else target.partition("?")[2])
        if not query:
            return DohPayload(400, b"bad dns query\n", "text/plain; charset=utf-8", "dns_over_https:error")
        response, _ = DnsService(self._dns_config, self._global, self._logger, self._acl)._build_response(query, peer, "doh")
        if not response:
            return DohPayload(400, b"bad dns query\n", "text/plain; charset=utf-8", "dns_over_https:error")
        return DohPayload(200, response, "application/dns-message", "dns_over_https")


def _server_context(cert_file: Path, key_file: Path) -> ssl.SSLContext:
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.load_cert_chain(cert_file, key_file)
    return context


def _ensure_lab_ca(cert_file: Path, key_file: Path) -> bool:
    if cert_file.exists() and key_file.exists():
        return False
    _generate_ca_cert(cert_file, key_file)
    return True


def _generate_ca_cert(cert_file: Path, key_file: Path) -> None:
    cert_file.parent.mkdir(parents=True, exist_ok=True)
    safe_name = "inetsim-py-lab-ca"
    with tempfile.TemporaryDirectory() as temp_dir:
        config_path = Path(temp_dir) / "openssl-ca.cnf"
        config_path.write_text(
            "\n".join(
                [
                    "[req]",
                    "distinguished_name = dn",
                    "x509_extensions = v3_ca",
                    "prompt = no",
                    "[dn]",
                    f"CN = {safe_name}",
                    "[v3_ca]",
                    "subjectKeyIdentifier = hash",
                    "authorityKeyIdentifier = keyid:always,issuer",
                    "basicConstraints = critical, CA:true",
                    "keyUsage = critical, keyCertSign, cRLSign",
                    "",
                ]
            ),
            encoding="ascii",
        )
        _run_openssl(
            [
                "openssl",
                "req",
                "-x509",
                "-newkey",
                "rsa:2048",
                "-sha256",
                "-days",
                "365",
                "-nodes",
                "-keyout",
                str(key_file),
                "-out",
                str(cert_file),
                "-config",
                str(config_path),
            ]
        )
    key_file.chmod(0o600)


def _generate_signed_leaf_cert(cert_file: Path, key_file: Path, ca_cert: Path, ca_key: Path, common_name: str, crl_url: str = "") -> None:
    cert_file.parent.mkdir(parents=True, exist_ok=True)
    safe_name = _safe_cert_subject(common_name)
    # OpenSSL limits CN to 64 characters; DNS identity belongs in the full SAN.
    subject_cn = safe_name if len(safe_name) <= 64 else "service"
    if crl_url:
        crl_url_path(crl_url)
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        config_path = temp_path / "openssl-leaf.cnf"
        csr_path = temp_path / "leaf.csr"
        config_path.write_text(
            "\n".join(
                [
                    "[req]",
                    "distinguished_name = dn",
                    "req_extensions = v3_req",
                    "prompt = no",
                    "[dn]",
                    f"CN = {subject_cn}",
                    "[v3_req]",
                    f"subjectAltName = DNS:{safe_name}",
                    "basicConstraints = critical, CA:false",
                    "keyUsage = critical, digitalSignature, keyEncipherment",
                    "extendedKeyUsage = serverAuth",
                    *([f"crlDistributionPoints = URI:{crl_url}"] if crl_url else []),
                    "",
                ]
            ),
            encoding="ascii",
        )
        key_arguments = ["-key", str(key_file)] if key_file.is_file() else [
            "-newkey", "rsa:2048", "-nodes", "-keyout", str(key_file)]
        _run_openssl(
            [
                "openssl",
                "req",
                "-new",
                *key_arguments,
                "-out",
                str(csr_path),
                "-config",
                str(config_path),
            ]
        )
        _run_openssl(
            [
                "openssl",
                "x509",
                "-req",
                "-in",
                str(csr_path),
                "-CA",
                str(ca_cert),
                "-CAkey",
                str(ca_key),
                "-CAcreateserial",
                "-out",
                str(cert_file),
                "-days",
                "90",
                "-sha256",
                "-extfile",
                str(config_path),
                "-extensions",
                "v3_req",
            ]
        )
    key_file.chmod(0o600)


def _run_openssl(command: list[str]) -> None:
    try:
        result = subprocess.run(command, check=False, capture_output=True, text=True)
    except FileNotFoundError as exc:
        raise RuntimeError("openssl was not found; configure services.https.cert_file/key_file or install openssl") from exc
    if result.returncode != 0:
        reason = result.stderr.strip() or result.stdout.strip() or f"openssl exited with status {result.returncode}"
        raise RuntimeError(f"failed to generate HTTPS certificate: {reason}")


def _certificate_notes(action: str, cert_file: Path, ca_cert: Path | None = None) -> list[str]:
    ca_note = f"https lab CA certificate {ca_cert}; install this CA into clients for arbitrary sinkholed HTTPS hostnames" if ca_cert else "https clients must trust the configured certificate"
    return [
        f"https {action} {cert_file}",
        ca_note,
        "https generates per-SNI certificates for sinkholed hostnames; certificate-pinned clients may still reject interception",
    ]


def _safe_cert_subject(value: str) -> str:
    return "".join(char for char in value if char.isalnum() or char in ".-") or "inetsim.local"


def _normalize_sni_name(value: str) -> str:
    normalized = value.rstrip(".").lower()
    if not normalized or len(normalized) > 253:
        return ""
    labels = normalized.split(".")
    for label in labels:
        if not label or len(label) > 63:
            return ""
        if not all(char.isalnum() or char == "-" for char in label):
            return ""
        if label.startswith("-") or label.endswith("-"):
            return ""
    return normalized


def _cipher_name(ssl_object: ssl.SSLObject | None) -> str:
    if ssl_object is None:
        return ""
    cipher = ssl_object.cipher()
    if not cipher:
        return ""
    return str(cipher[0])


async def _write_tls_error(writer: asyncio.StreamWriter, server: str, status: int, reason: str, body: str) -> None:
    writer.write(_response(status, reason, server, body.encode("utf-8"), "text/plain; charset=utf-8"))
    await writer.drain()
