from __future__ import annotations

import asyncio
import json
import os
import shutil
import sys
from pathlib import Path

from ..config import GlobalConfig, HttpConfig, MitmProxyConfig
from .base import RunningService

_STARTUP_TIMEOUT_SECONDS = 10.0


class MitmProxyService:
    def __init__(self, config: MitmProxyConfig, http_config: HttpConfig, global_config: GlobalConfig) -> None:
        self._config = config
        self._http_config = http_config
        self._global = global_config

    async def start(self) -> RunningService:
        executable = shutil.which(self._config.executable)
        if executable is None:
            raise RuntimeError(
                f"mitmproxy service is enabled, but {self._config.executable!r} was not found. "
                "Install the optional extra with `python3 -m pip install -e .[mitm]` or set services.mitmproxy.executable."
            )

        runtime_dir = self._global.artifact_dir / "mitmproxy"
        confdir = runtime_dir / "conf"
        log_dir = self._global.log_dir
        runtime_dir.mkdir(parents=True, exist_ok=True)
        confdir.mkdir(parents=True, exist_ok=True)
        log_dir.mkdir(parents=True, exist_ok=True)
        addon_config = runtime_dir / "addon-config.json"
        addon_config.write_text(json.dumps(self._addon_config(), indent=2, sort_keys=True), encoding="utf-8")

        addon = Path(__file__).resolve().parents[1] / "mitm_addon.py"
        env = os.environ.copy()
        env["INETSIM_MITMPROXY_CONFIG"] = str(addon_config)
        env["PYTHONPATH"] = _pythonpath_with_package(env.get("PYTHONPATH", ""))

        command = [
            executable,
            "--mode",
            self._config.mode,
            "--listen-host",
            self._global.listen_host,
            "--listen-port",
            str(self._config.port),
            "--set",
            f"confdir={confdir}",
            "-s",
            str(addon),
        ]
        if self._config.ssl_insecure:
            command.append("--ssl-insecure")

        stdout_file = (log_dir / "mitmproxy-startup.log").open("ab")
        stderr_file = (log_dir / "mitmproxy-startup.err.log").open("ab")
        try:
            process = await asyncio.create_subprocess_exec(
                *command,
                env=env,
                stdout=stdout_file,
                stderr=stderr_file,
            )
        finally:
            stdout_file.close()
            stderr_file.close()
        running = RunningService("mitmproxy", [], [], processes=[process], notes=_startup_notes(confdir, self._global.listen_host, self._config.port))
        try:
            await _wait_for_listener(process, self._global.listen_host, self._config.port, log_dir)
        except BaseException:
            running.close()
            await running.wait_closed()
            raise
        return running

    def _addon_config(self) -> dict[str, object]:
        return {
            "log_dir": str(self._global.log_dir),
            "artifact_dir": str(self._global.artifact_dir),
            "allowed_clients": self._global.allowed_clients,
            "block_upstream": self._config.block_upstream,
            "allow_upstream_hosts": self._config.allow_upstream_hosts,
            "synthesize_downloads": self._config.synthesize_downloads,
            "body_capture_limit": self._config.body_capture_limit,
            "synthetic_status": self._config.synthetic_status,
            "blocked_status": self._config.blocked_status,
            "server_header": self._http_config.server_header,
            "default_status": self._http_config.default_status,
            "default_body": self._http_config.default_body,
            "login_page_enabled": self._http_config.login_page_enabled,
            "login_page_path": self._http_config.login_page_path,
            "login_page_brand": self._http_config.login_page_brand,
            "login_page_title": self._http_config.login_page_title,
            "login_page_realm": self._http_config.login_page_realm,
            "fake_download_extensions": self._http_config.fake_download_extensions,
            "fake_download_routes": self._http_config.fake_download_routes,
            "routes": self._http_config.routes,
            "route_statuses": self._http_config.route_statuses,
        }


async def _wait_for_listener(process: asyncio.subprocess.Process, host: str, port: int, log_dir: Path) -> None:
    probe_host = {"0.0.0.0": "127.0.0.1", "::": "::1"}.get(host, host)
    try:
        async with asyncio.timeout(_STARTUP_TIMEOUT_SECONDS):
            while True:
                if process.returncode is not None:
                    raise RuntimeError(f"mitmdump exited during startup; see {log_dir / 'mitmproxy-startup.err.log'} for details")
                try:
                    _, writer = await asyncio.wait_for(asyncio.open_connection(probe_host, port), timeout=0.5)
                except (OSError, TimeoutError):
                    await asyncio.sleep(0.05)
                    continue
                writer.close()
                await writer.wait_closed()
                return
    except TimeoutError as exc:
        raise RuntimeError(f"mitmdump did not listen on {host}:{port} within {_STARTUP_TIMEOUT_SECONDS:g}s; see {log_dir / 'mitmproxy-startup.err.log'} for details") from exc


def _pythonpath_with_package(existing: str) -> str:
    package_root = str(Path(__file__).resolve().parents[2])
    entries = [package_root]
    if existing:
        entries.append(existing)
    return os.pathsep.join(entries)


def _startup_notes(confdir: Path, listen_host: str, port: int) -> list[str]:
    return [
        f"mitmproxy explicit proxy listening at {listen_host}:{port}",
        f"mitmproxy CA directory {confdir}",
        f"install {confdir / 'mitmproxy-ca-cert.pem'} into the client trust store, or browse to http://mitm.it through the proxy",
        "certificate-pinned clients may still reject interception even after the CA is trusted",
    ]
