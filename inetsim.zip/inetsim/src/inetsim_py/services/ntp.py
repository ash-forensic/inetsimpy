from __future__ import annotations

from hashlib import sha256
from typing import Any
import asyncio
import struct

from ..acl import SubnetAcl
from ..config import GlobalConfig, NtpConfig
from ..logger import EventLogger
from ..timeutils import unix_time
from .base import RunningService

NTP_EPOCH_DELTA = 2208988800


class NtpService:
    def __init__(self, config: NtpConfig, global_config: GlobalConfig, logger: EventLogger, acl: SubnetAcl) -> None:
        self._config = config
        self._global = global_config
        self._logger = logger
        self._acl = acl

    async def start(self) -> RunningService:
        loop = asyncio.get_running_loop()
        transport, _ = await loop.create_datagram_endpoint(lambda: _NtpProtocol(self), local_addr=(self._global.listen_host, self._config.port))
        return RunningService("ntp", [], [transport])

    async def handle_datagram(self, data: bytes, peer: tuple[str, int], transport: asyncio.DatagramTransport) -> None:
        if not self._acl.allows(peer[0]):
            return
        event: dict[str, Any] = {"client_ip": peer[0], "client_port": peer[1], "bytes": len(data), "sha256": sha256(data).hexdigest()}
        if len(data) < 48:
            event["error"] = "ShortPacket"
            await self._logger.write("ntp", event)
            return
        event["client_mode"] = data[0] & 0x07
        event["client_version"] = (data[0] >> 3) & 0x07
        response = _build_ntp_response(data, self._config.stratum)
        transport.sendto(response, peer)
        event["stratum"] = self._config.stratum
        await self._logger.write("ntp", event)


class _NtpProtocol(asyncio.DatagramProtocol):
    def __init__(self, service: NtpService) -> None:
        self._service = service
        self._transport: asyncio.DatagramTransport | None = None

    def connection_made(self, transport: asyncio.BaseTransport) -> None:
        self._transport = transport  # type: ignore[assignment]

    def datagram_received(self, data: bytes, addr: tuple[str, int]) -> None:
        if self._transport is not None:
            asyncio.create_task(self._service.handle_datagram(data, addr, self._transport))


def _build_ntp_response(request: bytes, stratum: int) -> bytes:
    now = _ntp_timestamp(unix_time())
    version = (request[0] >> 3) & 0x07 or 4
    first = (0 << 6) | (version << 3) | 4
    packet = bytearray(48)
    packet[0] = first
    packet[1] = max(1, min(stratum, 15))
    packet[2] = 6
    packet[3] = 0xEC
    packet[12:16] = b"LOCL"
    packet[16:24] = now
    packet[24:32] = request[40:48]
    packet[32:40] = now
    packet[40:48] = now
    return bytes(packet)


def _ntp_timestamp(value: float) -> bytes:
    seconds = int(value) + NTP_EPOCH_DELTA
    fraction = int((value - int(value)) * (1 << 32))
    return struct.pack("!II", seconds & 0xFFFFFFFF, fraction & 0xFFFFFFFF)
