from __future__ import annotations

from email.utils import formatdate, make_msgid
from hashlib import sha256
from typing import Any
import asyncio
import ssl

from ..acl import SubnetAcl
from ..config import GlobalConfig, Pop3Config
from ..logger import EventLogger
from .base import RunningService, close_writer
from .smtp import _service_tls_context


class Pop3Service:
    def __init__(self, config: Pop3Config, global_config: GlobalConfig, logger: EventLogger, acl: SubnetAcl) -> None:
        self._config = config
        self._global = global_config
        self._logger = logger
        self._acl = acl

    async def start(self) -> RunningService:
        servers = [await asyncio.start_server(lambda r, w: self._handle_client(r, w, implicit_tls=False), self._global.listen_host, self._config.port)]
        if self._config.implicit_tls_port:
            servers.append(
                await asyncio.start_server(
                    lambda r, w: self._handle_client(r, w, implicit_tls=True),
                    self._global.listen_host,
                    self._config.implicit_tls_port,
                    ssl=_service_tls_context(self._global.artifact_dir, self._config.hostname, self._global.tls_crl_url),
                )
            )
        return RunningService("pop3", servers, [])

    async def _handle_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter, implicit_tls: bool = False) -> None:
        peer = _peer(writer)
        if peer is None or not self._acl.allows(peer):
            await close_writer(writer)
            return

        message = build_message(self._config)
        deleted = False
        authed = False
        event: dict[str, Any] = {"client_ip": peer, "commands": [], "username": ""}
        if implicit_tls:
            event["tls_established"] = True
            event["implicit_tls"] = True
        writer.write(f"+OK {self._config.hostname} {self._config.banner}\r\n".encode("ascii"))
        await writer.drain()
        try:
            while True:
                line = await asyncio.wait_for(reader.readline(), timeout=self._global.read_timeout_seconds)
                if not line:
                    break
                text = line.decode("utf-8", "replace").rstrip("\r\n")
                if not text:
                    continue
                command, argument = _split_command(text)
                _record_command(event, _sanitize_command(command, argument), self._global.max_command_count)

                if command == "CAPA":
                    capabilities = b"+OK capability list follows\r\nUSER\r\nUIDL\r\nTOP\r\n"
                    if not event.get("tls_established"):
                        capabilities += b"STLS\r\n"
                    writer.write(capabilities + b".\r\n")
                elif command == "USER":
                    event["username"] = argument
                    writer.write(b"+OK user accepted\r\n")
                elif command == "PASS":
                    event["password_length"] = len(argument)
                    event["password_sha256"] = sha256(argument.encode("utf-8", "replace")).hexdigest()
                    authed = True
                    writer.write(b"+OK mailbox locked and ready\r\n")
                elif command == "APOP":
                    event["apop_length"] = len(argument)
                    event["apop_sha256"] = sha256(argument.encode("utf-8", "replace")).hexdigest()
                    authed = True
                    writer.write(b"+OK mailbox locked and ready\r\n")
                elif command == "AUTH":
                    writer.write(b"-ERR authentication mechanism not available\r\n")
                elif command == "STLS":
                    event["tls_requested"] = True
                    writer.write(b"+OK begin TLS negotiation\r\n")
                    await writer.drain()
                    try:
                        await asyncio.wait_for(writer.start_tls(_service_tls_context(self._global.artifact_dir, self._config.hostname, self._global.tls_crl_url)), timeout=min(self._global.read_timeout_seconds, 1.0))
                        event["tls_established"] = True
                    except (AttributeError, ssl.SSLError, OSError) as exc:
                        event["tls_error"] = exc.__class__.__name__
                        break
                elif command == "STAT":
                    writer.write(_mailbox_stat(message, deleted, authed))
                elif command == "LIST":
                    writer.write(_mailbox_list(message, deleted, authed, argument))
                elif command == "UIDL":
                    writer.write(_mailbox_uidl(message, deleted, authed, argument))
                elif command == "RETR":
                    if authed and argument.strip() == "1" and not deleted:
                        writer.write(b"+OK message follows\r\n" + _dot_stuff(message) + b".\r\n")
                    else:
                        writer.write(b"-ERR no such message\r\n")
                elif command == "TOP":
                    if authed and _first_argument(argument) == "1" and not deleted:
                        writer.write(b"+OK top of message follows\r\n" + _dot_stuff(_top(message, argument)) + b".\r\n")
                    else:
                        writer.write(b"-ERR no such message\r\n")
                elif command == "DELE":
                    if authed and argument.strip() == "1" and not deleted:
                        deleted = True
                        writer.write(b"+OK message deleted\r\n")
                    else:
                        writer.write(b"-ERR no such message\r\n")
                elif command == "NOOP":
                    writer.write(b"+OK\r\n")
                elif command == "RSET":
                    deleted = False
                    writer.write(b"+OK reset\r\n")
                elif command == "QUIT":
                    writer.write(b"+OK bye\r\n")
                    await writer.drain()
                    break
                else:
                    writer.write(b"-ERR command not implemented\r\n")
                await writer.drain()
        except Exception as exc:
            event["error"] = exc.__class__.__name__
        finally:
            await self._logger.write("pop3", event)
            await close_writer(writer)


def build_message(config: Pop3Config) -> bytes:
    body = config.message_body.replace("\n", "\r\n")
    message = (
        f"From: {config.message_from}\r\n"
        f"To: {config.username}@{config.hostname}\r\n"
        f"Subject: {config.message_subject}\r\n"
        f"Date: {formatdate(usegmt=True)}\r\n"
        f"Message-ID: {make_msgid(domain=config.hostname)}\r\n"
        "MIME-Version: 1.0\r\n"
        "Content-Type: text/plain; charset=utf-8\r\n"
        "\r\n"
        f"{body}\r\n"
    )
    return message.encode("utf-8")


def _record_command(event: dict[str, Any], command: str, limit: int) -> None:
    commands = event["commands"]
    if len(commands) < limit:
        commands.append(command)
    else:
        event["commands_truncated"] = True


def _split_command(text: str) -> tuple[str, str]:
    parts = text.split(None, 1)
    command = parts[0].upper()
    argument = parts[1] if len(parts) == 2 else ""
    return command, argument


def _sanitize_command(command: str, argument: str) -> str:
    if command in {"PASS", "APOP", "AUTH"}:
        return f"{command} <redacted>" if argument else command
    return f"{command} {argument}".rstrip()


def _mailbox_stat(message: bytes, deleted: bool, authed: bool) -> bytes:
    if not authed:
        return b"-ERR authenticate first\r\n"
    count = 0 if deleted else 1
    size = 0 if deleted else len(message)
    return f"+OK {count} {size}\r\n".encode("ascii")


def _mailbox_list(message: bytes, deleted: bool, authed: bool, argument: str) -> bytes:
    if not authed:
        return b"-ERR authenticate first\r\n"
    if argument.strip() == "1" and not deleted:
        return f"+OK 1 {len(message)}\r\n".encode("ascii")
    if argument.strip():
        return b"-ERR no such message\r\n"
    if deleted:
        return b"+OK scan listing follows\r\n.\r\n"
    return f"+OK scan listing follows\r\n1 {len(message)}\r\n.\r\n".encode("ascii")


def _mailbox_uidl(message: bytes, deleted: bool, authed: bool, argument: str) -> bytes:
    if not authed:
        return b"-ERR authenticate first\r\n"
    uid = sha256(message).hexdigest()[:16]
    if argument.strip() == "1" and not deleted:
        return f"+OK 1 {uid}\r\n".encode("ascii")
    if argument.strip():
        return b"-ERR no such message\r\n"
    if deleted:
        return b"+OK unique-id listing follows\r\n.\r\n"
    return f"+OK unique-id listing follows\r\n1 {uid}\r\n.\r\n".encode("ascii")


def _first_argument(argument: str) -> str:
    parts = argument.split()
    return parts[0] if parts else ""


def _dot_stuff(message: bytes) -> bytes:
    lines = message.splitlines(keepends=True)
    return b"".join(b"." + line if line.startswith(b".") else line for line in lines)


def _top(message: bytes, argument: str) -> bytes:
    parts = argument.split()
    line_count = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 0
    head, _, body = message.partition(b"\r\n\r\n")
    body_lines = body.splitlines(keepends=True)[:line_count]
    return head + b"\r\n\r\n" + b"".join(body_lines)


def _peer(writer: asyncio.StreamWriter) -> str | None:
    peer = writer.get_extra_info("peername")
    if not peer:
        return None
    return str(peer[0])
