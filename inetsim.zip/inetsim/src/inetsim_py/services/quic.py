from __future__ import annotations

from hashlib import sha256
from typing import Any
import asyncio

from ..acl import SubnetAcl
from ..config import GlobalConfig, QuicConfig
from ..logger import EventLogger
from .base import RunningService


class QuicService:
    def __init__(self, config: QuicConfig, global_config: GlobalConfig, logger: EventLogger, acl: SubnetAcl) -> None:
        self._config = config
        self._global = global_config
        self._logger = logger
        self._acl = acl

    async def start(self) -> RunningService:
        loop = asyncio.get_running_loop()
        transport, _ = await loop.create_datagram_endpoint(lambda: _QuicUdpProtocol(self), local_addr=(self._global.listen_host, self._config.port))
        mode = "blocks" if self._config.block else "observes"
        return RunningService("quic", [], [transport], notes=[f"quic UDP sink {mode} HTTP/3 attempts; it does not proxy QUIC streams"])

    async def handle_udp(self, data: bytes, peer: tuple[str, int], transport: asyncio.DatagramTransport) -> None:
        if not self._acl.allows(peer[0]):
            return
        event: dict[str, Any] = {
            "client_ip": peer[0],
            "client_port": peer[1],
            "bytes": len(data),
            "sha256": sha256(data).hexdigest(),
            "long_header": bool(data and data[0] & 0x80),
        }
        event.update(_parse_quic_packet(data))
        await self._logger.write("quic", event)
        if self._config.block and self._config.send_close and data:
            transport.sendto(_quic_block_response(data), peer)


class _QuicUdpProtocol(asyncio.DatagramProtocol):
    def __init__(self, service: QuicService) -> None:
        self._service = service
        self._transport: asyncio.DatagramTransport | None = None

    def connection_made(self, transport: asyncio.BaseTransport) -> None:
        self._transport = transport  # type: ignore[assignment]

    def datagram_received(self, data: bytes, addr: tuple[str, int]) -> None:
        if self._transport is None:
            return
        asyncio.create_task(self._service.handle_udp(data, addr, self._transport))


def _stateless_close(data: bytes) -> bytes:
    token = sha256(data).digest()[:16]
    return b"\x43\x00\x00\x00" + token


def _quic_block_response(data: bytes) -> bytes:
    version_negotiation = _version_negotiation(data)
    if version_negotiation:
        return version_negotiation
    return _stateless_close(data)


def _version_negotiation(data: bytes) -> bytes:
    if len(data) < 7 or not data[0] & 0x80:
        return b""
    offset = 5
    dcid_length = data[offset]
    offset += 1
    if offset + dcid_length > len(data):
        return b""
    dcid = data[offset : offset + dcid_length]
    offset += dcid_length
    if offset >= len(data):
        return b""
    scid_length = data[offset]
    offset += 1
    if offset + scid_length > len(data):
        return b""
    scid = data[offset : offset + scid_length]
    return b"\x80\x00\x00\x00\x00" + bytes([len(scid)]) + scid + bytes([len(dcid)]) + dcid + b"\x0a\x0a\x0a\x0a"


def _parse_quic_packet(data: bytes) -> dict[str, Any]:
    if len(data) < 6 or not data[0] & 0x80:
        return {}

    event: dict[str, Any] = {
        "version": f"0x{int.from_bytes(data[1:5], 'big'):08x}",
        "fixed_bit": bool(data[0] & 0x40),
    }
    offset = 5
    dcid_length = data[offset]
    offset += 1
    if offset + dcid_length > len(data):
        event["malformed"] = "truncated_dcid"
        return event
    dcid = data[offset : offset + dcid_length]
    offset += dcid_length
    event["dcid_length"] = dcid_length
    if dcid:
        event["dcid_sha256"] = sha256(dcid).hexdigest()
    if offset >= len(data):
        event["malformed"] = "missing_scid_length"
        return event
    scid_length = data[offset]
    offset += 1
    if offset + scid_length > len(data):
        event["scid_length"] = scid_length
        event["malformed"] = "truncated_scid"
        return event
    scid = data[offset : offset + scid_length]
    event["scid_length"] = scid_length
    if scid:
        event["scid_sha256"] = sha256(scid).hexdigest()
    return event
