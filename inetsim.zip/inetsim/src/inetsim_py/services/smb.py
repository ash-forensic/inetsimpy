from __future__ import annotations

from hashlib import sha256
from typing import Any
import asyncio
import struct

from ..acl import SubnetAcl
from ..config import GlobalConfig, SmbConfig
from ..logger import EventLogger
from .base import RunningService, close_writer

SMB1_MAGIC = b"\xffSMB"
SMB2_MAGIC = b"\xfeSMB"
STATUS_NOT_SUPPORTED = 0xC00000BB
STATUS_SUCCESS = 0x00000000
STATUS_INVALID_SMB = 0x00010002
STATUS_NO_MORE_FILES = 0x80000006

SMB2_DIALECTS = {
    0x0202: "SMB 2.0.2",
    0x0210: "SMB 2.1",
    0x0300: "SMB 3.0",
    0x0302: "SMB 3.0.2",
    0x0311: "SMB 3.1.1",
}

SMB2_COMMANDS = {
    0: "NEGOTIATE",
    1: "SESSION_SETUP",
    2: "LOGOFF",
    3: "TREE_CONNECT",
    4: "TREE_DISCONNECT",
    5: "CREATE",
    6: "CLOSE",
    7: "FLUSH",
    8: "READ",
    9: "WRITE",
    10: "LOCK",
    11: "IOCTL",
    12: "CANCEL",
    13: "ECHO",
    14: "QUERY_DIRECTORY",
    15: "CHANGE_NOTIFY",
    16: "QUERY_INFO",
    17: "SET_INFO",
}


class SmbService:
    def __init__(self, config: SmbConfig, global_config: GlobalConfig, logger: EventLogger, acl: SubnetAcl) -> None:
        self._config = config
        self._global = global_config
        self._logger = logger
        self._acl = acl

    async def start(self) -> RunningService:
        servers = [
            await asyncio.start_server(
                lambda reader, writer: self._handle_client(self._config.port, reader, writer),
                self._global.listen_host,
                self._config.port,
            )
        ]
        if self._config.netbios_port and self._config.netbios_port != self._config.port:
            servers.append(
                await asyncio.start_server(
                    lambda reader, writer: self._handle_client(self._config.netbios_port, reader, writer),
                    self._global.listen_host,
                    self._config.netbios_port,
                )
            )
        return RunningService("smb", servers, [])

    async def _handle_client(self, port: int, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        peer = _peer(writer)
        if peer is None or not self._acl.allows(peer):
            await close_writer(writer)
            return

        event: dict[str, Any] = {"client_ip": peer, "port": port, "server_name": self._config.server_name, "workgroup": self._config.workgroup, "frames": []}
        try:
            while True:
                try:
                    frame = await asyncio.wait_for(
                        read_netbios_session_frame(
                            reader,
                            writer,
                            self._config.max_request_bytes,
                            allow_session_request=port == self._config.netbios_port,
                        ),
                        timeout=self._global.read_timeout_seconds,
                    )
                except asyncio.IncompleteReadError:
                    break
                except asyncio.TimeoutError:
                    break
                frame_event = classify_smb_frame(frame)
                frame_event["request_size"] = len(frame)
                frame_event["request_sha256"] = sha256(frame).hexdigest()
                response = build_response(frame)
                if response:
                    writer.write(wrap_direct_tcp(response))
                    await writer.drain()
                    frame_event["response_size"] = len(response)
                event["frames"].append(frame_event)
                if len(event["frames"]) == 1:
                    event.update(frame_event)
                if len(event["frames"]) >= self._global.max_command_count:
                    event["frames_truncated"] = True
                    break
        except Exception as exc:
            event["error"] = exc.__class__.__name__
        finally:
            await self._logger.write("smb", event)
            await close_writer(writer)


async def read_netbios_session_frame(reader: asyncio.StreamReader, writer: asyncio.StreamWriter, max_size: int, allow_session_request: bool = True) -> bytes:
    header = await reader.readexactly(4)
    if header[0] == 0x81:
        if not allow_session_request:
            raise ValueError("NetBIOS session request is not valid on direct-hosted SMB")
        size = int.from_bytes(header[1:4], "big")
        if size > max_size:
            raise ValueError("invalid NetBIOS session request size")
        await reader.readexactly(size)
        writer.write(b"\x82\x00\x00\x00")
        await writer.drain()
        header = await reader.readexactly(4)
    if header[0] != 0x00:
        raise ValueError("unsupported NetBIOS session message")
    size = int.from_bytes(header[1:4], "big")
    if size <= 0 or size > max_size:
        raise ValueError("invalid SMB frame size")
    return await reader.readexactly(size)


async def read_direct_tcp_frame(reader: asyncio.StreamReader, max_size: int) -> bytes:
    class _NoopWriter:
        def write(self, data: bytes) -> None:
            return None

        async def drain(self) -> None:
            return None

    return await read_netbios_session_frame(reader, _NoopWriter(), max_size, allow_session_request=False)


def classify_smb_frame(frame: bytes) -> dict[str, Any]:
    if frame.startswith(SMB2_MAGIC):
        return _classify_smb2(frame)
    if frame.startswith(SMB1_MAGIC):
        return _classify_smb1(frame)
    return {"version": "unknown"}


def _classify_smb2(frame: bytes) -> dict[str, Any]:
    event: dict[str, Any] = {"version": "SMB2+"}
    if len(frame) < 64:
        event["malformed"] = "short_smb2_header"
        return event

    command = int.from_bytes(frame[12:14], "little")
    message_id = int.from_bytes(frame[24:32], "little")
    event.update({"command": command, "message_id": message_id})
    event["command_name"] = SMB2_COMMANDS.get(command, f"UNKNOWN_{command}")
    if command == 0:
        event["dialects"] = _parse_smb2_dialects(frame)
    return event


def _parse_smb2_dialects(frame: bytes) -> list[str]:
    if len(frame) < 100:
        return []
    body_offset = 64
    dialect_count = int.from_bytes(frame[body_offset + 2 : body_offset + 4], "little")
    dialect_offset = body_offset + 36
    dialects: list[str] = []
    for index in range(dialect_count):
        start = dialect_offset + index * 2
        if start + 2 > len(frame):
            break
        value = int.from_bytes(frame[start : start + 2], "little")
        dialects.append(SMB2_DIALECTS.get(value, f"0x{value:04x}"))
    return dialects


def _classify_smb1(frame: bytes) -> dict[str, Any]:
    event: dict[str, Any] = {"version": "SMB1"}
    if len(frame) < 32:
        event["malformed"] = "short_smb1_header"
        return event

    command = frame[4]
    event["command"] = command
    if command == 0x72:
        event["command_name"] = "NEGOTIATE"
        event["dialects"] = _parse_smb1_dialects(frame)
    return event


def _parse_smb1_dialects(frame: bytes) -> list[str]:
    if len(frame) < 35:
        return []
    word_count = frame[32]
    byte_count_offset = 33 + word_count * 2
    if byte_count_offset + 2 > len(frame):
        return []
    byte_count = int.from_bytes(frame[byte_count_offset : byte_count_offset + 2], "little")
    data_offset = byte_count_offset + 2
    data = frame[data_offset : data_offset + byte_count]
    dialects: list[str] = []
    for part in data.split(b"\x02"):
        if not part:
            continue
        dialects.append(part.split(b"\x00", 1)[0].decode("ascii", "replace"))
    return [dialect for dialect in dialects if dialect]


def build_error_response(frame: bytes) -> bytes:
    return build_response(frame)


def build_response(frame: bytes) -> bytes:
    if frame.startswith(SMB2_MAGIC) and len(frame) >= 64:
        command = int.from_bytes(frame[12:14], "little")
        if command == 0:
            return _smb2_negotiate_response(frame)
        if command == 1:
            return _smb2_session_setup_response(frame)
        if command == 2:
            return _smb2_success_response(frame, b"\x04\x00\x00\x00")
        if command == 3:
            return _smb2_tree_connect_response(frame)
        if command == 4:
            return _smb2_success_response(frame, b"\x04\x00\x00\x00")
        if command == 5:
            return _smb2_create_response(frame)
        if command == 6:
            return _smb2_close_response(frame)
        if command == 7:
            return _smb2_success_response(frame, b"\x04\x00\x00\x00")
        if command == 8:
            return _smb2_read_response(frame)
        if command == 9:
            return _smb2_write_response(frame)
        if command == 13:
            return _smb2_success_response(frame, b"\x04\x00\x00\x00")
        if command == 14:
            return _smb2_query_directory_response(frame)
        if command == 16:
            return _smb2_query_info_response(frame)
        return _smb2_error(frame)
    if frame.startswith(SMB1_MAGIC) and len(frame) >= 32:
        return _smb1_error(frame)
    return b""


def _smb2_error(frame: bytes, status: int = STATUS_NOT_SUPPORTED) -> bytes:
    header = _smb2_header(frame, status)
    return bytes(header) + b"\x09\x00\x00\x00\x00\x00\x00\x00"


def _smb2_negotiate_response(frame: bytes) -> bytes:
    header = _smb2_header(frame)
    body = bytearray(64)
    body[0:2] = (65).to_bytes(2, "little")
    body[2:4] = (1).to_bytes(2, "little")
    body[4:6] = (0x0311).to_bytes(2, "little")
    body[8:24] = b"INETSIMPYSMBDEMO"[:16]
    body[24:28] = (0).to_bytes(4, "little")
    body[28:32] = (65536).to_bytes(4, "little")
    body[32:36] = (65536).to_bytes(4, "little")
    body[36:40] = (65536).to_bytes(4, "little")
    return bytes(header) + bytes(body)


def _smb2_session_setup_response(frame: bytes) -> bytes:
    header = _smb2_header(frame)
    if header[40:48] == b"\x00" * 8:
        header[40:48] = (1).to_bytes(8, "little")
    body = bytearray(8)
    body[0:2] = (9).to_bytes(2, "little")
    body[4:6] = (72).to_bytes(2, "little")
    body[6:8] = (0).to_bytes(2, "little")
    return bytes(header) + bytes(body)


def _smb2_tree_connect_response(frame: bytes) -> bytes:
    header = _smb2_header(frame)
    if header[36:40] == b"\x00" * 4:
        header[36:40] = (1).to_bytes(4, "little")
    body = bytearray(16)
    body[0:2] = (16).to_bytes(2, "little")
    body[2] = 1
    body[4:8] = (0).to_bytes(4, "little")
    body[8:12] = (0).to_bytes(4, "little")
    body[12:16] = (0x001F01FF).to_bytes(4, "little")
    return bytes(header) + bytes(body)


def _smb2_create_response(frame: bytes) -> bytes:
    header = _smb2_header(frame)
    body = bytearray(88)
    body[0:2] = (89).to_bytes(2, "little")
    body[2] = 0
    body[4:8] = (1).to_bytes(4, "little")
    body[40:48] = (4096).to_bytes(8, "little")
    body[48:56] = (64).to_bytes(8, "little")
    body[56:60] = (0x80).to_bytes(4, "little")
    body[64:80] = b"INETSIMPYFILEID1"
    return bytes(header) + bytes(body)


def _smb2_close_response(frame: bytes) -> bytes:
    header = _smb2_header(frame)
    body = bytearray(60)
    body[0:2] = (60).to_bytes(2, "little")
    body[36:44] = (64).to_bytes(8, "little")
    body[44:48] = (0x80).to_bytes(4, "little")
    return bytes(header) + bytes(body)


def _smb2_read_response(frame: bytes) -> bytes:
    data = b"INetSim SMB data\r\n"
    header = _smb2_header(frame)
    body = bytearray(16)
    body[0:2] = (17).to_bytes(2, "little")
    body[2] = 80
    body[4:8] = len(data).to_bytes(4, "little")
    return bytes(header) + bytes(body) + data


def _smb2_write_response(frame: bytes) -> bytes:
    count = 0
    if len(frame) >= 64 + 16:
        count = int.from_bytes(frame[64 + 4 : 64 + 8], "little")
    header = _smb2_header(frame)
    body = bytearray(16)
    body[0:2] = (17).to_bytes(2, "little")
    body[4:8] = count.to_bytes(4, "little")
    return bytes(header) + bytes(body)


def _smb2_query_info_response(frame: bytes) -> bytes:
    data = (64).to_bytes(8, "little") + (4096).to_bytes(8, "little")
    header = _smb2_header(frame)
    body = bytearray(8)
    body[0:2] = (9).to_bytes(2, "little")
    body[2:4] = (72).to_bytes(2, "little")
    body[4:8] = len(data).to_bytes(4, "little")
    return bytes(header) + bytes(body) + data


def _smb2_query_directory_response(frame: bytes) -> bytes:
    filename = "README.txt".encode("utf-16-le")
    entry = bytearray(64 + len(filename))
    entry[0:4] = (0).to_bytes(4, "little")
    entry[4:8] = (1).to_bytes(4, "little")
    entry[40:48] = (64).to_bytes(8, "little")
    entry[48:56] = (4096).to_bytes(8, "little")
    entry[56:60] = (0x80).to_bytes(4, "little")
    entry[60:64] = len(filename).to_bytes(4, "little")
    entry[64:] = filename
    header = _smb2_header(frame)
    body = bytearray(8)
    body[0:2] = (9).to_bytes(2, "little")
    body[2:4] = (72).to_bytes(2, "little")
    body[4:8] = len(entry).to_bytes(4, "little")
    return bytes(header) + bytes(body) + bytes(entry)


def _smb2_success_response(frame: bytes, body: bytes) -> bytes:
    return bytes(_smb2_header(frame)) + body


def _smb2_header(frame: bytes, status: int = STATUS_SUCCESS) -> bytearray:
    header = bytearray(64)
    header[0:4] = SMB2_MAGIC
    header[4:6] = (64).to_bytes(2, "little")
    header[8:12] = status.to_bytes(4, "little")
    header[12:14] = frame[12:14]
    header[14:16] = (1).to_bytes(2, "little")
    header[16:20] = (1).to_bytes(4, "little")
    header[24:32] = frame[24:32]
    header[32:36] = frame[32:36]
    header[36:40] = frame[36:40]
    header[40:48] = frame[40:48]
    return header


def _smb1_error(frame: bytes) -> bytes:
    header = bytearray(32)
    header[0:4] = SMB1_MAGIC
    header[4] = frame[4]
    header[5:9] = STATUS_INVALID_SMB.to_bytes(4, "little")
    header[9] = 0x88
    header[24:26] = frame[24:26]
    header[28:30] = frame[28:30]
    header[30:32] = frame[30:32]
    return bytes(header) + b"\x00\x00\x00"


def wrap_direct_tcp(payload: bytes) -> bytes:
    if len(payload) > 0xFFFFFF:
        raise ValueError("SMB payload too large")
    return b"\x00" + len(payload).to_bytes(3, "big") + payload


def _peer(writer: asyncio.StreamWriter) -> str | None:
    peer = writer.get_extra_info("peername")
    if not peer:
        return None
    return str(peer[0])
