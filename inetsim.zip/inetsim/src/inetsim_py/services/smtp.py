from __future__ import annotations

from base64 import b64decode
from binascii import Error as BinasciiError
from dataclasses import dataclass
from hashlib import sha256
from typing import Any
import asyncio
import ssl

from ..acl import SubnetAcl
from ..artifacts import ArtifactStore
from ..config import GlobalConfig, SmtpConfig
from ..logger import EventLogger
from .base import RunningService, close_writer
from .https import _ensure_lab_ca, _generate_signed_leaf_cert, _server_context
from ..pki import certificate_needs_crl


@dataclass(slots=True)
class _AuthState:
    mechanism: str
    stage: str


class SmtpService:
    def __init__(self, config: SmtpConfig, global_config: GlobalConfig, logger: EventLogger, artifacts: ArtifactStore, acl: SubnetAcl) -> None:
        self._config = config
        self._global = global_config
        self._logger = logger
        self._artifacts = artifacts
        self._acl = acl

    async def start(self) -> RunningService:
        servers = [await asyncio.start_server(lambda r, w: self._handle_client(r, w, implicit_tls=False), self._global.listen_host, self._config.port)]
        if self._config.implicit_tls_port:
            servers.append(
                await asyncio.start_server(
                    lambda r, w: self._handle_client(r, w, implicit_tls=True),
                    self._global.listen_host,
                    self._config.implicit_tls_port,
                    ssl=_service_tls_context(self._global.artifact_dir, self._config.hostname, self._global.tls_crl_url),
                )
            )
        return RunningService("smtp", servers, [])

    async def _handle_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter, implicit_tls: bool = False) -> None:
        peer = _peer(writer)
        if peer is None or not self._acl.allows(peer):
            await close_writer(writer)
            return

        event: dict[str, Any] = {"client_ip": peer, "commands": [], "mail_from": "", "rcpt_to": []}
        if implicit_tls:
            event["tls_established"] = True
            event["implicit_tls"] = True
        writer.write(f"220 {self._config.hostname} {self._config.banner}\r\n".encode("ascii"))
        await writer.drain()
        in_data = False
        auth_state: _AuthState | None = None
        message_lines: list[bytes] = []
        message_size = 0
        message_truncated = False
        try:
            while True:
                line = await asyncio.wait_for(reader.readline(), timeout=self._global.read_timeout_seconds)
                if not line:
                    break
                text = line.decode("utf-8", "replace").rstrip("\r\n")
                upper = text.upper()
                if in_data:
                    if text == ".":
                        payload = b"".join(message_lines)
                        event["message_size"] = message_size
                        if message_truncated:
                            event["message_truncated"] = True
                        event["message"] = self._artifacts.save("smtp", payload, ".eml")
                        writer.write(b"250 queued\r\n")
                        in_data = False
                    else:
                        data_line = _unstuff_data_line(line)
                        message_size += len(data_line)
                        if message_size <= self._global.max_body_bytes:
                            message_lines.append(data_line)
                        else:
                            message_truncated = True
                    await writer.drain()
                    continue

                if auth_state is not None:
                    _record_command(event, "AUTH-CONT <redacted>", self._global.max_command_count)
                    auth_state = _handle_auth_continuation(event, auth_state, text, writer)
                    await writer.drain()
                    continue

                if not text:
                    writer.write(b"500 command unrecognized\r\n")
                    await writer.drain()
                    continue

                command, argument = _split_command(text)
                _record_command(event, _sanitize_command(command, argument), self._global.max_command_count)
                if command in {"EHLO", "HELO"}:
                    writer.write(f"250-{self._config.hostname}\r\n250-STARTTLS\r\n250 SIZE {self._global.max_body_bytes}\r\n".encode("ascii"))
                elif command == "MAIL" and argument.upper().startswith("FROM:"):
                    event["mail_from"] = argument[5:].strip()
                    writer.write(b"250 sender ok\r\n")
                elif command == "RCPT" and argument.upper().startswith("TO:"):
                    event["rcpt_to"].append(argument[3:].strip())
                    writer.write(b"250 recipient ok\r\n")
                elif command == "STARTTLS":
                    event["tls_requested"] = True
                    writer.write(b"220 ready to start TLS\r\n")
                    await writer.drain()
                    try:
                        await asyncio.wait_for(writer.start_tls(_service_tls_context(self._global.artifact_dir, self._config.hostname, self._global.tls_crl_url)), timeout=min(self._global.read_timeout_seconds, 1.0))
                        event["tls_established"] = True
                    except (AttributeError, ssl.SSLError, OSError) as exc:
                        event["tls_error"] = exc.__class__.__name__
                        break
                elif command == "AUTH":
                    auth_state = _handle_auth_command(event, argument, writer)
                elif command == "DATA":
                    in_data = True
                    auth_state = None
                    message_lines.clear()
                    message_size = 0
                    message_truncated = False
                    writer.write(b"354 end with <CRLF>.<CRLF>\r\n")
                elif command == "RSET":
                    auth_state = None
                    message_lines.clear()
                    message_size = 0
                    message_truncated = False
                    writer.write(b"250 reset\r\n")
                elif command == "QUIT":
                    writer.write(b"221 bye\r\n")
                    await writer.drain()
                    break
                else:
                    writer.write(b"250 ok\r\n")
                await writer.drain()
        except Exception as exc:
            event["error"] = exc.__class__.__name__
        finally:
            await self._logger.write("smtp", event)
            await close_writer(writer)


def _record_command(event: dict[str, Any], command: str, limit: int) -> None:
    commands = event["commands"]
    if len(commands) < limit:
        commands.append(command)
    else:
        event["commands_truncated"] = True


def _peer(writer: asyncio.StreamWriter) -> str | None:
    peer = writer.get_extra_info("peername")
    if not peer:
        return None
    return str(peer[0])


def _split_command(text: str) -> tuple[str, str]:
    parts = text.split(None, 1)
    return parts[0].upper(), parts[1] if len(parts) == 2 else ""


def _unstuff_data_line(line: bytes) -> bytes:
    if line.startswith(b"."):
        return line[1:]
    return line


def _sanitize_command(command: str, argument: str) -> str:
    if command == "AUTH":
        return "AUTH <redacted>" if argument else "AUTH"
    return f"{command} {argument}".rstrip()


def _handle_auth_command(event: dict[str, Any], argument: str, writer: asyncio.StreamWriter) -> _AuthState | None:
    mechanism, initial_response = _split_auth_argument(argument)
    if not mechanism:
        writer.write(b"501 syntax: AUTH mechanism [initial-response]\r\n")
        return None

    event["auth_mechanism"] = mechanism
    if mechanism == "PLAIN":
        if initial_response:
            _record_plain_auth(event, initial_response)
            writer.write(b"235 authentication accepted\r\n")
            return None
        writer.write(b"334 \r\n")
        return _AuthState(mechanism="PLAIN", stage="response")

    if mechanism == "LOGIN":
        if initial_response:
            _record_auth_value(event, "auth_username", initial_response)
            writer.write(b"334 UGFzc3dvcmQ6\r\n")
            return _AuthState(mechanism="LOGIN", stage="password")
        writer.write(b"334 VXNlcm5hbWU6\r\n")
        return _AuthState(mechanism="LOGIN", stage="username")

    writer.write(b"504 authentication mechanism not supported\r\n")
    return None


def _handle_auth_continuation(event: dict[str, Any], state: _AuthState, text: str, writer: asyncio.StreamWriter) -> _AuthState | None:
    if text == "*":
        writer.write(b"501 authentication aborted\r\n")
        return None

    if state.mechanism == "PLAIN":
        _record_plain_auth(event, text)
        writer.write(b"235 authentication accepted\r\n")
        return None

    if state.mechanism == "LOGIN" and state.stage == "username":
        _record_auth_value(event, "auth_username", text)
        writer.write(b"334 UGFzc3dvcmQ6\r\n")
        return _AuthState(mechanism="LOGIN", stage="password")

    if state.mechanism == "LOGIN" and state.stage == "password":
        _record_auth_value(event, "auth_password", text)
        writer.write(b"235 authentication accepted\r\n")
        return None

    writer.write(b"504 authentication mechanism not supported\r\n")
    return None


def _split_auth_argument(argument: str) -> tuple[str, str]:
    parts = argument.strip().split(None, 1)
    if not parts:
        return "", ""
    return parts[0].upper(), parts[1] if len(parts) == 2 else ""


def _record_plain_auth(event: dict[str, Any], response: str) -> None:
    decoded, valid = _decode_auth_response(response)
    event["auth_response_valid_base64"] = valid
    fields = decoded.split(b"\x00")
    if len(fields) >= 3:
        _record_bytes(event, "auth_identity", fields[1])
        _record_bytes(event, "auth_password", fields[2])
        return
    _record_bytes(event, "auth_response", decoded)


def _record_auth_value(event: dict[str, Any], prefix: str, response: str) -> None:
    decoded, valid = _decode_auth_response(response)
    event[f"{prefix}_valid_base64"] = valid
    _record_bytes(event, prefix, decoded)


def _decode_auth_response(response: str) -> tuple[bytes, bool]:
    try:
        return b64decode(response.encode("ascii"), validate=True), True
    except (BinasciiError, UnicodeEncodeError, ValueError):
        return response.encode("utf-8", "replace"), False


def _record_bytes(event: dict[str, Any], prefix: str, value: bytes) -> None:
    event[f"{prefix}_length"] = len(value)
    event[f"{prefix}_sha256"] = sha256(value).hexdigest()


def _service_tls_context(artifact_dir, hostname: str, crl_url: str = "") -> ssl.SSLContext:
    cert_dir = artifact_dir / "tls"
    cert_dir.mkdir(parents=True, exist_ok=True)
    ca_cert = cert_dir / "inetsim-ca.crt"
    ca_key = cert_dir / "inetsim-ca.key"
    _ensure_lab_ca(ca_cert, ca_key)
    safe = "".join(char for char in hostname.lower() if char.isalnum() or char in ".-") or "mail.local"
    cert_file = cert_dir / f"{safe}-smtp.crt"
    key_file = cert_dir / f"{safe}-smtp.key"
    if certificate_needs_crl(cert_file, key_file, crl_url):
        _generate_signed_leaf_cert(cert_file, key_file, ca_cert, ca_key, safe, crl_url)
    return _server_context(cert_file, key_file)
