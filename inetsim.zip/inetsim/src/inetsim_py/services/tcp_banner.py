from __future__ import annotations

from hashlib import sha256
from typing import Any
import asyncio
import errno

from ..acl import SubnetAcl
from ..config import GlobalConfig, TcpBannerConfig
from ..logger import EventLogger
from .base import RunningService, close_writer

PORT_FALLBACKS = {22: 2222}


class TcpBannerService:
    def __init__(self, config: TcpBannerConfig, global_config: GlobalConfig, logger: EventLogger, acl: SubnetAcl) -> None:
        self._config = config
        self._global = global_config
        self._logger = logger
        self._acl = acl
        self._bound_banners: dict[int, str] = {}

    async def start(self) -> RunningService:
        servers = []
        notes = []
        self._bound_banners.clear()
        for port, banner in self._config.ports.items():
            server, bound_port, note = await self._start_banner_server(port, banner)
            servers.append(server)
            self._bound_banners[bound_port] = banner
            if note:
                notes.append(note)
        return RunningService("tcp-banners", servers, [], notes=notes)

    async def _start_banner_server(self, port: int, banner: str) -> tuple[asyncio.AbstractServer, int, str]:
        try:
            server = await asyncio.start_server(lambda r, w, bound_port=port: self._handle_client(bound_port, r, w), self._global.listen_host, port)
            return server, port, ""
        except OSError as exc:
            fallback = PORT_FALLBACKS.get(port)
            if fallback is None or exc.errno != errno.EADDRINUSE:
                raise
            server = await asyncio.start_server(lambda r, w, bound_port=fallback: self._handle_client(bound_port, r, w), self._global.listen_host, fallback)
            return server, fallback, f"tcp banner port {port} was in use; bound fallback port {fallback}"

    async def _handle_client(self, port: int, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        peer = _peer(writer)
        if peer is None or not self._acl.allows(peer):
            await close_writer(writer)
            return

        event: dict[str, Any] = {"client_ip": peer, "port": port}
        try:
            writer.write(self._bound_banners[port].encode("utf-8"))
            await writer.drain()
            data = await asyncio.wait_for(reader.read(4096), timeout=self._global.read_timeout_seconds)
            if data:
                event["client_bytes"] = len(data)
                event["client_sha256"] = sha256(data).hexdigest()
        except Exception as exc:
            event["error"] = exc.__class__.__name__
        finally:
            await self._logger.write("tcp", event)
            await close_writer(writer)


def _peer(writer: asyncio.StreamWriter) -> str | None:
    peer = writer.get_extra_info("peername")
    if not peer:
        return None
    return str(peer[0])
