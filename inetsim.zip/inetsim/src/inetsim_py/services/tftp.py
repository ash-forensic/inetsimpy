from __future__ import annotations

from hashlib import sha256
from pathlib import PurePosixPath
from typing import Any
import asyncio
import struct

from ..acl import SubnetAcl
from ..artifacts import ArtifactStore
from ..config import GlobalConfig, TftpConfig
from ..logger import EventLogger
from .base import RunningService

OP_RRQ = 1
OP_WRQ = 2
OP_DATA = 3
OP_ACK = 4
OP_ERROR = 5
BLOCK_SIZE = 512
TRANSFER_TTL_SECONDS = 60.0


class TftpService:
    def __init__(self, config: TftpConfig, global_config: GlobalConfig, logger: EventLogger, artifacts: ArtifactStore, acl: SubnetAcl) -> None:
        self._config = config
        self._global = global_config
        self._logger = logger
        self._artifacts = artifacts
        self._acl = acl
        self._writes: dict[tuple[str, int], dict[str, Any]] = {}
        self._reads: dict[tuple[str, int], dict[str, Any]] = {}
        self._cleanup_task: asyncio.Task[None] | None = None

    async def start(self) -> RunningService:
        loop = asyncio.get_running_loop()
        transport, _ = await loop.create_datagram_endpoint(lambda: _TftpProtocol(self), local_addr=(self._global.listen_host, self._config.port))
        self._cleanup_task = asyncio.create_task(self._cleanup_loop())
        return RunningService("tftp", [], [transport])

    async def handle_datagram(self, data: bytes, peer: tuple[str, int], transport: asyncio.DatagramTransport) -> None:
        if not self._acl.allows(peer[0]):
            return
        self._cleanup_transfers()
        event: dict[str, Any] = {"client_ip": peer[0], "client_port": peer[1], "bytes": len(data)}
        try:
            if len(data) < 2:
                raise ValueError("short packet")
            opcode = struct.unpack("!H", data[:2])[0]
            event["opcode"] = opcode
            if opcode == OP_RRQ:
                await self._handle_rrq(data, peer, transport, event)
            elif opcode == OP_WRQ:
                await self._handle_wrq(data, peer, transport, event)
            elif opcode == OP_DATA:
                await self._handle_data(data, peer, transport, event)
            elif opcode == OP_ACK:
                await self._handle_ack(data, peer, transport, event)
            else:
                transport.sendto(_error(4, "unsupported operation"), peer)
                event["error"] = "UnsupportedOpcode"
        except Exception as exc:
            transport.sendto(_error(0, "request failed"), peer)
            event["error"] = exc.__class__.__name__
        finally:
            await self._logger.write("tftp", event)

    async def _handle_rrq(self, data: bytes, peer: tuple[str, int], transport: asyncio.DatagramTransport, event: dict[str, Any]) -> None:
        filename, mode = _parse_request(data)
        path = _normalize_path(filename)
        payload = self._file_bytes(path)
        event.update({"operation": "rrq", "path": path, "mode": mode, "response_size": len(payload)})
        if len(payload) >= BLOCK_SIZE:
            self._reads[peer] = {"path": path, "data": payload, "next": 2, "last_seen": _loop_time()}
        transport.sendto(struct.pack("!HH", OP_DATA, 1) + payload[:BLOCK_SIZE], peer)

    async def _handle_wrq(self, data: bytes, peer: tuple[str, int], transport: asyncio.DatagramTransport, event: dict[str, Any]) -> None:
        filename, mode = _parse_request(data)
        path = _normalize_path(filename)
        event.update({"operation": "wrq", "path": path, "mode": mode})
        if not self._config.allow_uploads:
            transport.sendto(_error(2, "writes disabled"), peer)
            event["error"] = "WritesDisabled"
            return
        self._writes[peer] = {"path": path, "data": bytearray(), "expected": 1, "last_seen": _loop_time()}
        transport.sendto(struct.pack("!HH", OP_ACK, 0), peer)

    async def _handle_data(self, data: bytes, peer: tuple[str, int], transport: asyncio.DatagramTransport, event: dict[str, Any]) -> None:
        if len(data) < 4:
            raise ValueError("short data packet")
        state = self._writes.get(peer)
        if state is None:
            transport.sendto(_error(5, "unknown transfer id"), peer)
            event["error"] = "UnknownTransfer"
            return
        block = struct.unpack("!H", data[2:4])[0]
        chunk = data[4:]
        event.update({"operation": "data", "path": state["path"], "block": block, "chunk_size": len(chunk)})
        if block == state["expected"]:
            if len(state["data"]) + len(chunk) > self._global.max_body_bytes:
                event["upload_size"] = len(state["data"]) + len(chunk)
                event["upload_truncated"] = True
                transport.sendto(_error(3, "upload exceeds configured limit"), peer)
                self._writes.pop(peer, None)
                return
            state["data"].extend(chunk)
            state["expected"] += 1
            state["last_seen"] = _loop_time()
        transport.sendto(struct.pack("!HH", OP_ACK, block), peer)
        if len(chunk) < BLOCK_SIZE:
            payload = bytes(state["data"])
            event["upload"] = self._artifacts.save("tftp", payload)
            event["upload_sha256"] = sha256(payload).hexdigest()
            event["upload_size"] = len(payload)
            self._writes.pop(peer, None)

    async def _handle_ack(self, data: bytes, peer: tuple[str, int], transport: asyncio.DatagramTransport, event: dict[str, Any]) -> None:
        if len(data) < 4:
            raise ValueError("short ack packet")
        block = struct.unpack("!H", data[2:4])[0]
        event.update({"operation": "ack", "ack_block": block})
        state = self._reads.get(peer)
        if state is None:
            return
        state["last_seen"] = _loop_time()
        next_block = int(state["next"])
        if block + 1 != next_block:
            return
        payload = bytes(state["data"])
        start = (next_block - 1) * BLOCK_SIZE
        chunk = payload[start : start + BLOCK_SIZE]
        transport.sendto(struct.pack("!HH", OP_DATA, next_block) + chunk, peer)
        event.update({"path": state["path"], "sent_block": next_block, "chunk_size": len(chunk)})
        if len(chunk) < BLOCK_SIZE:
            self._reads.pop(peer, None)
        else:
            state["next"] = next_block + 1

    def _cleanup_transfers(self) -> None:
        cutoff = _loop_time() - TRANSFER_TTL_SECONDS
        for store in (self._reads, self._writes):
            stale = [peer for peer, state in store.items() if float(state.get("last_seen", 0.0)) < cutoff]
            for peer in stale:
                store.pop(peer, None)

    async def _cleanup_loop(self) -> None:
        try:
            while True:
                await asyncio.sleep(TRANSFER_TTL_SECONDS)
                self._cleanup_transfers()
        except asyncio.CancelledError:
            pass

    def _file_bytes(self, path: str) -> bytes:
        if path in self._config.files:
            return self._config.files[path].encode("utf-8")
        name = PurePosixPath(path).name or "file.bin"
        return f"File: {name}\nStatus: available\n".encode("utf-8")


class _TftpProtocol(asyncio.DatagramProtocol):
    def __init__(self, service: TftpService) -> None:
        self._service = service
        self._transport: asyncio.DatagramTransport | None = None

    def connection_made(self, transport: asyncio.BaseTransport) -> None:
        self._transport = transport  # type: ignore[assignment]

    def datagram_received(self, data: bytes, addr: tuple[str, int]) -> None:
        if self._transport is not None:
            asyncio.create_task(self._service.handle_datagram(data, addr, self._transport))


def _parse_request(data: bytes) -> tuple[str, str]:
    parts = data[2:].split(b"\x00")
    if len(parts) < 2:
        raise ValueError("malformed request")
    filename = parts[0].decode("utf-8", "replace")
    mode = parts[1].decode("ascii", "replace").lower() or "octet"
    return filename, mode


def _normalize_path(path: str) -> str:
    normalized = "/" + str(PurePosixPath("/", path.replace("\\", "/")).relative_to("/"))
    if ".." in PurePosixPath(normalized).parts:
        return "/" + PurePosixPath(normalized).name
    return normalized


def _error(code: int, message: str) -> bytes:
    return struct.pack("!HH", OP_ERROR, code) + message.encode("ascii", "replace") + b"\x00"


def _loop_time() -> float:
    return asyncio.get_running_loop().time()
