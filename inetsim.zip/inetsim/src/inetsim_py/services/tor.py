from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from http import HTTPStatus
from ipaddress import ip_address
from typing import Any
import asyncio
import contextlib
import socket
import ssl
import struct

from ..acl import SubnetAcl
from ..artifacts import ArtifactStore
from ..config import GlobalConfig, HttpConfig, TorControlConfig, TorSocksConfig
from ..logger import EventLogger
from .base import RunningService, close_writer
from .http import _parse_head, _request_host, _response, select_http_payload
from .smtp import _service_tls_context

SOCKS_VERSION = 5
SOCKS_NO_AUTH = 0
SOCKS_USERNAME_PASSWORD = 2
SOCKS_NO_ACCEPTABLE_METHODS = 0xFF
SOCKS_CONNECT = 1
SOCKS_ATYP_IPV4 = 1
SOCKS_ATYP_DOMAIN = 3
SOCKS_ATYP_IPV6 = 4
MAX_LOGGED_CONTROL_COMMAND_LENGTH = 256
SENSITIVE_CONTROL_KEYWORDS = ("PASSWORD", "AUTHENTICATOR", "COOKIE")
DEFAULT_ONION_SERVICE_ID = "inetsim" * 8


class SocksReplySent(Exception):
    pass


class Socks4Error(Exception):
    pass


@dataclass(slots=True)
class SocksConnectRequest:
    host: str
    port: int
    atyp: int
    command: int
    version: int


class TorSocksService:
    def __init__(
        self,
        config: TorSocksConfig,
        http_config: HttpConfig,
        global_config: GlobalConfig,
        logger: EventLogger,
        artifacts: ArtifactStore,
        acl: SubnetAcl,
    ) -> None:
        self._config = config
        self._http_config = http_config
        self._global = global_config
        self._logger = logger
        self._artifacts = artifacts
        self._acl = acl

    async def start(self) -> RunningService:
        server = await asyncio.start_server(self._handle_client, self._global.listen_host, self._config.port)
        return RunningService("tor-socks", [server], [], notes=["tor SOCKS emulator accepts SOCKS5/SOCKS4a CONNECT requests and fake HTTP/HTTPS streams; it does not build real Tor circuits"])

    async def _handle_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        peer = _peer(writer)
        if peer is None or not self._acl.allows(peer):
            await close_writer(writer)
            return

        event: dict[str, Any] = {"client_ip": peer}
        connected = False
        try:
            request = await _read_socks_connect(reader, writer, self._global.read_timeout_seconds, event)
            event["socks_version"] = request.version
            onion_metadata = _onion_metadata(request.host)
            event.update(
                {
                    "command": "CONNECT" if request.command == SOCKS_CONNECT else request.command,
                    "target_host": request.host,
                    "target_port": request.port,
                    **onion_metadata,
                }
            )
            if request.command != SOCKS_CONNECT:
                writer.write(_socks_failure_reply(request, 0x07))
                await writer.drain()
                event["error"] = "UnsupportedCommand"
                return

            writer.write(_socks_success_reply(request))
            await writer.drain()
            connected = True
            event["connect_established"] = True
            await self._handle_stream(reader, writer, request, event)
        except SocksReplySent as exc:
            event["error"] = exc.__class__.__name__
        except Socks4Error as exc:
            event["error"] = exc.__class__.__name__
            with contextlib.suppress(OSError):
                writer.write(b"\x00\x5b\x00\x00\x00\x00\x00\x00")
                await writer.drain()
        except Exception as exc:
            event["error"] = exc.__class__.__name__
            if not connected:
                with contextlib.suppress(OSError):
                    writer.write(_socks5_reply(0x01))
                    await writer.drain()
        finally:
            await self._logger.write("tor_socks", event)
            await close_writer(writer)

    async def _handle_stream(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
        request: SocksConnectRequest,
        event: dict[str, Any],
    ) -> None:
        if request.port == 443:
            first = await _peek_transport_byte(reader, writer, timeout=min(self._global.read_timeout_seconds, 0.1))
            if first and _looks_like_http_start(first):
                first = await asyncio.wait_for(reader.read(1), timeout=self._global.read_timeout_seconds)
                await self._handle_http_stream(reader, writer, request, event, first, "http")
                return
            event["tls_requested"] = True
            try:
                await asyncio.wait_for(
                    writer.start_tls(_service_tls_context(self._global.artifact_dir, _tls_hostname(request.host), self._global.tls_crl_url)),
                    timeout=min(self._global.read_timeout_seconds, 2.0),
                )
                event["tls_established"] = True
                ssl_object = writer.get_extra_info("ssl_object")
                if ssl_object is not None:
                    event["tls_version"] = ssl_object.version() or ""
                    cipher = ssl_object.cipher()
                    event["cipher"] = cipher[0] if cipher else ""
            except (AttributeError, ssl.SSLError, OSError, asyncio.TimeoutError) as exc:
                event["stream_kind"] = "tls"
                event["tls_error"] = exc.__class__.__name__
                return
            await self._handle_http_stream(reader, writer, request, event, b"", "https")
            return

        first = await asyncio.wait_for(reader.read(1), timeout=self._global.read_timeout_seconds)
        if not first:
            event["stream_kind"] = "empty"
            return
        if not _looks_like_http_start(first):
            data = first + await _read_available(reader)
            event.update(
                {
                    "stream_kind": "binary",
                    "initial_bytes": len(data),
                    "initial_sha256": sha256(data).hexdigest(),
                }
            )
            return

        await self._handle_http_stream(reader, writer, request, event, first, "http")

    async def _handle_http_stream(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
        request: SocksConnectRequest,
        event: dict[str, Any],
        first: bytes,
        stream_kind: str,
    ) -> None:
        raw_head = first + await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"), timeout=self._global.read_timeout_seconds)
        request_line, headers = _parse_head(raw_head)
        parts = request_line.split()
        if len(parts) != 3 or not all(parts):
            writer.write(_response(400, "Bad Request", self._http_config.server_header, b"bad request\n", "text/plain; charset=utf-8"))
            await writer.drain()
            event.update({"stream_kind": stream_kind, "target": request_line, "status": 400, "error": "MalformedRequestLine"})
            return
        method, target, version = parts
        try:
            content_length = int(headers.get("content-length", "0"))
        except ValueError:
            writer.write(_response(400, "Bad Request", self._http_config.server_header, b"bad content length\n", "text/plain; charset=utf-8"))
            await writer.drain()
            event.update({"stream_kind": stream_kind, "method": method, "target": target, "version": version, "status": 400, "error": "InvalidContentLength"})
            return
        if content_length < 0:
            writer.write(_response(400, "Bad Request", self._http_config.server_header, b"bad content length\n", "text/plain; charset=utf-8"))
            await writer.drain()
            event.update({"stream_kind": stream_kind, "method": method, "target": target, "version": version, "status": 400, "error": "InvalidContentLength"})
            return
        if content_length > self._global.max_body_bytes:
            writer.write(_response(413, "Payload Too Large", self._http_config.server_header, b"request body too large\n", "text/plain; charset=utf-8"))
            await writer.drain()
            event.update({"stream_kind": stream_kind, "method": method, "target": target, "version": version, "status": 413, "request_body_size": content_length})
            return
        if content_length:
            body = await asyncio.wait_for(reader.readexactly(content_length), timeout=self._global.read_timeout_seconds)
            event["request_body"] = self._artifacts.save("tor_socks", body)

        host = _request_host(target, headers.get("host", "") or request.host)
        payload = select_http_payload(self._http_config, target)
        reason = HTTPStatus(payload.status).phrase if payload.status in HTTPStatus._value2member_map_ else "OK"
        include_body = method != "HEAD"
        writer.write(_response(payload.status, reason, self._http_config.server_header, payload.body, payload.content_type, payload.download_name, include_body))
        await writer.drain()
        event.update(
            {
                "stream_kind": stream_kind,
                "method": method,
                "target": target,
                "path": payload.normalized_path,
                "version": version,
                "host": host,
                "user_agent": headers.get("user-agent", ""),
                "status": payload.status,
                "response_size": len(payload.body) if include_body else 0,
                "response_kind": payload.response_kind,
            }
        )
        if payload.download_name:
            event["download_name"] = payload.download_name
            event["response_sha256"] = sha256(payload.body).hexdigest()


class TorControlService:
    def __init__(self, config: TorControlConfig, socks_config: TorSocksConfig, global_config: GlobalConfig, logger: EventLogger, acl: SubnetAcl) -> None:
        self._config = config
        self._socks_config = socks_config
        self._global = global_config
        self._logger = logger
        self._acl = acl

    async def start(self) -> RunningService:
        server = await asyncio.start_server(self._handle_client, self._global.listen_host, self._config.port)
        return RunningService("tor-control", [server], [], notes=["tor control emulator accepts health-check and hidden-service commands; it does not control a real Tor daemon"])

    async def _handle_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        peer = _peer(writer)
        if peer is None or not self._acl.allows(peer):
            await close_writer(writer)
            return

        event: dict[str, Any] = {"client_ip": peer, "commands": []}
        try:
            while True:
                line = await asyncio.wait_for(reader.readline(), timeout=self._global.read_timeout_seconds)
                if not line:
                    break
                text = line.decode("utf-8", "replace").rstrip("\r\n")
                if not text:
                    continue
                command, argument = _split_control_command(text)
                _record_control_command(event, command, argument, self._global.max_command_count)
                response = _control_response(command, argument, self._config.version, self._global.listen_host, self._socks_config.port, self._config.port)
                writer.write(response)
                await writer.drain()
                if command == "QUIT":
                    break
        except Exception as exc:
            event["error"] = exc.__class__.__name__
        finally:
            await self._logger.write("tor_control", event)
            await close_writer(writer)


async def _read_socks_connect(reader: asyncio.StreamReader, writer: asyncio.StreamWriter, timeout: float, event: dict[str, Any]) -> SocksConnectRequest:
    first = (await asyncio.wait_for(reader.readexactly(1), timeout=timeout))[0]
    if first == SOCKS_VERSION:
        return await _read_socks5_session(reader, writer, timeout, event)
    if first == 4:
        return await _read_socks4a_connect(reader, timeout, event)
    raise ValueError("unsupported SOCKS version")


async def _read_socks5_session(reader: asyncio.StreamReader, writer: asyncio.StreamWriter, timeout: float, event: dict[str, Any]) -> SocksConnectRequest:
    method_count = (await asyncio.wait_for(reader.readexactly(1), timeout=timeout))[0]
    methods = await asyncio.wait_for(reader.readexactly(method_count), timeout=timeout)
    if SOCKS_NO_AUTH in methods:
        method = SOCKS_NO_AUTH
    elif SOCKS_USERNAME_PASSWORD in methods:
        method = SOCKS_USERNAME_PASSWORD
    else:
        writer.write(bytes([SOCKS_VERSION, SOCKS_NO_ACCEPTABLE_METHODS]))
        await writer.drain()
        raise SocksReplySent("no acceptable SOCKS5 auth method")
    writer.write(bytes([SOCKS_VERSION, method]))
    await writer.drain()
    event["auth_method"] = "none" if method == SOCKS_NO_AUTH else "username_password"
    if method == SOCKS_USERNAME_PASSWORD:
        await _read_socks5_username_password(reader, timeout, event)
        writer.write(b"\x01\x00")
        await writer.drain()
    return await _read_socks5_connect(reader, timeout)


async def _read_socks5_connect(reader: asyncio.StreamReader, timeout: float) -> SocksConnectRequest:
    version, command, reserved, atyp = await asyncio.wait_for(reader.readexactly(4), timeout=timeout)
    if version != SOCKS_VERSION or reserved != 0:
        raise ValueError("invalid SOCKS5 request")
    if atyp == SOCKS_ATYP_IPV4:
        host = str(ip_address(await asyncio.wait_for(reader.readexactly(4), timeout=timeout)))
    elif atyp == SOCKS_ATYP_IPV6:
        host = str(ip_address(await asyncio.wait_for(reader.readexactly(16), timeout=timeout)))
    elif atyp == SOCKS_ATYP_DOMAIN:
        length = (await asyncio.wait_for(reader.readexactly(1), timeout=timeout))[0]
        raw_host = await asyncio.wait_for(reader.readexactly(length), timeout=timeout)
        try:
            host = raw_host.decode("ascii").encode("ascii").decode("idna")
        except UnicodeError:
            host = raw_host.decode("ascii", "replace")
    else:
        raise ValueError("unsupported SOCKS5 address type")
    port = struct.unpack("!H", await asyncio.wait_for(reader.readexactly(2), timeout=timeout))[0]
    return SocksConnectRequest(host=host, port=port, atyp=atyp, command=command, version=SOCKS_VERSION)


async def _read_socks5_username_password(reader: asyncio.StreamReader, timeout: float, event: dict[str, Any]) -> None:
    version = (await asyncio.wait_for(reader.readexactly(1), timeout=timeout))[0]
    if version != 1:
        raise ValueError("invalid SOCKS5 username/password auth version")
    username_length = (await asyncio.wait_for(reader.readexactly(1), timeout=timeout))[0]
    username = await asyncio.wait_for(reader.readexactly(username_length), timeout=timeout)
    password_length = (await asyncio.wait_for(reader.readexactly(1), timeout=timeout))[0]
    password = await asyncio.wait_for(reader.readexactly(password_length), timeout=timeout)
    event["auth_username_length"] = len(username)
    event["auth_username_sha256"] = sha256(username).hexdigest()
    event["auth_password_length"] = len(password)
    event["auth_password_sha256"] = sha256(password).hexdigest()


async def _read_socks4a_connect(reader: asyncio.StreamReader, timeout: float, event: dict[str, Any]) -> SocksConnectRequest:
    try:
        command = (await asyncio.wait_for(reader.readexactly(1), timeout=timeout))[0]
        port = struct.unpack("!H", await asyncio.wait_for(reader.readexactly(2), timeout=timeout))[0]
        raw_ip = await asyncio.wait_for(reader.readexactly(4), timeout=timeout)
        user_id = await _read_nul_terminated(reader, timeout)
        event["socks4_userid_length"] = len(user_id)
        event["socks4_userid_sha256"] = sha256(user_id).hexdigest() if user_id else ""
        if raw_ip[:3] == b"\x00\x00\x00" and raw_ip[3] != 0:
            host = (await _read_nul_terminated(reader, timeout)).decode("ascii", "replace")
            atyp = SOCKS_ATYP_DOMAIN
        else:
            host = str(ip_address(raw_ip))
            atyp = SOCKS_ATYP_IPV4
        return SocksConnectRequest(host=host, port=port, atyp=atyp, command=command, version=4)
    except Exception as exc:
        raise Socks4Error("invalid SOCKS4/SOCKS4a request") from exc


async def _read_nul_terminated(reader: asyncio.StreamReader, timeout: float, limit: int = 255) -> bytes:
    data = bytearray()
    while len(data) < limit:
        char = await asyncio.wait_for(reader.readexactly(1), timeout=timeout)
        if char == b"\x00":
            return bytes(data)
        data.extend(char)
    raise ValueError("unterminated SOCKS field")


def _socks5_reply(reply_code: int) -> bytes:
    return bytes([SOCKS_VERSION, reply_code, 0, SOCKS_ATYP_IPV4, 0, 0, 0, 0, 0, 0])


def _socks_success_reply(request: SocksConnectRequest) -> bytes:
    if request.version == 4:
        return b"\x00\x5a" + struct.pack("!H", request.port) + b"\x00\x00\x00\x00"
    return _socks5_reply(0x00)


def _socks_failure_reply(request: SocksConnectRequest, socks5_code: int = 0x01) -> bytes:
    if request.version == 4:
        return b"\x00\x5b" + struct.pack("!H", request.port) + b"\x00\x00\x00\x00"
    return _socks5_reply(socks5_code)


def _looks_like_http_start(data: bytes) -> bool:
    return data[:1] in b"ABCDEFGHIJKLMNOPQRSTUVWXYZ"


def _tls_hostname(host: str) -> str:
    normalized = host.rstrip(".").lower()
    return normalized if normalized else "onion.local"


def _onion_metadata(host: str) -> dict[str, Any]:
    normalized = host.rstrip(".").lower()
    is_onion = normalized.endswith(".onion")
    metadata: dict[str, Any] = {"target_is_onion": is_onion}
    if not is_onion:
        return metadata
    labels = normalized[:-6].split(".")
    label = labels[-1]
    metadata["target_onion_name"] = label
    if len(labels) > 1:
        metadata["target_onion_subdomain"] = ".".join(labels[:-1])
    if len(label) == 16:
        metadata["target_onion_version"] = 2
    elif len(label) == 56:
        metadata["target_onion_version"] = 3
    else:
        metadata["target_onion_version"] = "invalid_length"
    return metadata


async def _read_available(reader: asyncio.StreamReader, limit: int = 4095, timeout: float = 0.05) -> bytes:
    try:
        return await asyncio.wait_for(reader.read(limit), timeout=timeout)
    except asyncio.TimeoutError:
        return b""


async def _peek_transport_byte(reader: asyncio.StreamReader, writer: asyncio.StreamWriter, timeout: float) -> bytes:
    # Optimistic SOCKS data can already be in StreamReader rather than the socket.
    # Inspect without consuming: start_tls needs an unread TLS handshake.
    buffered = getattr(reader, "_buffer", b"")
    if buffered:
        return bytes(buffered[:1])
    transport = writer.transport
    pause_reading = getattr(transport, "pause_reading", None)
    resume_reading = getattr(transport, "resume_reading", None)
    if pause_reading is not None:
        with contextlib.suppress(Exception):
            pause_reading()
    try:
        sock = writer.get_extra_info("socket")
        if sock is None or not hasattr(sock, "dup"):
            return b""
        duplicate = sock.dup()
        try:
            return await asyncio.to_thread(_peek_socket_byte, duplicate, timeout)
        finally:
            duplicate.close()
    finally:
        if resume_reading is not None:
            with contextlib.suppress(Exception):
                resume_reading()


def _peek_socket_byte(sock: socket.socket, timeout: float) -> bytes:
    sock.settimeout(timeout)
    try:
        return sock.recv(1, socket.MSG_PEEK)
    except (BlockingIOError, TimeoutError, socket.timeout, OSError):
        return b""


def _split_control_command(text: str) -> tuple[str, str]:
    parts = text.split(None, 1)
    return parts[0].upper(), parts[1] if len(parts) == 2 else ""


def _record_control_command(event: dict[str, Any], command: str, argument: str, limit: int) -> None:
    commands = event["commands"]
    if len(commands) >= limit:
        event["commands_truncated"] = True
        return
    if _control_argument_is_sensitive(command, argument):
        commands.append(f"{command} <redacted>")
    elif command == "SETCONF" and _contains_sensitive_control_option(argument):
        commands.append("SETCONF <redacted>")
    else:
        commands.append(_truncate_logged_command(f"{command} {argument}".rstrip()))


def _control_argument_is_sensitive(command: str, argument: str) -> bool:
    if command == "AUTHENTICATE" and bool(argument):
        return True
    if command == "ADD_ONION":
        upper = argument.upper()
        return "RSA1024" in upper or "ED25519-V3" in upper or "PRIVATEKEY" in upper
    return False


def _contains_sensitive_control_option(argument: str) -> bool:
    upper = argument.upper()
    return any(keyword in upper for keyword in SENSITIVE_CONTROL_KEYWORDS)


def _truncate_logged_command(value: str) -> str:
    if len(value) <= MAX_LOGGED_CONTROL_COMMAND_LENGTH:
        return value
    return value[:MAX_LOGGED_CONTROL_COMMAND_LENGTH] + "...[truncated]"


def _control_response(command: str, argument: str, version: str, listen_host: str, socks_port: int, control_port: int) -> bytes:
    if command == "PROTOCOLINFO":
        return (
            b"250-PROTOCOLINFO 1\r\n"
            b"250-AUTH METHODS=NULL\r\n"
            + f'250-VERSION Tor="{version}"\r\n'.encode("ascii")
            + b"250 OK\r\n"
        )
    if command == "AUTHENTICATE":
        return b"250 OK\r\n"
    if command == "GETINFO":
        keys = argument.split()
        if not keys:
            return b"552 Unrecognized key\r\n"
        lines = []
        for key in keys:
            line = _getinfo_line(key, version, listen_host, socks_port, control_port)
            if line is None:
                return f"552 Unrecognized key \"{key}\"\r\n".encode("utf-8")
            lines.append(line)
        return b"".join(lines) + b"250 OK\r\n"
    if command == "ADD_ONION":
        return _add_onion_response(argument)
    if command == "DEL_ONION":
        return b"250 OK\r\n"
    if command in {"SIGNAL", "SETEVENTS", "TAKEOWNERSHIP", "RESETCONF", "SETCONF"}:
        return b"250 OK\r\n"
    if command == "QUIT":
        return b"250 closing connection\r\n"
    return b"250 OK\r\n"


def _getinfo_line(key: str, version: str, listen_host: str, socks_port: int, control_port: int) -> bytes | None:
    values = {
        "version": version,
        "status/bootstrap-phase": 'NOTICE BOOTSTRAP PROGRESS=100 TAG=done SUMMARY="Done"',
        "net/listeners/socks": f'"{listen_host}:{socks_port}"',
        "net/listeners/control": f'"{listen_host}:{control_port}"',
        "onions/current": DEFAULT_ONION_SERVICE_ID,
        "onions/detached": "",
        "hs/service/desc/id": DEFAULT_ONION_SERVICE_ID,
        "hs/client/desc/id": DEFAULT_ONION_SERVICE_ID,
    }
    if key not in values:
        return None
    value = values[key]
    return f"250-{key}={value}\r\n".encode("utf-8")


def _add_onion_response(argument: str) -> bytes:
    flags = _control_options(argument).get("FLAGS", "")
    lines = [f"250-ServiceID={DEFAULT_ONION_SERVICE_ID}\r\n".encode("ascii")]
    if "DiscardPK" not in {flag.strip() for flag in flags.split(",")}:
        lines.append(b"250-PrivateKey=ED25519-V3:INETSIMPYPLACEHOLDERKEY\r\n")
    lines.append(b"250 OK\r\n")
    return b"".join(lines)


def _control_options(argument: str) -> dict[str, str]:
    options: dict[str, str] = {}
    for part in argument.split():
        if "=" not in part:
            continue
        key, value = part.split("=", 1)
        options[key.upper()] = value
    return options


def _peer(writer: asyncio.StreamWriter) -> str | None:
    peer = writer.get_extra_info("peername")
    if not peer:
        return None
    return str(peer[0])
