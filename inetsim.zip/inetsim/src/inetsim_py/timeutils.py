from __future__ import annotations

from datetime import datetime, timezone
from email.utils import format_datetime

_fake_time: datetime | None = None


def configure_fake_time(value: str) -> None:
    global _fake_time
    _fake_time = parse_fake_time(value) if value else None


def parse_fake_time(value: str) -> datetime:
    text = value.strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    parsed = datetime.fromisoformat(text)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def now_utc() -> datetime:
    return _fake_time or datetime.now(timezone.utc)


def real_now_utc() -> datetime:
    return datetime.now(timezone.utc)


def iso_now() -> str:
    return now_utc().isoformat()


def http_date() -> str:
    return format_datetime(now_utc(), usegmt=True)


def unix_time() -> float:
    return now_utc().timestamp()
