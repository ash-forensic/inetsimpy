/* Validation helper: fail if the downloaded DLL cannot load or expose stubs. */
#include <windows.h>

int main(int count, char **arguments) {
    if (count != 2) return 10;
    HMODULE module = LoadLibraryA(arguments[1]);
    if (!module) return 11;
    typedef void (CALLBACK *RUN)(HWND, HINSTANCE, LPSTR, int);
    typedef HRESULT (WINAPI *REGISTER)(void);
    RUN run = (RUN)GetProcAddress(module, "Run");
    REGISTER install = (REGISTER)GetProcAddress(module, "DllRegisterServer");
    REGISTER uninstall = (REGISTER)GetProcAddress(module, "DllUnregisterServer");
    if (!run || !install || !uninstall) return 12;
    run(NULL, NULL, NULL, 0);
    if (install() != S_OK || uninstall() != S_OK) return 13;
    return FreeLibrary(module) ? 0 : 14;
}
