from inetsim_py.acl import SubnetAcl


def test_subnet_acl_allows_configured_subnet() -> None:
    acl = SubnetAcl(["10.10.20.0/24"])

    assert acl.allows("10.10.20.5")
    assert not acl.allows("10.10.21.5")
