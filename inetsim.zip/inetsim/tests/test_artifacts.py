import pytest

from inetsim_py.artifacts import ArtifactStore


def test_artifact_store_rejects_non_directory_root(tmp_path) -> None:
    path = tmp_path / "artifacts"
    path.write_text("", encoding="utf-8")

    with pytest.raises(OSError):
        ArtifactStore(path)


def test_artifact_store_does_not_write_over_limit(tmp_path) -> None:
    store = ArtifactStore(tmp_path, max_bytes=2)

    result = store.save("http", b"abc")

    assert result["captured"] is False
    assert result["size"] == 3
    assert not list(tmp_path.rglob("*.bin"))


def test_artifact_store_rejects_unsafe_category_and_suffix(tmp_path) -> None:
    store = ArtifactStore(tmp_path)

    with pytest.raises(ValueError, match="invalid artifact category"):
        store.save("../outside", b"data")
    with pytest.raises(ValueError, match="invalid artifact category"):
        store.save("http/../outside", b"data")
    with pytest.raises(ValueError, match="invalid artifact suffix"):
        store.save("http", b"data", "../x")

    assert not (tmp_path.parent / "outside").exists()
