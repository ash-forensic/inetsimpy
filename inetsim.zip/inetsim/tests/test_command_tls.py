import asyncio
import json
from pathlib import Path
import socket
import ssl

from inetsim_py.acl import SubnetAcl
from inetsim_py.artifacts import ArtifactStore
from inetsim_py.config import FtpConfig, GlobalConfig, Pop3Config, SmtpConfig
from inetsim_py.logger import EventLogger
from inetsim_py.services.ftp import FtpService
from inetsim_py.services.pop3 import Pop3Service
from inetsim_py.services.smtp import SmtpService


def _client_tls_context() -> ssl.SSLContext:
    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    return context


def _free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def test_smtp_starttls_establishes_tls(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = SmtpService(SmtpConfig(port=0), global_config, EventLogger(global_config.log_dir), ArtifactStore(global_config.artifact_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        await reader.readline()
        writer.write(b"STARTTLS\r\n")
        await writer.drain()
        assert (await reader.readline()).startswith(b"220")
        await writer.start_tls(_client_tls_context(), server_hostname="mx01.corp.local")
        writer.write(b"EHLO client\r\nQUIT\r\n")
        await writer.drain()
        assert (await reader.readline()).startswith(b"250-")
        while not (await reader.readline()).startswith(b"250 "):
            pass
        assert (await reader.readline()).startswith(b"221")
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()

    asyncio.run(run())
    event = json.loads((tmp_path / "logs" / "smtp.jsonl").read_text().splitlines()[-1])
    assert event["tls_requested"] is True
    assert event["tls_established"] is True


def test_smtp_implicit_tls_listener_establishes_tls(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        implicit_port = _free_port()
        service = SmtpService(SmtpConfig(port=0, implicit_tls_port=implicit_port), global_config, EventLogger(global_config.log_dir), ArtifactStore(global_config.artifact_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        reader, writer = await asyncio.open_connection(global_config.listen_host, implicit_port, ssl=_client_tls_context(), server_hostname="mx01.corp.local")
        assert (await reader.readline()).startswith(b"220")
        writer.write(b"QUIT\r\n")
        await writer.drain()
        assert (await reader.readline()).startswith(b"221")
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()

    asyncio.run(run())
    event = json.loads((tmp_path / "logs" / "smtp.jsonl").read_text().splitlines()[-1])
    assert event["implicit_tls"] is True
    assert event["tls_established"] is True


def test_smtp_does_not_treat_prefix_as_starttls(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = SmtpService(SmtpConfig(port=0), global_config, EventLogger(global_config.log_dir), ArtifactStore(global_config.artifact_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        await reader.readline()
        writer.write(b"STARTTLSNOW\r\nQUIT\r\n")
        await writer.drain()
        assert (await reader.readline()).startswith(b"250")
        assert (await reader.readline()).startswith(b"221")
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()

    asyncio.run(run())
    event = json.loads((tmp_path / "logs" / "smtp.jsonl").read_text().splitlines()[-1])
    assert "tls_requested" not in event
    assert "STARTTLSNOW" in event["commands"]


def test_ftp_auth_tls_establishes_tls(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = FtpService(FtpConfig(port=0), global_config, EventLogger(global_config.log_dir), ArtifactStore(global_config.artifact_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        await reader.readline()
        writer.write(b"AUTH TLS\r\n")
        await writer.drain()
        assert (await reader.readline()).startswith(b"234")
        await writer.start_tls(_client_tls_context(), server_hostname="ftp.local")
        writer.write(b"PBSZ 0\r\nPROT P\r\nQUIT\r\n")
        await writer.drain()
        assert (await reader.readline()).startswith(b"200")
        assert (await reader.readline()).startswith(b"200")
        assert (await reader.readline()).startswith(b"221")
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()

    asyncio.run(run())


def test_ftp_pasv_list_sends_data_channel_listing(tmp_path) -> None:
    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = FtpService(FtpConfig(port=0), global_config, EventLogger(global_config.log_dir), ArtifactStore(global_config.artifact_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        await reader.readline()
        writer.write(b"USER anonymous\r\nPASS guest\r\nPASV\r\n")
        await writer.drain()
        await reader.readline()
        await reader.readline()
        pasv = (await reader.readline()).decode("ascii")
        numbers = [int(part) for part in pasv.split("(", 1)[1].split(")", 1)[0].split(",")]
        data_port = numbers[-2] * 256 + numbers[-1]
        data_reader, data_writer = await asyncio.open_connection(global_config.listen_host, data_port)
        writer.write(b"LIST\r\n")
        await writer.drain()
        await reader.readline()
        listing = await data_reader.read(1024)
        data_writer.close()
        await data_writer.wait_closed()
        await reader.readline()
        writer.write(b"QUIT\r\n")
        await writer.drain()
        await reader.readline()
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()
        return listing

    listing = asyncio.run(run())
    assert b"README.txt" in listing


def test_ftp_pasv_advertises_configured_address(tmp_path) -> None:
    async def run() -> str:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = FtpService(FtpConfig(port=0, pasv_advertise_ip="10.10.20.1"), global_config, EventLogger(global_config.log_dir), ArtifactStore(global_config.artifact_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        await reader.readline()
        writer.write(b"PASV\r\nQUIT\r\n")
        await writer.drain()
        pasv = (await reader.readline()).decode("ascii")
        await reader.readline()
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()
        return pasv

    assert "(10,10,20,1," in asyncio.run(run())


def test_ftp_implicit_tls_listener_establishes_tls(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        implicit_port = _free_port()
        service = FtpService(FtpConfig(port=0, implicit_tls_port=implicit_port), global_config, EventLogger(global_config.log_dir), ArtifactStore(global_config.artifact_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        reader, writer = await asyncio.open_connection(global_config.listen_host, implicit_port, ssl=_client_tls_context(), server_hostname="ftp.local")
        assert (await reader.readline()).startswith(b"220")
        writer.write(b"QUIT\r\n")
        await writer.drain()
        assert (await reader.readline()).startswith(b"221")
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()

    asyncio.run(run())
    event = json.loads((tmp_path / "logs" / "ftp.jsonl").read_text().splitlines()[-1])
    assert event["implicit_tls"] is True
    assert event["tls_established"] is True


def test_pop3_implicit_tls_listener_establishes_tls(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        implicit_port = _free_port()
        service = Pop3Service(Pop3Config(port=0, implicit_tls_port=implicit_port), global_config, EventLogger(global_config.log_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        reader, writer = await asyncio.open_connection(global_config.listen_host, implicit_port, ssl=_client_tls_context(), server_hostname="mail.corp.local")
        assert (await reader.readline()).startswith(b"+OK")
        writer.write(b"QUIT\r\n")
        await writer.drain()
        assert (await reader.readline()).startswith(b"+OK")
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()

    asyncio.run(run())
    event = json.loads((tmp_path / "logs" / "pop3.jsonl").read_text().splitlines()[-1])
    assert event["implicit_tls"] is True
    assert event["tls_established"] is True


def test_smtp_auth_login_redacts_continuations(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = SmtpService(SmtpConfig(port=0), global_config, EventLogger(global_config.log_dir), None, SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        await reader.readline()

        writer.write(b"AUTH LOGIN\r\n")
        await writer.drain()
        assert (await reader.readline()).startswith(b"334 VXNlcm5hbWU6")
        writer.write(b"YW5hbHlzdA==\r\n")
        await writer.drain()
        assert (await reader.readline()).startswith(b"334 UGFzc3dvcmQ6")
        writer.write(b"c2VjcmV0\r\n")
        await writer.drain()
        assert (await reader.readline()).startswith(b"235")
        writer.write(b"QUIT\r\n")
        await writer.drain()
        await reader.readline()

        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()

    asyncio.run(run())
    event = json.loads((tmp_path / "logs" / "smtp.jsonl").read_text().splitlines()[-1])
    joined = " ".join(event["commands"])
    assert event["auth_mechanism"] == "LOGIN"
    assert event["auth_username_length"] == len("analyst")
    assert event["auth_password_length"] == len("secret")
    assert "AUTH <redacted>" in event["commands"]
    assert event["commands"].count("AUTH-CONT <redacted>") == 2
    assert "YW5hbHlzdA==" not in joined
    assert "c2VjcmV0" not in joined
    assert "secret" not in joined


def test_smtp_auth_plain_records_hashes_not_raw_secret(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = SmtpService(SmtpConfig(port=0), global_config, EventLogger(global_config.log_dir), None, SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        await reader.readline()

        writer.write(b"AUTH PLAIN AGFuYWx5c3QAc2VjcmV0\r\n")
        await writer.drain()
        assert (await reader.readline()).startswith(b"235")
        writer.write(b"QUIT\r\n")
        await writer.drain()
        await reader.readline()

        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()

    asyncio.run(run())
    event = json.loads((tmp_path / "logs" / "smtp.jsonl").read_text().splitlines()[-1])
    joined = " ".join(event["commands"])
    assert event["auth_mechanism"] == "PLAIN"
    assert event["auth_identity_length"] == len("analyst")
    assert event["auth_password_length"] == len("secret")
    assert "AGFuYWx5c3QAc2VjcmV0" not in joined
    assert "secret" not in joined


def test_smtp_auth_with_tab_separator_is_redacted(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = SmtpService(SmtpConfig(port=0), global_config, EventLogger(global_config.log_dir), None, SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        await reader.readline()
        writer.write(b"AUTH\tPLAIN AGFuYWx5c3QAc2VjcmV0\r\nQUIT\r\n")
        await writer.drain()
        assert (await reader.readline()).startswith(b"235")
        await reader.readline()
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()

    asyncio.run(run())
    event = json.loads((tmp_path / "logs" / "smtp.jsonl").read_text().splitlines()[-1])
    joined = " ".join(event["commands"])
    assert "AUTH <redacted>" in event["commands"]
    assert "AGFuYWx5c3QAc2VjcmV0" not in joined
    assert event["auth_password_length"] == len("secret")


def test_smtp_mail_rcpt_and_data_use_parsed_command_tokens(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = SmtpService(SmtpConfig(port=0), global_config, EventLogger(global_config.log_dir), ArtifactStore(global_config.artifact_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        await reader.readline()
        for command in [
            b"MAIL\tFROM:<sender@example.test>\r\n",
            b"RCPT\tTO:<user@example.test>\r\n",
            b"DATA   \r\n",
        ]:
            writer.write(command)
            await writer.drain()
            assert (await reader.readline()).startswith((b"250", b"354"))
        writer.write(b"Subject: x\r\n\r\nbody\r\n.\r\nQUIT   \r\n")
        await writer.drain()
        assert (await reader.readline()).startswith(b"250")
        assert (await reader.readline()).startswith(b"221")
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()

    asyncio.run(run())
    event = json.loads((tmp_path / "logs" / "smtp.jsonl").read_text().splitlines()[-1])
    assert event["mail_from"] == "<sender@example.test>"
    assert event["rcpt_to"] == ["<user@example.test>"]
    assert "DATA" in event["commands"]
    assert "QUIT" in event["commands"]


def test_smtp_blank_command_does_not_close_session(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = SmtpService(SmtpConfig(port=0), global_config, EventLogger(global_config.log_dir), ArtifactStore(global_config.artifact_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        await reader.readline()
        writer.write(b"\r\nNOOP\r\nQUIT\r\n")
        await writer.drain()
        assert (await reader.readline()).startswith(b"500")
        assert (await reader.readline()).startswith(b"250")
        assert (await reader.readline()).startswith(b"221")
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()

    asyncio.run(run())
    event = json.loads((tmp_path / "logs" / "smtp.jsonl").read_text().splitlines()[-1])
    assert "error" not in event
    assert event["commands"] == ["NOOP", "QUIT"]


def test_smtp_data_artifact_removes_dot_stuffing(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = SmtpService(SmtpConfig(port=0), global_config, EventLogger(global_config.log_dir), ArtifactStore(global_config.artifact_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        await reader.readline()
        for command in [b"MAIL FROM:<sender@example.test>\r\n", b"RCPT TO:<user@example.test>\r\n", b"DATA\r\n"]:
            writer.write(command)
            await writer.drain()
            await reader.readline()
        writer.write(b"Subject: x\r\n\r\n..line starts with dot\r\n.\r\nQUIT\r\n")
        await writer.drain()
        assert (await reader.readline()).startswith(b"250")
        assert (await reader.readline()).startswith(b"221")
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()

    asyncio.run(run())
    event = json.loads((tmp_path / "logs" / "smtp.jsonl").read_text().splitlines()[-1])
    artifact_path = event["message"]["path"]
    message = Path(artifact_path).read_bytes()
    assert b".line starts with dot\r\n" in message
    assert b"..line starts with dot" not in message
    assert event["message_size"] == len(message)


def test_ftp_pass_is_redacted_in_logs(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = FtpService(FtpConfig(port=0), global_config, EventLogger(global_config.log_dir), ArtifactStore(global_config.artifact_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        await reader.readline()
        for command in [b"USER analyst\r\n", b"PASS secret\r\n", b"QUIT\r\n"]:
            writer.write(command)
            await writer.drain()
            await reader.readline()
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()

    asyncio.run(run())
    event = json.loads((tmp_path / "logs" / "ftp.jsonl").read_text().splitlines()[-1])
    assert "PASS <redacted>" in event["commands"]
    assert "secret" not in " ".join(event["commands"])
    assert event["password_length"] == 6


def test_ftp_pass_with_tab_separator_is_redacted(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = FtpService(FtpConfig(port=0), global_config, EventLogger(global_config.log_dir), ArtifactStore(global_config.artifact_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        await reader.readline()
        for command in [b"USER\tanalyst\r\n", b"PASS\tsecret\r\n", b"QUIT\r\n"]:
            writer.write(command)
            await writer.drain()
            await reader.readline()
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()

    asyncio.run(run())
    event = json.loads((tmp_path / "logs" / "ftp.jsonl").read_text().splitlines()[-1])
    assert "PASS <redacted>" in event["commands"]
    assert "secret" not in " ".join(event["commands"])
    assert event["password_length"] == 6
