from pathlib import Path
import asyncio
import signal

import pytest

import inetsim_py.cli as cli
from inetsim_py.cli import InterfaceDetectionError, InterfaceNetwork, detect_interface_network, main
from inetsim_py.config import DEFAULT_CONFIG_TOML, ConfigValidationError, config_from_dict, load_config, validate_config


def test_config_parses_tcp_banner_ports_as_ints() -> None:
    config = config_from_dict(
        {
            "global": {"listen_host": "0.0.0.0", "log_dir": "logs", "artifact_dir": "artifacts"},
            "services": {"tcp_banners": {"ports": {"22": "SSH\r\n"}}},
        }
    )

    assert config.global_.listen_host == "0.0.0.0"
    assert config.global_.log_dir == Path("logs")
    assert config.tcp_banners.ports == {22: "SSH\r\n"}


def test_validate_config_rejects_bad_values_and_port_collisions() -> None:
    config = config_from_dict(
        {
            "global": {"allowed_clients": ["not-a-network"]},
            "services": {
                "dns": {"sinkhole_ip": "not-an-ip"},
                "http": {
                    "port": 2525,
                    "default_status": 99,
                    "server_header": "nginx café\r\nX-Bad: yes",
                    "login_page_brand": 123,
                    "login_page_path": "/login?x=1",
                    "fake_download_extensions": {"exe": "windows_executable"},
                    "routes": {"/status?check=1": "ok\n"},
                },
                "smtp": {"port": 2525, "hostname": "mxé\r\n250-X: y", "banner": "ESMTP\r\n250-X: y"},
                "ftp": {"banner": "vsftpd\r\n220 injected"},
                "pop3": {"hostname": "mail\r\n+OK injected", "banner": "ready\r\n+OK injected", "message_from": "postmaster@example.test\r\nX-Bad: y", "message_subject": "héllo\r\nX-Bad: y"},
                "smb": {"max_request_bytes": 0},
            },
        }
    )

    with pytest.raises(ConfigValidationError) as exc_info:
        validate_config(config)

    message = str(exc_info.value)
    assert "global.allowed_clients" in message
    assert "services.dns.sinkhole_ip" in message
    assert "services.http.default_status" in message
    assert "services.http.server_header" in message
    assert "services.http.login_page_brand" in message
    assert "services.http.login_page_path" in message
    assert "services.http.routes./status?check=1" in message
    assert "fake_download_extensions" in message
    assert "services.smtp.hostname" in message
    assert "services.smtp.banner" in message
    assert "services.ftp.banner" in message
    assert "services.pop3.hostname" in message
    assert "services.pop3.banner" in message
    assert "services.pop3.message_from" in message
    assert "services.pop3.message_subject" in message
    assert "services.smb.max_request_bytes" in message
    assert "TCP port 2525" in message


def test_config_rejects_wrong_collection_shapes() -> None:
    with pytest.raises(ConfigValidationError) as exc_info:
        config_from_dict(
            {
                "services": {
                    "dns": {"records": []},
                    "http": {"fake_download_extensions": [], "fake_download_routes": [], "routes": [], "route_statuses": []},
                    "mitmproxy": {"allow_upstream_hosts": "example.test"},
                }
            }
        )

    message = str(exc_info.value)
    assert "services.dns.records must be a table" in message
    assert "services.http.fake_download_extensions must be a table" in message
    assert "services.http.fake_download_routes must be a table" in message
    assert "services.http.routes must be a table" in message
    assert "services.http.route_statuses must be a table" in message
    assert "services.mitmproxy.allow_upstream_hosts must be a list" in message


def test_config_rejects_wrong_scalar_value_types() -> None:
    config = config_from_dict(
        {
            "services": {
                "dns": {"records": {"x.test": 123}},
                "http": {"routes": {"/x": 123}},
                "mitmproxy": {"allow_upstream_hosts": [123]},
                "tcp_banners": {"ports": {"12222": 5}},
            }
        }
    )

    with pytest.raises(ConfigValidationError) as exc_info:
        validate_config(config)

    message = str(exc_info.value)
    assert "services.dns.records.x.test must be a string IP address" in message
    assert "services.http.routes./x must be a string response body" in message
    assert "services.mitmproxy.allow_upstream_hosts[0] must be a non-empty string" in message
    assert "services.tcp_banners.ports.12222 must be a non-empty string banner" in message


def test_enabled_flags_must_be_booleans() -> None:
    config = config_from_dict({"services": {"dns": {"wildcard": "false"}, "smtp": {"enabled": "false"}, "http": {"fake_downloads_enabled": "true"}}})

    with pytest.raises(ConfigValidationError) as exc_info:
        validate_config(config)

    message = str(exc_info.value)
    assert "services.dns.wildcard must be a boolean" in message
    assert "services.smtp.enabled must be a boolean" in message
    assert "services.http.fake_downloads_enabled must be a boolean" in message


def test_integer_fields_reject_bools_and_floats() -> None:
    config = config_from_dict(
        {
            "global": {
                "read_timeout_seconds": True,
                "max_body_bytes": 1.5,
                "max_command_count": False,
                "max_artifact_bytes": 2.5,
            },
            "services": {
                "dns": {"udp_port": True, "ttl": 60.5},
                "http": {"port": True},
                "smb": {"max_request_bytes": 1.5},
                "mitmproxy": {"body_capture_limit": 1.5},
            },
        }
    )

    with pytest.raises(ConfigValidationError) as exc_info:
        validate_config(config)

    message = str(exc_info.value)
    assert "global.read_timeout_seconds must be numeric" in message
    assert "global.max_body_bytes must be an integer" in message
    assert "global.max_command_count must be an integer" in message
    assert "global.max_artifact_bytes must be an integer" in message
    assert "services.dns.udp_port must be an integer from 0 to 65535" in message
    assert "services.dns.ttl must be an integer" in message
    assert "services.http.port must be an integer from 0 to 65535" in message
    assert "services.smb.max_request_bytes must be an integer" in message
    assert "services.mitmproxy.body_capture_limit must be an integer" in message


def test_dns_ttl_must_fit_dns_uint32_field() -> None:
    config = config_from_dict({"services": {"dns": {"ttl": 4294967296}}})

    with pytest.raises(ConfigValidationError) as exc_info:
        validate_config(config)

    assert "services.dns.ttl must be an integer from 0 to 4294967295" in str(exc_info.value)


def test_dns_optional_family_sinkholes_validate_ip_version() -> None:
    config = config_from_dict({"services": {"dns": {"sinkhole_ipv4": "fd00::5", "sinkhole_ipv6": "10.10.20.5"}}})

    with pytest.raises(ConfigValidationError) as exc_info:
        validate_config(config)

    message = str(exc_info.value)
    assert "services.dns.sinkhole_ipv4 must be an IPv4 address" in message
    assert "services.dns.sinkhole_ipv6 must be an IPv6 address" in message


def test_timeout_rejects_non_finite_numbers() -> None:
    config = config_from_dict({"global": {"read_timeout_seconds": float("inf")}})

    with pytest.raises(ConfigValidationError) as exc_info:
        validate_config(config)

    assert "global.read_timeout_seconds must be finite" in str(exc_info.value)


def test_dns_records_are_normalized_case_insensitively() -> None:
    config = config_from_dict({"services": {"dns": {"records": {"Update.Example.Test.": "127.0.0.1"}}}})

    assert config.dns.records == {"update.example.test": "127.0.0.1"}


def test_dns_record_normalization_rejects_duplicates() -> None:
    with pytest.raises(ConfigValidationError) as exc_info:
        config_from_dict({"services": {"dns": {"records": {"Update.Example.Test": "127.0.0.1", "update.example.test.": "127.0.0.2"}}}})

    assert "services.dns.records contains duplicate hostname after normalization: update.example.test" in str(exc_info.value)


def test_dns_record_hostnames_must_be_valid_dns_names() -> None:
    config = config_from_dict(
        {
            "services": {
                "dns": {
                    "records": {
                        f"{'a' * 64}.example.test": "127.0.0.1",
                        "bad..example.test": "127.0.0.1",
                        "caf\u00e9.example.test": "127.0.0.1",
                        "bad label.example.test": "127.0.0.1",
                        "-bad.example.test": "127.0.0.1",
                        "bad-.example.test": "127.0.0.1",
                    }
                }
            }
        }
    )

    with pytest.raises(ConfigValidationError) as exc_info:
        validate_config(config)

    message = str(exc_info.value)
    assert f"services.dns.records contains invalid hostname '{'a' * 64}.example.test'" in message
    assert "services.dns.records contains invalid hostname 'bad..example.test'" in message
    assert "services.dns.records contains invalid hostname 'caf\u00e9.example.test'" in message
    assert "services.dns.records contains invalid hostname 'bad label.example.test'" in message
    assert "services.dns.records contains invalid hostname '-bad.example.test'" in message
    assert "services.dns.records contains invalid hostname 'bad-.example.test'" in message


def test_dns_srv_records_validate_owner_and_value() -> None:
    config = config_from_dict(
        {
            "services": {
                "dns": {
                    "srv_records": {
                        "_https._tcp.example.test": "0 5 443 web.example.test",
                        "_bad._tcp.example.test": "priority weight port bad target",
                        "_bad2._tcp.example.test": "0 0 99999 web.example.test",
                        "_bad3._tcp.example.test": "0 0 443 bad target",
                    }
                }
            }
        }
    )

    with pytest.raises(ConfigValidationError) as exc_info:
        validate_config(config)

    message = str(exc_info.value)
    assert "services.dns.srv_records._bad._tcp.example.test must be either" in message
    assert "services.dns.srv_records._bad2._tcp.example.test priority, weight, and port must fit uint16" in message
    assert "services.dns.srv_records._bad3._tcp.example.test must be either" in message


def test_fake_download_extensions_are_normalized_to_lowercase() -> None:
    config = config_from_dict({"services": {"http": {"fake_download_extensions": {".EXE": "windows_executable"}}}})

    assert config.http.fake_download_extensions == {".exe": "windows_executable"}


def test_fake_download_extension_normalization_rejects_duplicates() -> None:
    with pytest.raises(ConfigValidationError) as exc_info:
        config_from_dict({"services": {"http": {"fake_download_extensions": {".EXE": "windows_executable", ".exe": "text"}}}})

    assert "services.http.fake_download_extensions contains duplicate extension after normalization: .exe" in str(exc_info.value)


def test_mitmproxy_allow_upstream_hosts_must_be_valid_patterns() -> None:
    config = config_from_dict(
        {
            "services": {
                "mitmproxy": {
                    "allow_upstream_hosts": [
                        "updates.example.test",
                        "*.vendor.test",
                        "*",
                        "bad label.example.test",
                        "*.bad..example.test",
                        "-bad.example.test",
                    ]
                }
            }
        }
    )

    with pytest.raises(ConfigValidationError) as exc_info:
        validate_config(config)

    message = str(exc_info.value)
    assert "services.mitmproxy.allow_upstream_hosts[3] contains invalid host pattern 'bad label.example.test'" in message
    assert "services.mitmproxy.allow_upstream_hosts[4] contains invalid host pattern '*.bad..example.test'" in message
    assert "services.mitmproxy.allow_upstream_hosts[5] contains invalid host pattern '-bad.example.test'" in message


def test_config_rejects_unvalidated_text_field_types() -> None:
    config = config_from_dict(
        {
            "services": {
                "http": {"default_body": 123},
                "pop3": {"message_body": 456},
                "smb": {"server_name": "FILE01\r\nInjected", "workgroup": 789},
            }
        }
    )

    with pytest.raises(ConfigValidationError) as exc_info:
        validate_config(config)

    message = str(exc_info.value)
    assert "services.http.default_body must be a string" in message
    assert "services.pop3.message_body must be a string" in message
    assert "services.smb.server_name must not contain CR or LF characters" in message
    assert "services.smb.workgroup must not be empty" in message


def test_tcp_banner_ports_reject_non_integer_python_keys() -> None:
    with pytest.raises(ConfigValidationError) as exc_info:
        config_from_dict({"services": {"tcp_banners": {"ports": {True: "SSH\r\n", 1.5: "FTP\r\n"}}}})

    message = str(exc_info.value)
    assert "services.tcp_banners.ports contains non-integer port True" in message
    assert "services.tcp_banners.ports contains non-integer port 1.5" in message


def test_config_rejects_bad_scalar_types_cleanly() -> None:
    config = config_from_dict({"global": {"listen_host": 123, "allowed_clients": [123]}})
    with pytest.raises(ConfigValidationError) as exc_info:
        validate_config(config)
    message = str(exc_info.value)
    assert "global.listen_host" in message
    assert "global.allowed_clients[0] must be a string network" in message

    with pytest.raises(ConfigValidationError) as exc_info:
        config_from_dict({"global": {"log_dir": 123, "artifact_dir": 456}})
    message = str(exc_info.value)
    assert "global.log_dir must be a string path" in message
    assert "global.artifact_dir must be a string path" in message

    config = config_from_dict({"services": {"mitmproxy": {"mode": 123, "executable": 456}}})
    with pytest.raises(ConfigValidationError) as exc_info:
        validate_config(config)
    message = str(exc_info.value)
    assert "services.mitmproxy.mode" in message
    assert "services.mitmproxy.executable" in message


def test_fake_download_extension_kinds_must_be_supported_strings() -> None:
    config = config_from_dict({"services": {"http": {"fake_download_extensions": {".bin": 5, ".bad": "unknown"}}}})

    with pytest.raises(ConfigValidationError) as exc_info:
        validate_config(config)

    message = str(exc_info.value)
    assert "services.http.fake_download_extensions..bin has an empty kind" in message
    assert "services.http.fake_download_extensions..bad has unsupported kind 'unknown'" in message


def test_https_cert_paths_must_be_paired_when_auto_generation_is_disabled() -> None:
    config = config_from_dict({"services": {"https": {"auto_generate_cert": False, "cert_file": "cert.pem"}}})

    with pytest.raises(ConfigValidationError) as exc_info:
        validate_config(config)

    message = str(exc_info.value)
    assert "services.https.cert_file and services.https.key_file must be configured together" in message
    assert "services.https requires cert_file and key_file when auto_generate_cert is false" in message


def test_https_cert_common_name_must_be_dns_hostname() -> None:
    config = config_from_dict({"services": {"https": {"cert_common_name": "bad host name"}}})

    with pytest.raises(ConfigValidationError) as exc_info:
        validate_config(config)

    assert "services.https.cert_common_name must be a valid DNS hostname" in str(exc_info.value)


def test_check_config_returns_nonzero_for_invalid_config(tmp_path, capsys) -> None:
    path = tmp_path / "bad.toml"
    path.write_text(
        """
[global]
allowed_clients = ["not-a-network"]
""",
        encoding="utf-8",
    )

    assert main(["--config", str(path), "check-config"]) == 2
    captured = capsys.readouterr()
    assert "configuration is invalid" in captured.err
    assert "global.allowed_clients" in captured.err


def test_http_route_keys_must_be_path_only() -> None:
    config = config_from_dict({"services": {"http": {"routes": {"/status?check=1": "ok\n"}, "route_statuses": {"/bad?x=1": 204}}}})

    with pytest.raises(ConfigValidationError) as exc_info:
        validate_config(config)

    message = str(exc_info.value)
    assert "services.http.routes./status?check=1" in message
    assert "services.http.route_statuses./bad?x=1" in message


def test_http_route_statuses_must_be_valid_status_codes() -> None:
    config = config_from_dict({"services": {"http": {"route_statuses": {"/generate_204": 99}}}})

    with pytest.raises(ConfigValidationError) as exc_info:
        validate_config(config)

    assert "services.http.route_statuses./generate_204 must be an HTTP status code from 100 to 599" in str(exc_info.value)


def test_unknown_config_key_is_validation_error() -> None:
    with pytest.raises(ConfigValidationError) as exc_info:
        config_from_dict({"services": {"http": {"porrt": 80}}})

    assert "unknown config key services.http.porrt" in str(exc_info.value)


def test_check_config_returns_nonzero_for_unknown_config_key(tmp_path, capsys) -> None:
    path = tmp_path / "bad.toml"
    path.write_text(
        """
[services.http]
porrt = 80
""",
        encoding="utf-8",
    )

    assert main(["--config", str(path), "check-config"]) == 2
    captured = capsys.readouterr()
    assert "configuration is invalid" in captured.err
    assert "unknown config key services.http.porrt" in captured.err


def test_check_config_can_override_network_from_interface(monkeypatch, capsys) -> None:
    monkeypatch.setattr("inetsim_py.cli.detect_interface_network", lambda interface: InterfaceNetwork(interface, "10.10.20.5", "10.10.20.0/24"))

    assert main(["--interface", "eth1", "check-config"]) == 0

    captured = capsys.readouterr()
    assert "listen_host=10.10.20.5" in captured.out
    assert "allowed_clients=10.10.20.0/24" in captured.out
    assert "sinkhole_ip=10.10.20.5" in captured.out


def test_detect_interface_network_parses_ip_json(monkeypatch) -> None:
    class Result:
        returncode = 0
        stderr = ""
        stdout = '[{"ifname":"eth1","addr_info":[{"family":"inet","local":"10.10.20.5","prefixlen":24}]}]'

    monkeypatch.setattr("inetsim_py.cli.subprocess.run", lambda *args, **kwargs: Result())

    network = detect_interface_network("eth1")

    assert network == InterfaceNetwork("eth1", "10.10.20.5", "10.10.20.0/24")


def test_interface_detection_error_returns_nonzero(monkeypatch, capsys) -> None:
    def fail(interface: str) -> InterfaceNetwork:
        raise InterfaceDetectionError(f"interface {interface!r} has no IPv4 address")

    monkeypatch.setattr("inetsim_py.cli.detect_interface_network", fail)

    assert main(["--interface", "eth1", "check-config"]) == 2

    captured = capsys.readouterr()
    assert "interface detection failed" in captured.err
    assert "eth1" in captured.err


def test_interface_run_warns_when_default_ports_wont_catch_browser_traffic(monkeypatch, capsys) -> None:
    async def fake_run(config, dns_override=None, *args) -> int:
        return 0

    monkeypatch.setattr("inetsim_py.cli.detect_interface_network", lambda interface: InterfaceNetwork(interface, "10.10.20.5", "10.10.20.0/24"))
    monkeypatch.setattr("inetsim_py.cli._run", fake_run)

    assert main(["--interface", "eth1", "run"]) == 0

    captured = capsys.readouterr()
    assert "not using standard lab ports" in captured.err
    assert "https=18443" in captured.err
    assert "configs/lab-subnet.toml" in captured.err


def test_interface_port_warning_ignores_disabled_https(capsys) -> None:
    config = config_from_dict(
        {
            "services": {
                "dns": {"udp_port": 53, "tcp_port": 53},
                "http": {"port": 80},
                "https": {"enabled": False},
            }
        }
    )

    cli._warn_interface_lab_ports(config)

    assert capsys.readouterr().err == ""


def test_manage_dns_requires_interface(capsys) -> None:
    assert main(["--manage-dns", "run"]) == 2

    captured = capsys.readouterr()
    assert "--manage-dns requires --interface" in captured.err


def test_restore_dns_requires_interface(capsys) -> None:
    assert main(["restore-dns"]) == 2

    captured = capsys.readouterr()
    assert "restore-dns requires --interface" in captured.err


def test_restore_dns_command_reverts_and_reports_networkmanager_refresh(monkeypatch, capsys) -> None:
    calls = []

    class FakeOverride:
        def __init__(self, interface_name: str, dns_server: str) -> None:
            self.interface_name = interface_name
            self.dns_server = dns_server

        def revert(self) -> bool:
            calls.append(("revert", self.interface_name, self.dns_server))
            return True

    monkeypatch.setattr("inetsim_py.cli.detect_interface_network", lambda interface: InterfaceNetwork(interface, "10.10.20.5", "10.10.20.0/24"))
    monkeypatch.setattr("inetsim_py.cli.ResolvedDnsOverride", FakeOverride)

    assert main(["--interface", "eth1", "restore-dns"]) == 0

    assert calls == [("revert", "eth1", "10.10.20.5")]
    captured = capsys.readouterr()
    assert "managed dns: reverted eth1" in captured.err
    assert "managed dns: refreshed NetworkManager settings for eth1" in captured.err


def test_resolved_dns_revert_refreshes_networkmanager_when_available(monkeypatch) -> None:
    calls = []

    monkeypatch.setattr("inetsim_py.cli._run_resolvectl", lambda args: calls.append(("resolvectl", tuple(args))))
    monkeypatch.setattr("inetsim_py.cli._reapply_network_manager_device", lambda interface: calls.append(("nmcli", interface)) or True)

    assert cli.ResolvedDnsOverride("wlan0", "10.10.20.5").revert() is True

    assert calls == [
        ("resolvectl", ("revert", "wlan0")),
        ("resolvectl", ("flush-caches",)),
        ("nmcli", "wlan0"),
        ("resolvectl", ("flush-caches",)),
    ]


def test_trust_mitm_ca_requires_enabled_mitmproxy(capsys) -> None:
    assert main(["--trust-mitm-ca", "run"]) == 2

    captured = capsys.readouterr()
    assert "--trust-mitm-ca requires services.mitmproxy.enabled = true" in captured.err


def test_trust_https_ca_requires_enabled_https(capsys, tmp_path) -> None:
    config_path = tmp_path / "no-https.toml"
    config_path.write_text("[services.https]\nenabled = false\n", encoding="utf-8")

    assert main(["--config", str(config_path), "--trust-https-ca", "run"]) == 2

    captured = capsys.readouterr()
    assert "--trust-https-ca requires services.https.enabled = true" in captured.err


def test_trust_https_ca_rejects_custom_certificate_config(capsys, tmp_path) -> None:
    config_path = tmp_path / "custom-https.toml"
    config_path.write_text("[services.https]\ncert_file = \"cert.pem\"\nkey_file = \"key.pem\"\n", encoding="utf-8")

    assert main(["--config", str(config_path), "--trust-https-ca", "run"]) == 2

    captured = capsys.readouterr()
    assert "requires auto-generated HTTPS certificates" in captured.err


def test_transparent_proxy_rules_apply_and_revert(monkeypatch) -> None:
    calls = []
    monkeypatch.setattr(cli.shutil, "which", lambda command: f"/usr/sbin/{command}")
    monkeypatch.setattr(cli.subprocess, "run", lambda command, **kwargs: calls.append(tuple(command)) or type("Result", (), {"returncode": 0, "stderr": "", "stdout": ""})())

    override = cli.TransparentProxyOverride(80, 443, 443)
    override.apply()
    override.revert()

    assert any("--dport" in call and "80" in call for call in calls)
    assert any("--dport" in call and "443" in call for call in calls)
    assert any("-A" in call for call in calls)
    assert any("-D" in call for call in calls)


def test_transparent_router_rules_use_forwarding_chains(monkeypatch) -> None:
    calls = []
    monkeypatch.setattr(cli.shutil, "which", lambda command: f"/usr/sbin/{command}")
    monkeypatch.setattr(cli.subprocess, "run", lambda command, **kwargs: calls.append(tuple(command)) or type("Result", (), {"returncode": 0, "stderr": "", "stdout": ""})())

    override = cli.TransparentProxyOverride(80, 443, 443, router_mode=True)
    override.apply()
    override.revert()

    assert any("-t" in call and "nat" in call and "PREROUTING" in call and "-A" in call for call in calls)
    assert any("-t" in call and "nat" in call and "PREROUTING" in call and "-A" in call and "udp" in call and "REDIRECT" in call for call in calls)
    assert any("-t" in call and "nat" in call and "PREROUTING" in call and "-D" in call for call in calls)
    assert any("-t" in call and "nat" in call and "PREROUTING" in call and "-D" in call and "udp" in call and "REDIRECT" in call for call in calls)


def test_transparent_rules_include_interface_and_source_matches(monkeypatch) -> None:
    calls = []
    monkeypatch.setattr(cli.shutil, "which", lambda command: f"/usr/sbin/{command}")
    monkeypatch.setattr(cli.subprocess, "run", lambda command, **kwargs: calls.append(tuple(command)) or type("Result", (), {"returncode": 0, "stderr": "", "stdout": ""})())

    override = cli.TransparentProxyOverride(80, 443, 443, router_mode=True, interface_name="eth1", source_cidrs=("10.10.20.0/24",))
    override.apply()
    override.revert()

    add_calls = [call for call in calls if "-A" in call]
    delete_calls = [call for call in calls if "-D" in call]
    assert add_calls
    assert all("-i" in call and "eth1" in call for call in add_calls)
    assert all("-s" in call and "10.10.20.0/24" in call for call in add_calls)
    assert all("-i" in call and "eth1" in call for call in delete_calls)
    assert all("-s" in call and "10.10.20.0/24" in call for call in delete_calls)


def test_transparent_local_rules_use_output_interface_match(monkeypatch) -> None:
    calls = []
    monkeypatch.setattr(cli.shutil, "which", lambda command: f"/usr/sbin/{command}")
    monkeypatch.setattr(cli.subprocess, "run", lambda command, **kwargs: calls.append(tuple(command)) or type("Result", (), {"returncode": 0, "stderr": "", "stdout": ""})())

    cli.TransparentProxyOverride(80, 443, interface_name="eth0").apply()

    assert calls
    assert all("-o" in call and "eth0" in call for call in calls)


def test_restore_transparent_router_removes_router_rules(monkeypatch, tmp_path) -> None:
    calls = []
    config_path = tmp_path / "router.toml"
    config_path.write_text("[services.http]\nport = 80\n[services.https]\nport = 443\n[services.quic]\nenabled = true\nport = 443\n", encoding="utf-8")
    monkeypatch.setattr(cli.shutil, "which", lambda command: f"/usr/sbin/{command}")
    monkeypatch.setattr(cli.subprocess, "run", lambda command, **kwargs: calls.append(tuple(command)) or type("Result", (), {"returncode": 0, "stderr": "", "stdout": ""})())

    assert main(["--config", str(config_path), "--transparent-router", "restore-transparent"]) == 0

    assert any("-t" in call and "nat" in call and "PREROUTING" in call and "-D" in call for call in calls)
    assert any("-t" in call and "nat" in call and "PREROUTING" in call and "-D" in call and "udp" in call and "REDIRECT" in call for call in calls)


def test_transparent_router_defaults_sources_to_allowed_ipv4_clients() -> None:
    config = config_from_dict({"global": {"allowed_clients": ["10.10.20.0/24", "::1/128"]}})

    assert cli._transparent_source_cidrs([], config, router_mode=True) == ("10.10.20.0/24",)


def test_transparent_source_rejects_ipv6(capsys, tmp_path) -> None:
    config_path = tmp_path / "router.toml"
    config_path.write_text("[services.http]\nport = 80\n[services.https]\nport = 443\n", encoding="utf-8")

    assert main(["--config", str(config_path), "--transparent-router", "--transparent-source", "::1/128", "run"]) == 2

    assert "only supports IPv4" in capsys.readouterr().err


def test_transparent_proxy_apply_rolls_back_partial_rules(monkeypatch) -> None:
    calls = []
    monkeypatch.setattr(cli.shutil, "which", lambda command: f"/usr/sbin/{command}")

    def fake_run(command, **kwargs):
        calls.append(tuple(command))
        if "-A" in command and "--dport" in command and "443" in command:
            return type("Result", (), {"returncode": 1, "stderr": "failed", "stdout": ""})()
        return type("Result", (), {"returncode": 0, "stderr": "", "stdout": ""})()

    monkeypatch.setattr(cli.subprocess, "run", fake_run)

    with pytest.raises(cli.TransparentProxyError):
        cli.TransparentProxyOverride(80, 443).apply()

    assert any("-D" in call and "80" in call for call in calls)


def test_transparent_proxy_rejects_regular_mitmproxy(monkeypatch, capsys, tmp_path) -> None:
    config_path = tmp_path / "mitm.toml"
    config_path.write_text("[services.mitmproxy]\nenabled = true\nmode = \"regular\"\n", encoding="utf-8")
    monkeypatch.setattr("inetsim_py.cli.detect_interface_network", lambda interface: InterfaceNetwork(interface, "10.10.20.5", "10.10.20.0/24"))

    assert main(["--config", str(config_path), "--transparent-proxy", "run"]) == 2

    assert "requires services.mitmproxy.mode" in capsys.readouterr().err


def test_mitm_ca_trust_override_installs_and_removes(monkeypatch, tmp_path) -> None:
    updates = []
    source_ca = tmp_path / "mitmproxy-ca-cert.pem"
    trust_ca = tmp_path / "trust" / "inetsim-py-mitmproxy.crt"
    source_ca.write_text("lab ca\n", encoding="utf-8")

    monkeypatch.setattr(cli.shutil, "which", lambda command: f"/usr/sbin/{command}")
    monkeypatch.setattr(cli, "_run_trust_update", lambda command: updates.append(command))

    override = cli.MitmCaTrustOverride(source_ca, trust_ca)

    asyncio.run(override.apply())
    assert trust_ca.read_text(encoding="utf-8") == "lab ca\n"

    override.revert()
    assert not trust_ca.exists()
    assert updates == ["/usr/sbin/update-ca-certificates", "/usr/sbin/update-ca-certificates"]


def test_mitm_ca_trust_override_restores_existing_file(monkeypatch, tmp_path) -> None:
    source_ca = tmp_path / "mitmproxy-ca-cert.pem"
    trust_ca = tmp_path / "trust" / "inetsim-py-mitmproxy.crt"
    source_ca.write_text("new ca\n", encoding="utf-8")
    trust_ca.parent.mkdir()
    trust_ca.write_text("old ca\n", encoding="utf-8")

    monkeypatch.setattr(cli.shutil, "which", lambda command: f"/usr/sbin/{command}")
    monkeypatch.setattr(cli, "_run_trust_update", lambda command: None)

    override = cli.MitmCaTrustOverride(source_ca, trust_ca)

    asyncio.run(override.apply())
    assert trust_ca.read_text(encoding="utf-8") == "new ca\n"

    override.revert()
    assert trust_ca.read_text(encoding="utf-8") == "old ca\n"


def test_manage_dns_applies_and_reverts(monkeypatch, capsys) -> None:
    calls = []

    class FakeOverride:
        def __init__(self, interface_name: str, dns_server: str) -> None:
            self.interface_name = interface_name
            self.dns_server = dns_server

        def apply(self) -> None:
            calls.append(("apply", self.interface_name, self.dns_server))

        def revert(self) -> None:
            calls.append(("revert", self.interface_name, self.dns_server))

    async def fake_run(config, dns_override=None, *args) -> int:
        dns_override.apply()
        try:
            return 0
        finally:
            dns_override.revert()

    monkeypatch.setattr("inetsim_py.cli.detect_interface_network", lambda interface: InterfaceNetwork(interface, "10.10.20.5", "10.10.20.0/24"))
    monkeypatch.setattr("inetsim_py.cli.ResolvedDnsOverride", FakeOverride)
    monkeypatch.setattr("inetsim_py.cli._run", fake_run)

    assert main(["--interface", "eth1", "--manage-dns", "run"]) == 0

    assert calls == [("apply", "eth1", "10.10.20.5"), ("revert", "eth1", "10.10.20.5")]


def test_run_reverts_managed_dns_when_startup_fails(monkeypatch) -> None:
    calls = []

    class FakeApp:
        def __init__(self, config) -> None:
            self.config = config

        async def start(self):
            calls.append("start")
            raise RuntimeError("startup failed")

        async def stop(self) -> None:
            calls.append("stop")

    class FakeOverride:
        interface_name = "eth1"
        dns_server = "10.10.20.5"

        def apply(self) -> None:
            calls.append("apply")

        def revert(self) -> None:
            calls.append("revert")

    monkeypatch.setattr("inetsim_py.cli.InetSimPy", FakeApp)

    with pytest.raises(RuntimeError):
        asyncio.run(cli._run(config_from_dict({}), FakeOverride()))

    assert calls == ["apply", "start", "stop", "revert"]


def test_run_reverts_managed_dns_on_sigint_before_service_stop(monkeypatch, capsys) -> None:
    calls = []

    class FakeApp:
        def __init__(self, config) -> None:
            self.config = config

        async def start(self):
            calls.append("start")
            asyncio.get_running_loop().call_soon(signal.raise_signal, signal.SIGINT)
            return []

        async def stop(self) -> None:
            calls.append("stop")

    class FakeOverride:
        interface_name = "eth1"
        dns_server = "10.10.20.5"

        def apply(self) -> None:
            calls.append("apply")

        def revert(self) -> None:
            calls.append("revert")

    monkeypatch.setattr("inetsim_py.cli.InetSimPy", FakeApp)

    assert asyncio.run(cli._run(config_from_dict({}), FakeOverride())) == 0

    assert calls == ["apply", "start", "revert", "stop"]
    captured = capsys.readouterr()
    assert "=== INetSim-Py" in captured.err
    assert "Services       :" in captured.err
    assert "runtime        simulation services ready" in captured.err
    assert "received SIGINT; shutting down" in captured.err
    assert "managed dns: reverted eth1" in captured.err


def test_cleanup_runtime_caches_removes_project_pycache(monkeypatch, tmp_path) -> None:
    project_root = tmp_path / "project"
    cache_dirs = [
        project_root / "__pycache__",
        project_root / "src" / "pkg" / "__pycache__",
        project_root / "tests" / "__pycache__",
        project_root / ".venv" / "lib" / "__pycache__",
    ]
    for cache_dir in cache_dirs:
        cache_dir.mkdir(parents=True)

    monkeypatch.setattr(cli, "__file__", str(project_root / "src" / "inetsim_py" / "cli.py"))

    cli.cleanup_runtime_caches()

    assert not (project_root / "__pycache__").exists()
    assert not (project_root / "src" / "pkg" / "__pycache__").exists()
    assert not (project_root / "tests" / "__pycache__").exists()
    assert (project_root / ".venv" / "lib" / "__pycache__").exists()


def test_doctor_returns_zero_when_local_probes_pass(monkeypatch, capsys) -> None:
    monkeypatch.setattr("inetsim_py.cli._probe_dns", lambda host, port, query: 0)
    monkeypatch.setattr("inetsim_py.cli._probe_http", lambda host, port, host_header: 0)
    monkeypatch.setattr("inetsim_py.cli._probe_https", lambda host, port, host_header: 0)

    assert main(["doctor"]) == 0

    captured = capsys.readouterr()
    assert "doctor: local DNS, HTTP, and HTTPS probes passed" in captured.out


def test_doctor_returns_nonzero_when_probe_fails(monkeypatch, capsys) -> None:
    monkeypatch.setattr("inetsim_py.cli._probe_dns", lambda host, port, query: 1)
    monkeypatch.setattr("inetsim_py.cli._probe_http", lambda host, port, host_header: 0)
    monkeypatch.setattr("inetsim_py.cli._probe_https", lambda host, port, host_header: 0)

    assert main(["doctor"]) == 1

    captured = capsys.readouterr()
    assert "one or more local probes failed" in captured.out


def test_print_default_config_output_is_valid_toml(tmp_path) -> None:
    path = tmp_path / "default.toml"
    path.write_text(DEFAULT_CONFIG_TOML, encoding="utf-8")

    config = load_config(path)

    assert config.http.server_header.startswith("nginx/")
    assert config.pop3.message_body.endswith("\n")


def test_invalid_toml_is_validation_error(tmp_path) -> None:
    path = tmp_path / "bad.toml"
    path.write_text('message = "broken\n"', encoding="utf-8")

    with pytest.raises(ConfigValidationError) as exc_info:
        load_config(path)

    assert "invalid TOML" in str(exc_info.value)
