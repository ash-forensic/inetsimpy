import asyncio
import json
import socket
import struct

import pytest

from inetsim_py.acl import SubnetAcl
from inetsim_py.config import DnsConfig, GlobalConfig
from inetsim_py.logger import EventLogger
from inetsim_py.services.dns import DnsService, build_response, parse_question


def _query(name: str, qtype: int = 1, qclass: int = 1) -> bytes:
    labels = b"".join(bytes([len(part)]) + part.encode("ascii") for part in name.split("."))
    return b"\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00" + labels + b"\x00" + struct.pack("!HH", qtype, qclass)


def test_parse_dns_question() -> None:
    question = parse_question(_query("update.example.test"))

    assert question.name == "update.example.test"
    assert question.qtype == 1
    assert question.qclass == 1


def test_build_a_response() -> None:
    query = _query("update.example.test")
    question = parse_question(query)
    response = build_response(query, question, "10.10.20.5", 60)

    assert response[:2] == b"\x12\x34"
    assert response[6:8] == b"\x00\x01"
    assert response.endswith(b"\x0a\x0a\x14\x05")


def test_dns_defaults_are_loopback_safe() -> None:
    dns = DnsConfig()
    global_config = GlobalConfig()

    assert dns.udp_port == 1053
    assert global_config.listen_host == "127.0.0.1"


def test_build_nodata_response_for_known_name_has_noerror() -> None:
    query = _query("update.example.test", qtype=16)
    question = parse_question(query)
    response = build_response(query, question, None, 60, rcode=0)

    assert response[3] & 0x0F == 0
    assert response[6:8] == b"\x00\x00"


def test_wildcard_can_answer_ipv4_and_ipv6_sinkholes() -> None:
    service = DnsService(
        DnsConfig(sinkhole_ip="10.10.20.5", sinkhole_ipv4="10.10.20.5", sinkhole_ipv6="fd00::5"),
        GlobalConfig(),
        None,
        None,
    )

    _, event_a = service._build_response(_query("example.test", qtype=1), "127.0.0.1", "udp")
    response_aaaa, event_aaaa = service._build_response(_query("example.test", qtype=28), "127.0.0.1", "udp")

    assert event_a["answer"] == "10.10.20.5"
    assert event_aaaa["answer"] == "fd00::5"
    assert response_aaaa[6:8] == b"\x00\x01"


def test_dns_can_answer_txt_mx_cname_ns_and_srv_records() -> None:
    config = DnsConfig(
        txt_records={"example.test": "v=spf1 -all"},
        mx_records={"example.test": "mail.example.test"},
        cname_records={"www.example.test": "example.test"},
        ns_records={"example.test": "ns1.example.test"},
        srv_records={"_https._tcp.example.test": "0 5 443 web.example.test"},
    )
    service = DnsService(config, GlobalConfig(), None, None)

    for name, qtype, expected in [
        ("example.test", 16, b"v=spf1 -all"),
        ("example.test", 15, b"\x04mail\x07example\x04test\x00"),
        ("www.example.test", 5, b"\x07example\x04test\x00"),
        ("example.test", 2, b"\x03ns1\x07example\x04test\x00"),
        ("_https._tcp.example.test", 33, b"\x01\xbb\x03web\x07example\x04test\x00"),
    ]:
        response, event = service._build_response(_query(name, qtype=qtype), "127.0.0.1", "udp")
        assert response[6:8] == b"\x00\x01"
        assert expected in response
        assert event["answer"]


def test_non_in_dns_class_does_not_get_sinkhole_answer() -> None:
    service = DnsService(DnsConfig(records={"update.example.test": "10.10.20.5"}), GlobalConfig(), None, None)

    response, event = service._build_response(_query("update.example.test", qclass=3), "127.0.0.1", "udp")

    assert event["qclass"] == 3
    assert event["answer"] == ""
    assert response[3] & 0x0F == 0
    assert response[6:8] == b"\x00\x00"


def test_parse_compressed_dns_question() -> None:
    query = b"\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\xc0\x12\x00\x01\x00\x01" + b"\x06update\x07example\x04test\x00"
    question = parse_question(query)

    assert question.name == "update.example.test"
    assert question.qtype == 1


def test_parse_rejects_overlong_dns_label() -> None:
    query = b"\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00" + bytes([64]) + (b"a" * 64) + b"\x00\x00\x01\x00\x01"

    with pytest.raises(ValueError, match="invalid DNS label"):
        parse_question(query)


def test_parse_rejects_non_ascii_dns_label_bytes() -> None:
    query = b"\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x01\xff\x00\x00\x01\x00\x01"

    with pytest.raises(ValueError, match="non-ASCII"):
        parse_question(query)


def test_parse_rejects_overlong_dns_name() -> None:
    labels = b"".join(bytes([63]) + (b"a" * 63) for _ in range(4))
    query = b"\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00" + labels + b"\x00\x00\x01\x00\x01"

    with pytest.raises(ValueError, match="255 octets"):
        parse_question(query)


def test_compressed_question_response_rebuilds_uncompressed_question() -> None:
    query = b"\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\xc0\x12\x00\x01\x00\x01" + b"\x06update\x07example\x04test\x00"
    question = parse_question(query)
    response = build_response(query, question, "10.10.20.5", 60, rcode=0)

    assert b"\x06update\x07example\x04test\x00\x00\x01\x00\x01" in response
    assert b"\xc0\x12" not in response[12 : question.question_end]


def test_dns_tcp_rejects_frame_larger_than_global_body_limit(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts", max_body_bytes=4)
        service = DnsService(DnsConfig(udp_port=0, tcp_port=0), global_config, EventLogger(global_config.log_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        writer.write(struct.pack("!H", 5))
        await writer.drain()
        assert await reader.read(16) == b""
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()

    asyncio.run(run())
    event = json.loads((tmp_path / "logs" / "dns.jsonl").read_text().splitlines()[-1])
    assert event["transport"] == "tcp"
    assert event["error"] == "ValueError"


@pytest.mark.parametrize("pipelined", [False, True])
def test_dns_tcp_supports_multiple_queries_on_one_connection(tmp_path, pipelined) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = DnsService(DnsConfig(udp_port=0, tcp_port=0), global_config, EventLogger(global_config.log_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        queries = [_query("one.nonexistent.invalid"), b"\x56\x78" + _query("two.nonexistent.invalid")[2:]]
        frames = [struct.pack("!H", len(query)) + query for query in queries]
        try:
            if pipelined:
                writer.write(b"".join(frames))
                await writer.drain()
            for query, frame in zip(queries, frames):
                if not pipelined:
                    writer.write(frame)
                    await writer.drain()
                size = struct.unpack("!H", await asyncio.wait_for(reader.readexactly(2), 2))[0]
                response = await asyncio.wait_for(reader.readexactly(size), 2)
                assert response[:2] == query[:2]
                assert response[3] & 15 == 0
                assert response[6:8] == b"\x00\x01"
                assert response.endswith(socket.inet_aton("127.0.0.1"))
            writer.close()
            await writer.wait_closed()
            await asyncio.sleep(0)
        finally:
            writer.close()
            running.close()
            await running.wait_closed()

    asyncio.run(run())
    events = [json.loads(line) for line in (tmp_path / "logs/dns.jsonl").read_text().splitlines()]
    assert [event["query"] for event in events] == ["one.nonexistent.invalid", "two.nonexistent.invalid"]
    assert not any("error" in event for event in events)


def test_dns_tcp_limits_queries_per_connection(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts", max_command_count=2)
        service = DnsService(DnsConfig(udp_port=0, tcp_port=0), global_config, EventLogger(global_config.log_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        query = _query("limited.invalid")
        try:
            writer.write((struct.pack("!H", len(query)) + query) * 2)
            await writer.drain()
            for _ in range(2):
                size = struct.unpack("!H", await asyncio.wait_for(reader.readexactly(2), 2))[0]
                await reader.readexactly(size)
            assert await asyncio.wait_for(reader.read(1), 2) == b""
        finally:
            writer.close()
            await writer.wait_closed()
            running.close()
            await running.wait_closed()

    asyncio.run(run())


def test_dns_failed_tcp_bind_releases_udp_port(tmp_path) -> None:
    async def run() -> None:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
            probe.bind(("127.0.0.1", 0))
            udp_port = probe.getsockname()[1]
        blocker = await asyncio.start_server(lambda reader, writer: writer.close(), "127.0.0.1", 0)
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = DnsService(DnsConfig(udp_port=udp_port, tcp_port=blocker.sockets[0].getsockname()[1]), global_config, EventLogger(global_config.log_dir), SubnetAcl(global_config.allowed_clients))
        try:
            with pytest.raises(OSError):
                await service.start()
            await asyncio.sleep(0)
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
                probe.bind(("127.0.0.1", udp_port))
        finally:
            blocker.close()
            await blocker.wait_closed()

    asyncio.run(run())
