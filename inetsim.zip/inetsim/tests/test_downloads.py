import importlib.util
import json
from hashlib import sha256
from pathlib import Path
import platform
import shutil
import struct
import subprocess
import sys

import pytest

from inetsim_py.config import ConfigValidationError, HttpConfig, config_from_dict, validate_config
from inetsim_py.downloads import BINARY_TEMPLATES, binary_template
from inetsim_py.services.http import fake_download_body, select_http_payload


@pytest.mark.parametrize("kind,machine,magic,dll", [
    ("windows_executable", 0x14c, 0x10b, False), ("windows_dll", 0x14c, 0x10b, True),
    ("windows_executable_x64", 0x8664, 0x20b, False), ("windows_dll_x64", 0x8664, 0x20b, True),
])
def test_pe_has_mapped_entry_point_and_correct_architecture(kind, machine, magic, dll):
    body = fake_download_body("/stage.exe", kind)[0]
    pe = struct.unpack_from("<I", body, 0x3c)[0]
    assert body[pe:pe+4] == b"PE\0\0"
    got_machine, sections = struct.unpack_from("<HH", body, pe+4)
    optional_size, characteristics = struct.unpack_from("<HH", body, pe+20)
    assert got_machine == machine and bool(characteristics & 0x2000) == dll
    assert struct.unpack_from("<H", body, pe+24)[0] == magic
    entry = struct.unpack_from("<I", body, pe+40)[0]
    section_table = pe + 24 + optional_size
    mapped = []
    for i in range(sections):
        offset = section_table + i * 40
        size, address, raw_size, raw_offset = struct.unpack_from("<IIII", body, offset+8)
        flags = struct.unpack_from("<I", body, offset+36)[0]
        if address <= entry < address + size:
            assert flags & 0x20000000  # IMAGE_SCN_MEM_EXECUTE
            assert entry - address < raw_size and raw_offset + raw_size <= len(body)
            mapped.append(entry)
    assert mapped


def test_packaged_binaries_match_manifest():
    data = Path(__file__).parents[1] / "src/inetsim_py/data/downloads"
    manifest = json.loads((data / "manifest.json").read_text())
    for kind, name in BINARY_TEMPLATES.items():
        assert sha256(binary_template(kind)).hexdigest() == manifest["binaries"][name]


@pytest.mark.parametrize("extension,runtime", [("sh", "sh"), ("py", sys.executable), ("js", "node"), ("ps1", "pwsh")])
def test_script_download_executes_and_filename_cannot_inject_code(tmp_path, extension, runtime):
    if not shutil.which(runtime):
        pytest.skip(f"{runtime} unavailable")
    # A URL-decoded filename must not introduce an interpreter statement.
    body = fake_download_body(f"/stage\nraise Exception('injected').{extension}", "script")[0]
    assert b"injected" not in body
    path = tmp_path / ("stage." + extension)
    path.write_bytes(body)
    command = [runtime, "-NoProfile", "-NonInteractive", "-File", str(path)] if extension == "ps1" else [runtime, str(path)]
    result = subprocess.run(command, capture_output=True, timeout=20)
    assert result.returncode == 0, result.stderr


@pytest.mark.skipif(not sys.platform.startswith("linux") or platform.machine() != "x86_64", reason="Linux x86-64 only")
def test_linux_download_executes_without_dynamic_libraries(tmp_path):
    path = tmp_path / "stage.elf"
    path.write_bytes(fake_download_body("/stage.elf", "linux_executable")[0])
    path.chmod(0o700)
    assert subprocess.run([str(path)], timeout=5).returncode == 0


def test_extensionless_download_routes_and_explicit_script_kind():
    config = HttpConfig(fake_download_routes={"/stage": "python_script"})
    payload = select_http_payload(config, "http://unregistered.invalid/%73tage?token=abc")
    assert payload.response_kind == "fake_download:python_script"
    assert payload.body == fake_download_body("/stage.py", "script")[0]
    config.routes["/stage"] = "custom response"
    assert select_http_payload(config, "/stage").body == b"custom response"
    del config.routes["/stage"]
    config.fake_downloads_enabled = False
    assert select_http_payload(config, "/stage").response_kind == "default"


@pytest.mark.parametrize("mapping", [{"stage": "script"}, {"/stage?x=1": "script"}, {"/stage": "unknown"}, {"/stage": 2}])
def test_download_routes_reject_invalid_config(mapping):
    with pytest.raises(ConfigValidationError):
        validate_config(config_from_dict({"services": {"http": {"fake_download_routes": mapping}}}))


def test_raw_return_stub_requires_explicit_mapping():
    assert select_http_payload(HttpConfig(), "/stage.bin").response_kind == "default"
    config = HttpConfig(fake_download_routes={"/stage": "shellcode_x64"})
    assert select_http_payload(config, "/stage").body == b"\x31\xc0\xc3"


def test_download_validator_refuses_altered_executable():
    spec = importlib.util.spec_from_file_location("download_validator", Path(__file__).parents[1] / "scripts/validate-downloads.py")
    validator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(validator)
    body = fake_download_body("/stage.exe", "windows_executable")[0]
    validator.verified_body(body, body)
    with pytest.raises(ValueError, match="execution refused"):
        validator.verified_body(body + b"untrusted", body)
