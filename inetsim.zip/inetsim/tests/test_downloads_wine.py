"""Opt-in execution checks using Wine and MinGW, in a disposable Wine prefix."""
import os
from pathlib import Path
import shutil
import subprocess

import pytest

from inetsim_py.services.http import fake_download_body

pytestmark = pytest.mark.skipif(
    os.environ.get("INETSIM_RUN_WINDOWS_DOWNLOAD_INTEGRATION") != "1" or not shutil.which("wine"),
    reason="set INETSIM_RUN_WINDOWS_DOWNLOAD_INTEGRATION=1 with Wine/MinGW installed",
)


@pytest.fixture(scope="module")
def wine_environment(tmp_path_factory):
    env = dict(os.environ, WINEPREFIX=str(tmp_path_factory.mktemp("wine-prefix")),
               WINEDLLOVERRIDES="mscoree,mshtml,winemenubuilder.exe=", WINEDEBUG="-all")
    result = subprocess.run(["wineboot", "-u"], env=env, capture_output=True, timeout=60)
    assert result.returncode == 0, result.stderr
    try:
        yield env
    finally:
        subprocess.run(["wineserver", "-k"], env=env, capture_output=True, timeout=10)


@pytest.mark.parametrize("arch", ["x86", "x64"])
def test_windows_executable_runs_under_wine(tmp_path, wine_environment, arch):
    kind = "windows_executable" if arch == "x86" else "windows_executable_x64"
    path = tmp_path / "stage.exe"
    path.write_bytes(fake_download_body("/stage.exe", kind)[0])
    result = subprocess.run(["wine", str(path)], env=wine_environment, capture_output=True, timeout=30)
    assert result.returncode == 0, result.stderr


@pytest.mark.parametrize("arch", ["x86", "x64"])
def test_windows_dll_loads_and_exports_return_under_wine(tmp_path, wine_environment, arch):
    compiler = "i686-w64-mingw32-gcc" if arch == "x86" else "x86_64-w64-mingw32-gcc"
    if not shutil.which(compiler):
        pytest.skip(f"{compiler} missing")
    checker = tmp_path / "verify.exe"
    source = Path(__file__).parent / "fixtures/verify-download-dll.c"
    subprocess.run([compiler, "-Os", "-s", str(source), "-o", str(checker)], check=True, timeout=30)
    path = tmp_path / "stage.dll"
    kind = "windows_dll" if arch == "x86" else "windows_dll_x64"
    path.write_bytes(fake_download_body("/stage.dll", kind)[0])
    windows_path = "Z:" + str(path).replace("/", "\\")
    result = subprocess.run(["wine", str(checker), windows_path], env=wine_environment, capture_output=True, timeout=30)
    assert result.returncode == 0, result.stderr


@pytest.mark.parametrize("extension", ["js", "vbs", "cmd", "bat"])
def test_windows_script_executes_under_wine(tmp_path, wine_environment, extension):
    path = tmp_path / ("stage." + extension)
    path.write_bytes(fake_download_body("/stage." + extension, "script")[0])
    windows_path = "Z:" + str(path).replace("/", "\\")
    command = ["wine", "cscript.exe", "//nologo", windows_path] if extension in {"js", "vbs"} else ["wine", "cmd.exe", "/d", "/c", windows_path]
    result = subprocess.run(command, env=wine_environment, capture_output=True, timeout=30)
    assert result.returncode == 0, result.stderr
