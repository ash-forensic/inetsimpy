import asyncio
import ftplib
import io
import socket
import ssl
import time

import pytest

from inetsim_py.acl import SubnetAcl
from inetsim_py.artifacts import ArtifactStore
from inetsim_py.config import FtpConfig, GlobalConfig
from inetsim_py.logger import EventLogger
from inetsim_py.services.ftp import FtpService


@pytest.mark.parametrize("protected", [False, True])
def test_ftp_preserves_fragmented_upload_and_supports_protected_data(tmp_path, protected) -> None:
    async def run() -> None:
        config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = FtpService(FtpConfig(port=0), config, EventLogger(config.log_dir), ArtifactStore(config.artifact_dir), SubnetAcl(config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]

        def transfer() -> None:
            if protected:
                context = ssl.create_default_context()
                context.check_hostname = False
                context.verify_mode = ssl.CERT_NONE
                client = ftplib.FTP_TLS(context=context, timeout=5)
            else:
                client = ftplib.FTP(timeout=5)
            with client:
                client.connect(config.listen_host, port)
                client.login("analyst", "guest")
                if protected:
                    client.prot_p()
                payload = b"0123456789abcdef" * 4096
                client.storbinary("STOR /chunked.bin", io.BytesIO(payload), blocksize=1024, callback=lambda chunk: time.sleep(.001))
                received = bytearray()
                client.retrbinary("RETR /chunked.bin", received.extend)
                assert received == payload
                listing = []
                client.retrlines("LIST", listing.append)
                assert any("chunked.bin" in line for line in listing)

        try:
            await asyncio.to_thread(transfer)
        finally:
            running.close()
            await running.wait_closed()

    asyncio.run(run())


def test_ftp_passive_connection_requires_control_client_address(tmp_path) -> None:
    async def run() -> None:
        config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = FtpService(FtpConfig(port=0), config, EventLogger(config.log_dir), ArtifactStore(config.artifact_dir), SubnetAcl(config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]

        def transfer() -> None:
            with ftplib.FTP(timeout=5) as client:
                client.connect(config.listen_host, port)
                client.login("analyst", "guest")
                host, data_port = ftplib.parse227(client.sendcmd("PASV"))
                with socket.create_connection((host, data_port), timeout=1, source_address=("127.0.0.2", 0)) as wrong_client:
                    assert wrong_client.recv(1024) == b""
                received = bytearray()
                client.retrbinary("RETR /README.txt", received.extend)
                assert received

        try:
            await asyncio.to_thread(transfer)
        finally:
            running.close()
            await running.wait_closed()

    asyncio.run(run())
