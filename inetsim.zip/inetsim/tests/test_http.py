import zipfile
from io import BytesIO
import struct

from inetsim_py.config import DnsConfig, HttpConfig, config_from_dict
from inetsim_py.services.http import _response, select_http_payload


def test_absolute_evil_exe_request_gets_fake_pe_download() -> None:
    payload = select_http_payload(HttpConfig(), "http://evil.com/evil.exe")

    assert payload.normalized_path == "/evil.exe"
    assert payload.download_name == "evil.exe"
    assert payload.response_kind == "fake_download:windows_executable"
    assert payload.content_type == "application/vnd.microsoft.portable-executable"
    assert payload.body.startswith(b"MZ")
    assert b"PE\x00\x00" in payload.body
    assert b"File: evil.exe" in payload.body
    assert b"placeholder" not in payload.body.lower()
    assert b"generated" not in payload.body.lower()
    assert b"inetsim" not in payload.body.lower()


def test_default_root_serves_neutral_enterprise_login() -> None:
    payload = select_http_payload(HttpConfig(), "/")

    assert payload.response_kind == "enterprise_login"
    assert payload.content_type == "text/html; charset=utf-8"
    assert b"Enterprise sign in" in payload.body
    assert b"Contoso" in payload.body
    assert b"<nav>" in payload.body
    assert b"<footer>Secure access portal</footer>" in payload.body
    assert b'placeholder="name@company.com"' in payload.body
    assert b'placeholder="Password"' in payload.body
    assert b"<svg aria-hidden=\"true\"" in payload.body
    assert b"Microsoft" not in payload.body
    assert b"inetsim" not in payload.body.lower()


def test_configured_route_overrides_fake_download_generation() -> None:
    config = HttpConfig(routes={"/payload.exe": "configured\n"})

    payload = select_http_payload(config, "/payload.exe")

    assert payload.response_kind == "configured_route"
    assert payload.download_name == ""
    assert payload.body == b"configured\n"


def test_configured_route_can_override_status() -> None:
    config = HttpConfig(routes={"/generate_204": ""}, route_statuses={"/generate_204": 204})

    payload = select_http_payload(config, "/generate_204")

    assert payload.status == 204
    assert payload.response_kind == "configured_route"
    assert payload.body == b""


def test_fake_zip_download_is_valid_zip() -> None:
    payload = select_http_payload(HttpConfig(), "/archive.zip")

    with zipfile.ZipFile(BytesIO(payload.body)) as archive:
        assert archive.namelist() == ["manifest.txt"]
        manifest = archive.read("manifest.txt")
        assert b"archive.zip" in manifest
        assert b"placeholder" not in manifest.lower()
        assert b"generated" not in manifest.lower()


def test_fake_pdf_escapes_filename_for_pdf_string() -> None:
    payload = select_http_payload(HttpConfig(), "/report%28q4%29final.pdf")

    assert payload.response_kind == "fake_download:pdf"
    assert b"Document: report\\(q4\\)final.pdf" in payload.body


def test_fake_download_extensions_parse_from_config() -> None:
    config = config_from_dict(
        {
            "services": {
                "http": {
                    "fake_downloads_enabled": True,
                    "fake_download_extensions": {".bin": "text"},
                }
            }
        }
    )

    payload = select_http_payload(config.http, "/sample.bin")

    assert payload.response_kind == "fake_download:text"
    assert payload.body.startswith(b"File: sample.bin")
    assert b"placeholder" not in payload.body.lower()
    assert b"generated" not in payload.body.lower()


def test_download_name_strips_header_injection_characters() -> None:
    payload = select_http_payload(HttpConfig(), "/evil%0d%0aX-Bad:%201.exe")

    assert "\r" not in payload.download_name
    assert "\n" not in payload.download_name
    assert payload.download_name == "evilX-Bad: 1.exe"


def test_non_ascii_download_name_does_not_break_content_disposition() -> None:
    response = _response(200, "OK", "nginx/1.24.0", b"MZ", "application/octet-stream", "caf\u00e9.exe")

    assert b'Content-Disposition: attachment; filename="caf.exe"' in response


def test_http_rejects_oversized_request_body(tmp_path) -> None:
    import asyncio

    from inetsim_py.acl import SubnetAcl
    from inetsim_py.artifacts import ArtifactStore
    from inetsim_py.config import GlobalConfig
    from inetsim_py.logger import EventLogger
    from inetsim_py.services.http import HttpService

    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts", max_body_bytes=4)
        service = HttpService(HttpConfig(port=0), global_config, EventLogger(global_config.log_dir), ArtifactStore(global_config.artifact_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        writer.write(b"POST /upload HTTP/1.1\r\nHost: local\r\nContent-Length: 5\r\n\r\n")
        await writer.drain()
        response = await reader.read(1024)
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()
        return response

    assert b"413 Payload Too Large" in asyncio.run(run())


def test_http_returns_400_for_malformed_request_line(tmp_path) -> None:
    import asyncio

    from inetsim_py.acl import SubnetAcl
    from inetsim_py.artifacts import ArtifactStore
    from inetsim_py.config import GlobalConfig
    from inetsim_py.logger import EventLogger
    from inetsim_py.services.http import HttpService

    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = HttpService(HttpConfig(port=0), global_config, EventLogger(global_config.log_dir), ArtifactStore(global_config.artifact_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        writer.write(b"GET\r\nHost: local\r\n\r\n")
        await writer.drain()
        response = await reader.read(1024)
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()
        return response

    assert b"400 Bad Request" in asyncio.run(run())


def test_http_accepts_repeated_spaces_in_request_line(tmp_path) -> None:
    import asyncio

    from inetsim_py.acl import SubnetAcl
    from inetsim_py.artifacts import ArtifactStore
    from inetsim_py.config import GlobalConfig
    from inetsim_py.logger import EventLogger
    from inetsim_py.services.http import HttpService

    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = HttpService(HttpConfig(port=0), global_config, EventLogger(global_config.log_dir), ArtifactStore(global_config.artifact_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        writer.write(b"GET   /   HTTP/1.1\r\nHost: local\r\n\r\n")
        await writer.drain()
        response = await reader.read(1024)
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()
        return response

    assert b"200 OK" in asyncio.run(run())


def test_http_default_server_header_is_nginx(tmp_path) -> None:
    import asyncio

    from inetsim_py.acl import SubnetAcl
    from inetsim_py.artifacts import ArtifactStore
    from inetsim_py.config import GlobalConfig
    from inetsim_py.logger import EventLogger
    from inetsim_py.services.http import HttpService

    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = HttpService(HttpConfig(port=0), global_config, EventLogger(global_config.log_dir), ArtifactStore(global_config.artifact_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        writer.write(b"GET / HTTP/1.1\r\nHost: local\r\n\r\n")
        await writer.drain()
        response = await reader.read(4096)
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()
        return response

    response = asyncio.run(run())
    assert b"Server: nginx/1.24.0" in response
    assert b"Enterprise sign in" in response


def test_http_head_returns_headers_without_body(tmp_path) -> None:
    import asyncio

    from inetsim_py.acl import SubnetAcl
    from inetsim_py.artifacts import ArtifactStore
    from inetsim_py.config import GlobalConfig
    from inetsim_py.logger import EventLogger
    from inetsim_py.services.http import HttpService

    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = HttpService(HttpConfig(port=0), global_config, EventLogger(global_config.log_dir), ArtifactStore(global_config.artifact_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        writer.write(b"HEAD / HTTP/1.1\r\nHost: local\r\n\r\n")
        await writer.drain()
        response = await reader.read(4096)
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()
        return response

    response = asyncio.run(run())
    headers, _, body = response.partition(b"\r\n\r\n")
    assert b"200 OK" in headers
    assert b"Content-Length: " in headers
    assert body == b""


def test_http_keep_alive_serves_multiple_requests(tmp_path) -> None:
    import asyncio

    from inetsim_py.acl import SubnetAcl
    from inetsim_py.artifacts import ArtifactStore
    from inetsim_py.config import GlobalConfig
    from inetsim_py.logger import EventLogger
    from inetsim_py.services.http import HttpService

    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = HttpService(HttpConfig(port=0), global_config, EventLogger(global_config.log_dir), ArtifactStore(global_config.artifact_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        writer.write(b"GET /ncsi.txt HTTP/1.1\r\nHost: local\r\n\r\nGET /generate_204 HTTP/1.1\r\nHost: local\r\nConnection: close\r\n\r\n")
        await writer.drain()
        response = await reader.read()
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()
        return response

    response = asyncio.run(run())
    assert response.count(b"HTTP/1.1") == 2
    assert b"200 OK" in response
    assert b"204 No Content" in response


def test_http_dns_over_https_post(tmp_path) -> None:
    import asyncio

    from inetsim_py.acl import SubnetAcl
    from inetsim_py.artifacts import ArtifactStore
    from inetsim_py.config import GlobalConfig
    from inetsim_py.logger import EventLogger
    from inetsim_py.services.http import HttpService

    query = b"\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00" + b"\x07example\x04test\x00" + struct.pack("!HH", 1, 1)

    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = HttpService(
            HttpConfig(port=0),
            global_config,
            EventLogger(global_config.log_dir),
            ArtifactStore(global_config.artifact_dir),
            SubnetAcl(global_config.allowed_clients),
            DnsConfig(sinkhole_ip="127.0.0.1"),
        )
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        writer.write(b"POST /dns-query HTTP/1.1\r\nHost: local\r\nContent-Type: application/dns-message\r\nContent-Length: " + str(len(query)).encode("ascii") + b"\r\nConnection: close\r\n\r\n" + query)
        await writer.drain()
        response = await reader.read(4096)
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()
        return response

    response = asyncio.run(run())
    assert b"Content-Type: application/dns-message" in response
    assert b"\x7f\x00\x00\x01" in response


def test_http_dns_over_https_get_url_decodes_query(tmp_path) -> None:
    import asyncio
    import base64

    from inetsim_py.acl import SubnetAcl
    from inetsim_py.artifacts import ArtifactStore
    from inetsim_py.config import GlobalConfig
    from inetsim_py.logger import EventLogger
    from inetsim_py.services.http import HttpService

    query = b"\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00" + b"\x07example\x04test\x00" + struct.pack("!HH", 1, 1)
    encoded = base64.urlsafe_b64encode(query).decode("ascii").replace("=", "%3D")

    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = HttpService(
            HttpConfig(port=0),
            global_config,
            EventLogger(global_config.log_dir),
            ArtifactStore(global_config.artifact_dir),
            SubnetAcl(global_config.allowed_clients),
            DnsConfig(sinkhole_ip="127.0.0.1"),
        )
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        writer.write(f"GET /dns-query?dns={encoded} HTTP/1.1\r\nHost: local\r\nConnection: close\r\n\r\n".encode("ascii"))
        await writer.drain()
        response = await reader.read(4096)
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()
        return response

    response = asyncio.run(run())
    assert b"Content-Type: application/dns-message" in response
    assert b"\x7f\x00\x00\x01" in response


def test_http_dns_over_https_rejects_wrong_post_content_type(tmp_path) -> None:
    import asyncio

    from inetsim_py.acl import SubnetAcl
    from inetsim_py.artifacts import ArtifactStore
    from inetsim_py.config import GlobalConfig
    from inetsim_py.logger import EventLogger
    from inetsim_py.services.http import HttpService

    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = HttpService(
            HttpConfig(port=0),
            global_config,
            EventLogger(global_config.log_dir),
            ArtifactStore(global_config.artifact_dir),
            SubnetAcl(global_config.allowed_clients),
            DnsConfig(sinkhole_ip="127.0.0.1"),
        )
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        writer.write(b"POST /dns-query HTTP/1.1\r\nHost: local\r\nContent-Type: text/plain\r\nContent-Length: 3\r\nConnection: close\r\n\r\nabc")
        await writer.drain()
        response = await reader.read(4096)
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()
        return response

    response = asyncio.run(run())
    assert b"415 Unsupported Media Type" in response
    assert b"Content-Type: text/plain; charset=utf-8" in response


def test_http_dns_over_https_rejects_bad_get_query(tmp_path) -> None:
    import asyncio

    from inetsim_py.acl import SubnetAcl
    from inetsim_py.artifacts import ArtifactStore
    from inetsim_py.config import GlobalConfig
    from inetsim_py.logger import EventLogger
    from inetsim_py.services.http import HttpService

    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = HttpService(
            HttpConfig(port=0),
            global_config,
            EventLogger(global_config.log_dir),
            ArtifactStore(global_config.artifact_dir),
            SubnetAcl(global_config.allowed_clients),
            DnsConfig(sinkhole_ip="127.0.0.1"),
        )
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        writer.write(b"GET /dns-query?dns=%%% HTTP/1.1\r\nHost: local\r\nConnection: close\r\n\r\n")
        await writer.drain()
        response = await reader.read(4096)
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()
        return response

    response = asyncio.run(run())
    assert b"400 Bad Request" in response
