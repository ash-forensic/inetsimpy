import asyncio
import json
import shutil
import ssl
from hashlib import sha256

import pytest

from inetsim_py.acl import SubnetAcl
from inetsim_py.artifacts import ArtifactStore
from inetsim_py.config import GlobalConfig, HttpConfig, HttpsConfig
from inetsim_py.logger import EventLogger
from inetsim_py.services.https import HttpsService


@pytest.mark.skipif(shutil.which("openssl") is None, reason="openssl is required for generated HTTPS test certificate")
def test_https_serves_fake_download_and_logs_sni(tmp_path) -> None:
    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        http_config = HttpConfig()
        service = HttpsService(
            HttpsConfig(port=0, cert_common_name="example.test"),
            http_config,
            global_config,
            EventLogger(global_config.log_dir),
            ArtifactStore(global_config.artifact_dir),
            SubnetAcl(global_config.allowed_clients),
        )
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        try:
            reader, writer = await asyncio.open_connection(global_config.listen_host, port, ssl=context, server_hostname="evil.test")
            writer.write(b"GET /evil.exe HTTP/1.1\r\nHost: evil.test\r\nConnection: close\r\n\r\n")
            await writer.drain()
            response = await reader.read(4096)
            writer.close()
            await writer.wait_closed()
            return response
        finally:
            running.close()
            await running.wait_closed()

    response = asyncio.run(run())

    assert b"HTTP/1.1 200 OK" in response
    assert b"Server: nginx/1.24.0" in response
    assert b"MZ" in response

    event = json.loads((tmp_path / "logs" / "https.jsonl").read_text().splitlines()[-1])
    assert event["sni"] == "evil.test"
    assert event["host"] == "evil.test"
    assert event["response_kind"] == "fake_download:windows_executable"
    assert event["response_sha256"] == sha256(response.split(b"\r\n\r\n", 1)[1]).hexdigest()
    assert event["tls"] is True


@pytest.mark.skipif(shutil.which("openssl") is None, reason="openssl is required for generated HTTPS test certificate")
def test_https_dynamic_sni_certificate_validates_with_lab_ca(tmp_path) -> None:
    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = HttpsService(
            HttpsConfig(port=0, cert_common_name="inetsim.local", prewarm_hosts=["evil.test"]),
            HttpConfig(),
            global_config,
            EventLogger(global_config.log_dir),
            ArtifactStore(global_config.artifact_dir),
            SubnetAcl(global_config.allowed_clients),
        )
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        context = ssl.create_default_context(cafile=str(global_config.artifact_dir / "tls" / "inetsim-ca.crt"))
        try:
            reader, writer = await asyncio.open_connection(global_config.listen_host, port, ssl=context, server_hostname="evil.test")
            writer.write(b"GET / HTTP/1.1\r\nHost: evil.test\r\nConnection: close\r\n\r\n")
            await writer.drain()
            response = await reader.read(4096)
            writer.close()
            await writer.wait_closed()
            return response
        finally:
            running.close()
            await running.wait_closed()

    response = asyncio.run(run())

    assert b"HTTP/1.1 200 OK" in response
    assert b"Enterprise sign in" in response


@pytest.mark.skipif(shutil.which("openssl") is None, reason="openssl is required for generated HTTPS test certificate")
def test_https_unknown_sni_can_block_and_validate_first_handshake(tmp_path) -> None:
    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = HttpsService(
            HttpsConfig(port=0, cert_common_name="inetsim.local", block_on_unknown_sni=True),
            HttpConfig(),
            global_config,
            EventLogger(global_config.log_dir),
            ArtifactStore(global_config.artifact_dir),
            SubnetAcl(global_config.allowed_clients),
        )
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        context = ssl.create_default_context(cafile=str(global_config.artifact_dir / "tls" / "inetsim-ca.crt"))
        try:
            reader, writer = await asyncio.open_connection(global_config.listen_host, port, ssl=context, server_hostname="first-seen.test")
            writer.write(b"GET / HTTP/1.1\r\nHost: first-seen.test\r\nConnection: close\r\n\r\n")
            await writer.drain()
            response = await reader.read(4096)
            writer.close()
            await writer.wait_closed()
            return response
        finally:
            running.close()
            await running.wait_closed()

    response = asyncio.run(run())

    assert b"HTTP/1.1 200 OK" in response
    assert b"Enterprise sign in" in response
