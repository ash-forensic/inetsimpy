import pytest

from inetsim_py.logger import EventLogger


def test_event_logger_rejects_non_directory_log_root(tmp_path) -> None:
    path = tmp_path / "logs"
    path.write_text("", encoding="utf-8")

    with pytest.raises(OSError):
        EventLogger(path)
