import asyncio
import os
import shutil
import socket
import sys

import pytest

import inetsim_py.mitm_addon as mitm_addon
from inetsim_py.config import AppConfig, config_from_dict
from inetsim_py.mitm_addon import client_allowed, client_ip, fake_download_kind, headers_dict, host_allowed, server_header
from inetsim_py.services.mitmproxy import MitmProxyService, _startup_notes


def test_mitmproxy_defaults_are_disabled_and_blocking() -> None:
    config = AppConfig()

    assert not config.mitmproxy.enabled
    assert config.mitmproxy.port == 18088
    assert config.mitmproxy.block_upstream
    assert config.mitmproxy.allow_upstream_hosts == []


def test_mitmproxy_config_parses_allowlist() -> None:
    config = config_from_dict(
        {
            "services": {
                "mitmproxy": {
                    "enabled": True,
                    "port": 8080,
                    "block_upstream": True,
                    "allow_upstream_hosts": ["updates.example.test", "*.vendor.test"],
                }
            }
        }
    )

    assert config.mitmproxy.enabled
    assert config.mitmproxy.port == 8080
    assert config.mitmproxy.allow_upstream_hosts == ["updates.example.test", "*.vendor.test"]


def test_mitmproxy_host_allowlist_supports_exact_and_wildcard() -> None:
    patterns = ["updates.example.test", "*.vendor.test"]

    assert host_allowed("updates.example.test", patterns)
    assert host_allowed("cdn.vendor.test", patterns)
    assert not host_allowed("evil.test", patterns)
    assert not host_allowed("123", [123])


def test_mitmproxy_fake_download_kind_uses_extension_map() -> None:
    config = {"fake_download_extensions": {".exe": "windows_executable"}}

    assert fake_download_kind(config, "/evil.exe?x=1") == "windows_executable"
    assert fake_download_kind(config, "/index.html") == ""
    assert fake_download_kind({"fake_download_extensions": []}, "/evil.exe") == ""
    assert fake_download_kind({"fake_download_extensions": {".exe": "unsupported"}}, "/evil.exe") == ""
    assert fake_download_kind({"fake_download_extensions": {".exe": 123}}, "/evil.exe") == ""


def test_mitmproxy_extensionless_download_routes_and_text_route_precedence(monkeypatch, tmp_path) -> None:
    from hashlib import sha256
    import json
    config = _addon_config(tmp_path)
    config["fake_download_routes"] = {"/stage": "python_script"}
    monkeypatch.setattr(mitm_addon, "http", _FakeHttp)
    monkeypatch.setattr(mitm_addon, "_CONFIG", config)
    flow = _Flow("http://example.test/%73tage?session=abc")
    mitm_addon.request(flow)
    assert flow.response.raw_content == b"#!/usr/bin/env python3\n# Stage completed.\nraise SystemExit(0)\n"
    event = json.loads((tmp_path / "logs/mitmproxy.jsonl").read_text().splitlines()[-1])
    assert event["response_sha256"] == sha256(flow.response.raw_content).hexdigest()
    config["routes"] = {"/stage": "custom text"}
    flow = _Flow("http://example.test/stage")
    mitm_addon.request(flow)
    assert flow.response.raw_content == b"custom text"


def test_mitmproxy_defensive_runtime_config_helpers(tmp_path) -> None:
    assert not host_allowed("example.test", "*.example.test")
    assert mitm_addon.response_status({"synthetic_status": "not-a-status"}, "synthetic_status", 200) == 200
    assert mitm_addon.response_status({"synthetic_status": 99}, "synthetic_status", 200) == 200
    assert mitm_addon.response_status({"synthetic_status": True}, "synthetic_status", 200) == 200
    assert mitm_addon.response_status({"synthetic_status": 204}, "synthetic_status", 200) == 204
    assert mitm_addon.bool_setting({"enabled": "false"}, "enabled", True)
    assert not mitm_addon.bool_setting({"enabled": "true"}, "enabled", False)
    assert not mitm_addon.bool_setting({"enabled": False}, "enabled", True)
    assert mitm_addon.path_setting({"log_dir": []}, "log_dir", "logs").as_posix() == "logs"
    assert mitm_addon.body_capture_limit({"body_capture_limit": "bad"}) == 1048576
    assert mitm_addon.body_capture_limit({"body_capture_limit": True}) == 1048576
    assert mitm_addon.body_capture_limit({"body_capture_limit": -1}) == 0

    result = mitm_addon.save_artifact({"artifact_dir": str(tmp_path), "body_capture_limit": -1}, "mitmproxy/request", b"x")

    assert result["captured"] is False
    assert result["limit"] == 0

    with pytest.raises(ValueError, match="invalid artifact category"):
        mitm_addon.save_artifact({"artifact_dir": str(tmp_path)}, "../outside", b"x")


def test_mitmproxy_headers_dict_accepts_plain_dict() -> None:
    assert headers_dict({"User-Agent": "x"}) == {"User-Agent": "x"}


def test_mitmproxy_server_header_rejects_crlf_from_json_config() -> None:
    assert server_header({"server_header": "nginx\r\nX-Bad: yes"}) == "nginx/1.24.0"
    assert server_header({"server_header": "nginx café"}) == "nginx/1.24.0"


def test_mitmproxy_load_config_ignores_non_object_json(monkeypatch, tmp_path) -> None:
    config_path = tmp_path / "mitmproxy.json"
    config_path.write_text("[]", encoding="utf-8")
    monkeypatch.setenv("INETSIM_MITMPROXY_CONFIG", str(config_path))
    monkeypatch.setattr(mitm_addon, "_CONFIG", None)

    config = mitm_addon.load_config()

    assert config["block_upstream"] is True
    assert config["server_header"] == "nginx/1.24.0"


def test_mitmproxy_start_requires_executable_when_enabled() -> None:
    async def run() -> None:
        config = AppConfig()
        config.mitmproxy.enabled = True
        config.mitmproxy.executable = "definitely-not-a-real-mitmdump"
        service = MitmProxyService(config.mitmproxy, config.http, config.global_)
        with pytest.raises(RuntimeError, match="was not found"):
            await service.start()

    asyncio.run(run())


def test_mitmproxy_start_waits_for_delayed_listener(tmp_path) -> None:
    executable = tmp_path / "delayed-mitmdump"
    executable.write_text(
        f"#!{sys.executable}\n"
        "import socket, sys, time\n"
        "host = sys.argv[sys.argv.index('--listen-host') + 1]\n"
        "port = int(sys.argv[sys.argv.index('--listen-port') + 1])\n"
        "time.sleep(0.6)\n"
        "with socket.create_server((host, port)) as server:\n"
        "    while True:\n"
        "        client, _ = server.accept()\n"
        "        with client:\n"
        "            client.sendall(b'ready\\n')\n"
    )
    executable.chmod(0o755)

    async def run() -> None:
        config = AppConfig()
        config.global_.artifact_dir = tmp_path / "artifacts"
        config.global_.log_dir = tmp_path / "logs"
        config.mitmproxy.executable = str(executable)
        config.mitmproxy.port = _free_port()
        service = MitmProxyService(config.mitmproxy, config.http, config.global_)
        running = await service.start()
        try:
            reader, writer = await asyncio.open_connection("127.0.0.1", config.mitmproxy.port)
            assert await asyncio.wait_for(reader.readline(), 2) == b"ready\n"
            writer.close()
            await writer.wait_closed()
        finally:
            running.close()
            await running.wait_closed()

    asyncio.run(run())


def test_mitmproxy_start_reports_process_exit(tmp_path) -> None:
    executable = tmp_path / "failed-mitmdump"
    executable.write_text(f"#!{sys.executable}\nraise SystemExit(1)\n")
    executable.chmod(0o755)

    async def run() -> None:
        config = AppConfig()
        config.global_.artifact_dir = tmp_path / "artifacts"
        config.global_.log_dir = tmp_path / "logs"
        config.mitmproxy.executable = str(executable)
        config.mitmproxy.port = _free_port()
        service = MitmProxyService(config.mitmproxy, config.http, config.global_)
        with pytest.raises(RuntimeError, match="exited during startup"):
            await service.start()

    asyncio.run(run())


def test_mitmproxy_start_timeout_terminates_child(tmp_path, monkeypatch) -> None:
    executable = tmp_path / "hung-mitmdump"
    executable.write_text(f"#!{sys.executable}\nimport time\ntime.sleep(60)\n")
    executable.chmod(0o755)
    monkeypatch.setattr("inetsim_py.services.mitmproxy._STARTUP_TIMEOUT_SECONDS", 0.2)
    create_process = asyncio.create_subprocess_exec
    processes = []

    async def capture_process(*args, **kwargs):
        process = await create_process(*args, **kwargs)
        processes.append(process)
        return process

    monkeypatch.setattr(asyncio, "create_subprocess_exec", capture_process)

    async def run() -> None:
        config = AppConfig()
        config.global_.artifact_dir = tmp_path / "artifacts"
        config.global_.log_dir = tmp_path / "logs"
        config.mitmproxy.executable = str(executable)
        config.mitmproxy.port = _free_port()
        service = MitmProxyService(config.mitmproxy, config.http, config.global_)
        with pytest.raises(RuntimeError, match="did not listen"):
            await service.start()
        assert len(processes) == 1
        assert processes[0].returncode is not None

    asyncio.run(run())


def test_mitmproxy_client_acl_matches_allowed_clients() -> None:
    assert client_allowed("10.10.20.5", ["10.10.20.0/24"])
    assert client_allowed("::ffff:10.10.20.5", ["10.10.20.0/24"])
    assert not client_allowed("10.10.21.5", ["10.10.20.0/24"])
    assert not client_allowed("10.10.20.5", ["not-a-network"])
    assert not client_allowed("0.0.0.123", [123])
    assert not client_allowed("10.10.20.5", "10.10.20.0/24")


def test_mitmproxy_client_ip_supports_multiple_connection_shapes() -> None:
    class Conn:
        peername = ("10.10.20.5", 53000)

    class Flow:
        client_conn = Conn()

    assert client_ip(Flow()) == "10.10.20.5"

    class Address:
        host = "10.10.20.6"

    class ConnWithAddressObject:
        address = Address()

    class FlowWithAddressObject:
        client_conn = ConnWithAddressObject()

    assert client_ip(FlowWithAddressObject()) == "10.10.20.6"


def test_mitmproxy_addon_blocks_disallowed_client(monkeypatch, tmp_path) -> None:
    monkeypatch.setattr(mitm_addon, "http", _FakeHttp)
    monkeypatch.setattr(
        mitm_addon,
        "_CONFIG",
        _addon_config(tmp_path, allowed_clients=["10.10.20.0/24"]),
    )
    flow = _Flow("http://example.test/index.html", client_ip="192.0.2.10")

    mitm_addon.request(flow)

    assert flow.response.status_code == 403
    assert flow.response.headers["Server"] == "nginx/1.24.0"
    assert flow.response.raw_content == b"Access denied by proxy policy\n"


def test_mitmproxy_addon_synthesizes_fake_download(monkeypatch, tmp_path) -> None:
    monkeypatch.setattr(mitm_addon, "http", _FakeHttp)
    monkeypatch.setattr(mitm_addon, "_CONFIG", _addon_config(tmp_path, server_header="nginx/1.26.1"))
    flow = _Flow("http://example.test/evil.exe")

    mitm_addon.request(flow)

    assert flow.response.status_code == 200
    assert flow.response.headers["Server"] == "nginx/1.26.1"
    assert flow.response.raw_content.startswith(b"MZ")
    assert (tmp_path / "logs" / "mitmproxy.jsonl").exists()


def test_mitmproxy_synthetic_download_filename_is_ascii_safe(monkeypatch, tmp_path) -> None:
    monkeypatch.setattr(mitm_addon, "http", _FakeHttp)
    monkeypatch.setattr(mitm_addon, "_CONFIG", _addon_config(tmp_path))
    flow = _Flow("http://example.test/caf%C3%A9.exe")

    mitm_addon.request(flow)

    assert flow.response.headers["Content-Disposition"] == 'attachment; filename="caf.exe"'


def test_mitmproxy_download_matches_builtin_with_encoded_name_and_query(monkeypatch, tmp_path) -> None:
    from inetsim_py.config import HttpConfig
    from inetsim_py.services.http import select_http_payload
    monkeypatch.setattr(mitm_addon, "http", _FakeHttp)
    monkeypatch.setattr(mitm_addon, "_CONFIG", _addon_config(tmp_path))
    flow = _Flow("http://example.test/caf%C3%A9.exe?session=123")
    mitm_addon.request(flow)
    assert flow.response.raw_content == select_http_payload(HttpConfig(), flow.request.url).body


def test_mitmproxy_addon_does_not_relog_synthetic_response_as_upstream(monkeypatch, tmp_path) -> None:
    monkeypatch.setattr(mitm_addon, "http", _FakeHttp)
    monkeypatch.setattr(mitm_addon, "_CONFIG", _addon_config(tmp_path))
    flow = _Flow("http://example.test/evil.exe")

    mitm_addon.request(flow)
    mitm_addon.response(flow)

    lines = (tmp_path / "logs" / "mitmproxy.jsonl").read_text().splitlines()
    assert len(lines) == 1
    assert '"action":"synthesized"' in lines[0]
    assert "upstream_response" not in lines[0]


def test_mitmproxy_response_logs_upstream_header_that_matches_internal_marker(monkeypatch, tmp_path) -> None:
    monkeypatch.setattr(mitm_addon, "_CONFIG", _addon_config(tmp_path))
    flow = _Flow("http://example.test/index.html")
    flow.response = _FakeResponse(200, b"upstream", {"X-INetSim-Py": "upstream-header"})

    mitm_addon.response(flow)

    event = (tmp_path / "logs" / "mitmproxy.jsonl").read_text()
    assert '"action":"upstream_response"' in event
    assert '"X-INetSim-Py":"upstream-header"' in event


def test_mitmproxy_addon_blocks_unapproved_upstream(monkeypatch, tmp_path) -> None:
    monkeypatch.setattr(mitm_addon, "http", _FakeHttp)
    monkeypatch.setattr(mitm_addon, "_CONFIG", _addon_config(tmp_path, server_header="nginx/1.26.1"))
    flow = _Flow("http://example.test/index.html")

    mitm_addon.request(flow)

    assert flow.response.status_code == 200
    assert flow.response.headers["Server"] == "nginx/1.26.1"
    assert flow.response.raw_content == b"Service unavailable\n"
    event = (tmp_path / "logs" / "mitmproxy.jsonl").read_text()
    assert '"action":"synthesized_blocked"' in event
    assert '"response_kind":"default"' in event


def test_mitmproxy_addon_blocked_upstream_uses_configured_route_status(monkeypatch, tmp_path) -> None:
    monkeypatch.setattr(mitm_addon, "http", _FakeHttp)
    config = _addon_config(tmp_path)
    config["routes"] = {"/generate_204": ""}
    config["route_statuses"] = {"/generate_204": 204}
    monkeypatch.setattr(mitm_addon, "_CONFIG", config)
    flow = _Flow("http://connectivitycheck.example/generate_204")

    mitm_addon.request(flow)

    assert flow.response.status_code == 204
    assert flow.response.raw_content == b""


def test_mitmproxy_addon_runtime_json_uses_bool_defaults(monkeypatch, tmp_path) -> None:
    monkeypatch.setattr(mitm_addon, "http", _FakeHttp)
    config = _addon_config(tmp_path)
    config.update({"synthesize_downloads": "false", "block_upstream": "false"})
    monkeypatch.setattr(mitm_addon, "_CONFIG", config)
    flow = _Flow("http://example.test/evil.exe")

    mitm_addon.request(flow)

    assert flow.response.status_code == 200
    assert flow.response.raw_content.startswith(b"MZ")


def test_mitmproxy_addon_allows_approved_upstream(monkeypatch, tmp_path) -> None:
    monkeypatch.setattr(mitm_addon, "http", _FakeHttp)
    monkeypatch.setattr(
        mitm_addon,
        "_CONFIG",
        _addon_config(tmp_path, allow_upstream_hosts=["example.test"]),
    )
    flow = _Flow("http://example.test/index.html")

    mitm_addon.request(flow)

    assert flow.response is None
    event = (tmp_path / "logs" / "mitmproxy.jsonl").read_text()
    assert '"action":"allowed_upstream"' in event


def test_mitmproxy_managed_addon_config_includes_http_server_header() -> None:
    config = AppConfig()
    config.http.server_header = "nginx/1.26.1"

    service = MitmProxyService(config.mitmproxy, config.http, config.global_)

    assert service._addon_config()["server_header"] == "nginx/1.26.1"
    assert service._addon_config()["default_body"] == config.http.default_body
    assert service._addon_config()["routes"] == config.http.routes


def test_mitmproxy_startup_notes_include_proxy_and_ca_paths(tmp_path) -> None:
    notes = _startup_notes(tmp_path / "conf", "10.1.1.93", 8080)

    assert "10.1.1.93:8080" in notes[0]
    assert "mitmproxy-ca-cert.pem" in notes[2]
    assert "http://mitm.it" in notes[2]
    assert "pinned" in notes[3]


@pytest.mark.skipif(os.environ.get("INETSIM_RUN_MITMPROXY_INTEGRATION") != "1" or shutil.which("mitmdump") is None, reason="set INETSIM_RUN_MITMPROXY_INTEGRATION=1 and install mitmdump")
def test_mitmproxy_runtime_smoke(tmp_path) -> None:
    async def run() -> bytes:
        config = AppConfig()
        config.global_.log_dir = tmp_path / "logs"
        config.global_.artifact_dir = tmp_path / "artifacts"
        config.mitmproxy.enabled = True
        config.mitmproxy.port = _free_port()
        service = MitmProxyService(config.mitmproxy, config.http, config.global_)
        running = await service.start()
        try:
            reader, writer = await asyncio.open_connection(config.global_.listen_host, config.mitmproxy.port)
            writer.write(b"GET http://example.test/evil.exe HTTP/1.1\r\nHost: example.test\r\n\r\n")
            await writer.drain()
            response = await reader.read(4096)
            writer.close()
            await writer.wait_closed()
            return response
        finally:
            running.close()
            await running.wait_closed()

    response = asyncio.run(run())

    assert b"200 OK" in response
    assert b"Server: nginx/1.24.0" in response


def _free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def _addon_config(tmp_path, allowed_clients=None, allow_upstream_hosts=None, server_header="nginx/1.24.0"):
    return {
        "log_dir": str(tmp_path / "logs"),
        "artifact_dir": str(tmp_path / "artifacts"),
        "server_header": server_header,
        "allowed_clients": allowed_clients or ["127.0.0.1/32", "::1/128"],
        "block_upstream": True,
        "allow_upstream_hosts": allow_upstream_hosts or [],
        "synthesize_downloads": True,
        "synthetic_status": 200,
        "blocked_status": 502,
        "body_capture_limit": 1048576,
        "fake_download_extensions": {".exe": "windows_executable"},
        "default_status": 200,
        "default_body": "Service unavailable\n",
        "login_page_enabled": True,
        "login_page_path": "/",
        "login_page_brand": "Contoso",
        "login_page_title": "Enterprise sign in",
        "login_page_realm": "Work or school account",
        "routes": {},
        "route_statuses": {},
    }


class _FakeResponse:
    def __init__(self, status_code, raw_content, headers):
        self.status_code = status_code
        self.raw_content = raw_content
        self.headers = headers

    @classmethod
    def make(cls, status_code, body, headers):
        return cls(status_code, body, headers)


class _FakeHttp:
    Response = _FakeResponse


class _Flow:
    def __init__(self, url: str, client_ip: str = "127.0.0.1") -> None:
        parsed = _ParsedUrl(url)
        self.request = _Request(url, parsed)
        self.response = None
        self.metadata = {}
        self.client_conn = _ClientConn(client_ip)
        self.server_conn = _ServerConn()


class _Request:
    def __init__(self, url: str, parsed) -> None:
        self.url = url
        self.scheme = parsed.scheme
        self.host = parsed.host
        self.port = 80
        self.path = parsed.path
        self.method = "GET"
        self.http_version = "HTTP/1.1"
        self.headers = {"Host": parsed.host}
        self.raw_content = b""


class _ClientConn:
    def __init__(self, address: str) -> None:
        self.peername = (address, 50000)


class _ServerConn:
    tls_established = False


class _ParsedUrl:
    def __init__(self, url: str) -> None:
        from urllib.parse import urlsplit

        result = urlsplit(url)
        self.scheme = result.scheme
        self.host = result.hostname or ""
        self.path = result.path or "/"
