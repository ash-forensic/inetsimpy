import asyncio
from hashlib import sha256
import shutil
import subprocess

import pytest

from inetsim_py.acl import SubnetAcl
from inetsim_py.artifacts import ArtifactStore
from inetsim_py.config import ConfigValidationError, GlobalConfig, HttpConfig, config_from_dict, validate_config
from inetsim_py.logger import EventLogger
from inetsim_py.pki import LabCrl, certificate_needs_crl, openssl
from inetsim_py.services.http import HttpService
from inetsim_py.services.https import _ensure_lab_ca, _generate_signed_leaf_cert


@pytest.mark.parametrize('url', ['https://example.test/ca.crl', 'http://user:password@example.test/ca.crl',
                                'http://example.test/ca.crl?x=1', 'http://example.test/../ca.crl',
                                'http://example.test/ca.crl\nextra=value', 1, False])
def test_config_rejects_invalid_crl_url(url):
    with pytest.raises(ConfigValidationError, match='tls_crl_url'):
        validate_config(config_from_dict({'global': {'tls_crl_url': url}}))


@pytest.mark.skipif(shutil.which('openssl') is None, reason='OpenSSL required')
def test_signed_crl_preserves_revocations_and_rejects_another_ca(tmp_path):
    crl = LabCrl(tmp_path)
    _ensure_lab_ca(crl.ca, crl.key)
    cert, key = tmp_path / 'leaf.crt', tmp_path / 'leaf.key'
    _generate_signed_leaf_cert(cert, key, crl.ca, crl.key, 'example.test')
    original_key = sha256(key.read_bytes()).hexdigest()
    url = 'http://127.0.0.1/pki/lab-ca.crl'
    assert certificate_needs_crl(cert, key, url)
    _generate_signed_leaf_cert(cert, key, crl.ca, crl.key, 'example.test', url)
    assert not certificate_needs_crl(cert, key, url)
    assert sha256(key.read_bytes()).hexdigest() == original_key
    assert crl.refresh()
    assert not crl.refresh()

    pem = tmp_path / 'crl.pem'
    def verify():
        openssl('crl', '-inform', 'DER', '-in', str(crl.path), '-out', str(pem))
        return subprocess.run(['openssl', 'verify', '-CAfile', str(crl.ca), '-CRLfile', str(pem),
                               '-crl_check', str(cert)], capture_output=True, text=True)
    assert verify().returncode == 0
    crl.revoke(cert)
    rejected = verify()
    assert rejected.returncode != 0 and 'certificate revoked' in rejected.stderr
    crl.refresh(force=True)
    assert 'certificate revoked' in verify().stderr

    other = LabCrl(tmp_path / 'other')
    _ensure_lab_ca(other.ca, other.key)
    with pytest.raises(RuntimeError):
        other.revoke(cert)


@pytest.mark.skipif(shutil.which('openssl') is None, reason='OpenSSL required')
def test_http_serves_only_signed_crl_with_correct_head_and_method_handling(tmp_path):
    async def run():
        global_config = GlobalConfig(artifact_dir=tmp_path / 'artifacts', log_dir=tmp_path / 'logs',
                                     tls_crl_url='http://127.0.0.1/pki/lab-ca.crl')
        service = HttpService(HttpConfig(port=0, routes={'/pki/lab-ca.crl': 'wrong'}), global_config,
                              EventLogger(global_config.log_dir), ArtifactStore(global_config.artifact_dir),
                              SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        async def request(method, target):
            reader, writer = await asyncio.open_connection('127.0.0.1', port)
            writer.write(f'{method} {target} HTTP/1.1\r\nHost: lab.test\r\nConnection: close\r\n\r\n'.encode())
            await writer.drain()
            response = await reader.read()
            writer.close()
            await writer.wait_closed()
            return response.split(b'\r\n\r\n', 1)
        try:
            head, body = await request('GET', '/pki/lab-ca.crl')
            assert b'200 OK' in head and b'Content-Type: application/pkix-crl' in head
            assert body == LabCrl(global_config.artifact_dir).path.read_bytes()
            head, body = await request('HEAD', '/pki/lab-ca.crl')
            assert b'200 OK' in head and not body
            assert b'405' in (await request('POST', '/pki/lab-ca.crl'))[0]
            assert b'PRIVATE KEY' not in (await request('GET', '/pki/inetsim-ca.key'))[1]
        finally:
            running.close()
            await running.wait_closed()
        assert all(task.done() for task in running.tasks)
    asyncio.run(run())
