import asyncio
import json
import poplib
import ssl

from inetsim_py.acl import SubnetAcl
from inetsim_py.config import GlobalConfig, Pop3Config, config_from_dict
from inetsim_py.logger import EventLogger
from inetsim_py.services.pop3 import Pop3Service, build_message


def test_pop3_config_defaults_and_parse() -> None:
    config = config_from_dict({"services": {"pop3": {"port": 110, "hostname": "mx.test"}}})

    assert config.pop3.enabled
    assert config.pop3.port == 110
    assert config.pop3.hostname == "mx.test"


def test_pop3_message_builder_contains_placeholder_body() -> None:
    message = build_message(Pop3Config())

    assert b"Subject: Quarterly security update" in message
    assert b"Your mailbox is active" in message
    assert b"inetsim" not in message.lower()


def test_pop3_standard_client_can_discover_and_negotiate_stls(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = Pop3Service(Pop3Config(port=0), global_config, EventLogger(global_config.log_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]

        def client_flow() -> None:
            client = poplib.POP3(global_config.listen_host, port, timeout=5)
            try:
                assert "STLS" in client.capa()
                context = ssl.create_default_context()
                context.check_hostname = False
                context.verify_mode = ssl.CERT_NONE
                assert client.stls(context).startswith(b"+OK")
                assert "STLS" not in client.capa()
                client.user("analyst")
                client.pass_("guest")
                assert client.stat()[0] == 1
            finally:
                client.quit()

        try:
            await asyncio.to_thread(client_flow)
        finally:
            running.close()
            await running.wait_closed()

    asyncio.run(run())


def test_pop3_command_flow_logs_redacted_password(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        pop3_config = Pop3Config(port=0)
        service = Pop3Service(pop3_config, global_config, EventLogger(global_config.log_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        assert (await reader.readline()).startswith(b"+OK")
        for command in [b"USER analyst\r\n", b"PASS secret\r\n", b"STAT\r\n", b"UIDL 1\r\n", b"RETR 1\r\n"]:
            writer.write(command)
            await writer.drain()
            line = await reader.readline()
            assert line.startswith(b"+OK")
            if command.startswith(b"RETR"):
                while await reader.readline() != b".\r\n":
                    pass
        writer.write(b"STLS\r\n")
        await writer.drain()
        assert (await reader.readline()).startswith(b"+OK")
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        await writer.start_tls(context, server_hostname="mail.corp.local")
        writer.write(b"QUIT\r\n")
        await writer.drain()
        assert (await reader.readline()).startswith(b"+OK")
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()

    asyncio.run(run())

    event = json.loads((tmp_path / "logs" / "pop3.jsonl").read_text().splitlines()[-1])
    assert event["username"] == "analyst"
    assert "PASS <redacted>" in event["commands"]
    assert event["password_length"] == 6
    assert event["tls_requested"] is True


def test_pop3_apop_is_hashed_not_logged_raw(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = Pop3Service(Pop3Config(port=0), global_config, EventLogger(global_config.log_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        await reader.readline()
        writer.write(b"APOP user digest-secret\r\n")
        await writer.drain()
        await reader.readline()
        writer.write(b"QUIT\r\n")
        await writer.drain()
        await reader.readline()
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()

    asyncio.run(run())
    event = json.loads((tmp_path / "logs" / "pop3.jsonl").read_text().splitlines()[-1])
    assert "apop" not in event
    assert event["apop_length"] == len("user digest-secret")
    assert "APOP <redacted>" in event["commands"]


def test_pop3_pass_with_tab_separator_is_redacted(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = Pop3Service(Pop3Config(port=0), global_config, EventLogger(global_config.log_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        await reader.readline()
        writer.write(b"USER\tanalyst\r\n")
        await writer.drain()
        await reader.readline()
        writer.write(b"PASS\tsecret\r\n")
        await writer.drain()
        await reader.readline()
        writer.write(b"QUIT\r\n")
        await writer.drain()
        await reader.readline()
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()

    asyncio.run(run())
    event = json.loads((tmp_path / "logs" / "pop3.jsonl").read_text().splitlines()[-1])
    assert event["username"] == "analyst"
    assert "PASS <redacted>" in event["commands"]
    assert "secret" not in " ".join(event["commands"])
    assert event["password_length"] == 6


def test_pop3_top_accepts_tab_separated_arguments(tmp_path) -> None:
    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = Pop3Service(Pop3Config(port=0), global_config, EventLogger(global_config.log_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        await reader.readline()
        for command in [b"USER analyst\r\n", b"PASS secret\r\n"]:
            writer.write(command)
            await writer.drain()
            await reader.readline()
        writer.write(b"TOP\t1\t1\r\n")
        await writer.drain()
        response = b""
        while not response.endswith(b".\r\n"):
            response += await reader.readline()
        writer.write(b"QUIT\r\n")
        await writer.drain()
        await reader.readline()
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()
        return response

    response = asyncio.run(run())
    assert response.startswith(b"+OK top of message follows")
    assert b"Subject: Quarterly security update" in response
