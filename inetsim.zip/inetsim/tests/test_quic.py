import asyncio
import json

from inetsim_py.acl import SubnetAcl
from inetsim_py.config import GlobalConfig, QuicConfig
from inetsim_py.logger import EventLogger
from inetsim_py.services.quic import QuicService, _parse_quic_packet, _quic_block_response


def test_quic_udp_sink_logs_and_replies(tmp_path) -> None:
    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = QuicService(QuicConfig(port=0), global_config, EventLogger(global_config.log_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.transports[0].get_extra_info("sockname")[1]

        loop = asyncio.get_running_loop()
        response = loop.create_future()

        class Client(asyncio.DatagramProtocol):
            def connection_made(self, transport):
                transport.sendto(b"\xc3quic-client-hello", (global_config.listen_host, port))

            def datagram_received(self, data, addr):
                if not response.done():
                    response.set_result(data)

        transport, _ = await loop.create_datagram_endpoint(Client, local_addr=(global_config.listen_host, 0))
        try:
            data = await asyncio.wait_for(response, timeout=2)
        finally:
            transport.close()
            running.close()
            await running.wait_closed()
        return data

    data = asyncio.run(run())
    assert data.startswith(b"\x43\x00\x00\x00")
    event = json.loads((tmp_path / "logs" / "quic.jsonl").read_text().splitlines()[-1])
    assert event["long_header"] is True
    assert event["bytes"] == len(b"\xc3quic-client-hello")


def test_quic_udp_sink_can_observe_without_reply(tmp_path) -> None:
    async def run() -> bool:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = QuicService(QuicConfig(port=0, block=False), global_config, EventLogger(global_config.log_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.transports[0].get_extra_info("sockname")[1]

        loop = asyncio.get_running_loop()
        response = loop.create_future()

        class Client(asyncio.DatagramProtocol):
            def connection_made(self, transport):
                transport.sendto(b"\xc3quic-client-hello", (global_config.listen_host, port))

            def datagram_received(self, data, addr):
                if not response.done():
                    response.set_result(data)

        transport, _ = await loop.create_datagram_endpoint(Client, local_addr=(global_config.listen_host, 0))
        try:
            try:
                await asyncio.wait_for(response, timeout=0.2)
                return True
            except asyncio.TimeoutError:
                return False
        finally:
            transport.close()
            running.close()
            await running.wait_closed()

    assert asyncio.run(run()) is False


def test_quic_long_header_parser_records_connection_ids() -> None:
    packet = b"\xc3\x00\x00\x00\x01\x04dcid\x04scidpayload"

    event = _parse_quic_packet(packet)

    assert event["version"] == "0x00000001"
    assert event["fixed_bit"] is True
    assert event["dcid_length"] == 4
    assert event["scid_length"] == 4
    assert "dcid_sha256" in event
    assert "scid_sha256" in event


def test_quic_block_response_uses_version_negotiation_for_long_header() -> None:
    packet = b"\xc3\x00\x00\x00\x01\x04dcid\x04scidpayload"

    response = _quic_block_response(packet)

    assert response.startswith(b"\x80\x00\x00\x00\x00")
    assert b"scid" in response
    assert b"dcid" in response
    assert response.endswith(b"\x0a\x0a\x0a\x0a")
