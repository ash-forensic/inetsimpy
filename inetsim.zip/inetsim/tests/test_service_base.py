import asyncio

from inetsim_py.services.base import close_writer


def test_close_writer_suppresses_reset_during_wait_closed() -> None:
    class ResettingWriter:
        closed = False

        def close(self) -> None:
            self.closed = True

        async def wait_closed(self) -> None:
            raise ConnectionResetError("reset by peer")

    writer = ResettingWriter()

    asyncio.run(close_writer(writer))

    assert writer.closed is True
