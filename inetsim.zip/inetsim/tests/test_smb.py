import asyncio
import json
import struct

import pytest

from inetsim_py.acl import SubnetAcl
from inetsim_py.config import GlobalConfig, SmbConfig
from inetsim_py.logger import EventLogger
from inetsim_py.services.smb import SmbService, build_error_response, build_response, classify_smb_frame, read_netbios_session_frame, wrap_direct_tcp


def _smb2_negotiate() -> bytes:
    header = bytearray(64)
    header[0:4] = b"\xfeSMB"
    header[4:6] = (64).to_bytes(2, "little")
    header[12:14] = (0).to_bytes(2, "little")
    header[24:32] = (7).to_bytes(8, "little")
    body = bytearray(36)
    body[0:2] = (36).to_bytes(2, "little")
    body[2:4] = (3).to_bytes(2, "little")
    dialects = struct.pack("<HHH", 0x0202, 0x0302, 0x0311)
    return bytes(header + body) + dialects


def _smb2_request(command: int, message_id: int, body: bytes = b"") -> bytes:
    header = bytearray(64)
    header[0:4] = b"\xfeSMB"
    header[4:6] = (64).to_bytes(2, "little")
    header[12:14] = command.to_bytes(2, "little")
    header[24:32] = message_id.to_bytes(8, "little")
    header[36:40] = (1).to_bytes(4, "little")
    header[40:48] = (1).to_bytes(8, "little")
    return bytes(header) + body


def test_classify_smb2_negotiate_dialects() -> None:
    event = classify_smb_frame(_smb2_negotiate())

    assert event["version"] == "SMB2+"
    assert event["command_name"] == "NEGOTIATE"
    assert event["message_id"] == 7
    assert event["dialects"] == ["SMB 2.0.2", "SMB 3.0.2", "SMB 3.1.1"]


def test_smb2_negotiate_response_preserves_message_id() -> None:
    response = build_error_response(_smb2_negotiate())

    assert response.startswith(b"\xfeSMB")
    assert response[8:12] == (0).to_bytes(4, "little")
    assert response[24:32] == (7).to_bytes(8, "little")


def test_smb2_session_setup_response_is_successful() -> None:
    response = build_response(_smb2_request(1, 8, b"\x19\x00\x00\x00\x00\x00\x00\x00"))

    assert response.startswith(b"\xfeSMB")
    assert response[8:12] == (0).to_bytes(4, "little")
    assert response[12:14] == (1).to_bytes(2, "little")
    assert response[24:32] == (8).to_bytes(8, "little")
    assert response[64:66] == (9).to_bytes(2, "little")


def test_smb2_query_directory_returns_placeholder_entry() -> None:
    response = build_response(_smb2_request(14, 9, b"\x21\x00\x01\x00" + b"\x00" * 28))

    assert response.startswith(b"\xfeSMB")
    assert response[8:12] == (0).to_bytes(4, "little")
    assert response[12:14] == (14).to_bytes(2, "little")
    assert "README.txt".encode("utf-16-le") in response


def test_wrap_direct_tcp_prefixes_three_byte_size() -> None:
    wrapped = wrap_direct_tcp(b"abc")

    assert wrapped == b"\x00\x00\x00\x03abc"


def test_netbios_session_request_gets_positive_response() -> None:
    class Writer:
        def __init__(self) -> None:
            self.data = b""

        def write(self, data: bytes) -> None:
            self.data += data

        async def drain(self) -> None:
            return None

    async def run() -> tuple[bytes, bytes]:
        reader = asyncio.StreamReader()
        writer = Writer()
        frame = _smb2_negotiate()
        reader.feed_data(b"\x81\x00\x00\x02AA" + wrap_direct_tcp(frame))
        reader.feed_eof()
        result = await read_netbios_session_frame(reader, writer, 1048576, allow_session_request=True)
        return result, writer.data

    frame, response = asyncio.run(run())

    assert frame == _smb2_negotiate()
    assert response == b"\x82\x00\x00\x00"


def test_direct_smb_rejects_netbios_session_request() -> None:
    class Writer:
        def write(self, data: bytes) -> None:
            return None

        async def drain(self) -> None:
            return None

    async def run() -> None:
        reader = asyncio.StreamReader()
        reader.feed_data(b"\x81\x00\x00\x02AA" + wrap_direct_tcp(_smb2_negotiate()))
        reader.feed_eof()
        with pytest.raises(ValueError, match="direct-hosted SMB"):
            await read_netbios_session_frame(reader, Writer(), 1048576, allow_session_request=False)

    asyncio.run(run())


def test_smb_logs_configured_identity_metadata(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = SmbService(SmbConfig(port=0, netbios_port=0, server_name="FILE01", workgroup="ACME"), global_config, EventLogger(global_config.log_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        writer.write(wrap_direct_tcp(_smb2_negotiate()))
        await writer.drain()
        await reader.read(1024)
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()

    asyncio.run(run())
    event = json.loads((tmp_path / "logs" / "smb.jsonl").read_text().splitlines()[-1])
    assert event["server_name"] == "FILE01"
    assert event["workgroup"] == "ACME"


def test_smb_connection_handles_multiple_smb2_frames(tmp_path) -> None:
    async def run() -> tuple[bytes, bytes]:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts", read_timeout_seconds=0.2)
        service = SmbService(SmbConfig(port=0, netbios_port=0), global_config, EventLogger(global_config.log_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        reader, writer = await asyncio.open_connection(global_config.listen_host, port)
        writer.write(wrap_direct_tcp(_smb2_negotiate()))
        await writer.drain()
        first = await read_netbios_session_frame(reader, writer, 1048576, allow_session_request=False)
        writer.write(wrap_direct_tcp(_smb2_request(1, 8, b"\x19\x00\x00\x00\x00\x00\x00\x00")))
        await writer.drain()
        second = await read_netbios_session_frame(reader, writer, 1048576, allow_session_request=False)
        writer.close()
        await writer.wait_closed()
        running.close()
        await running.wait_closed()
        return first, second

    first, second = asyncio.run(run())

    assert first[12:14] == (0).to_bytes(2, "little")
    assert second[12:14] == (1).to_bytes(2, "little")
    event = json.loads((tmp_path / "logs" / "smb.jsonl").read_text().splitlines()[-1])
    assert len(event["frames"]) == 2
    assert event["frames"][1]["command_name"] == "SESSION_SETUP"
