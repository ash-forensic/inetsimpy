import asyncio
import errno
from types import SimpleNamespace

from inetsim_py.acl import SubnetAcl
from inetsim_py.config import GlobalConfig, TcpBannerConfig
from inetsim_py.logger import EventLogger
from inetsim_py.services.tcp_banner import TcpBannerService


def test_tcp_banner_port_22_falls_back_to_2222_when_in_use(monkeypatch, tmp_path) -> None:
    calls = []

    async def fake_start_server(handler, host, port):
        calls.append(port)
        if port == 22:
            raise OSError(errno.EADDRINUSE, "address already in use")
        return SimpleNamespace(close=lambda: None, wait_closed=_noop_wait_closed)

    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = TcpBannerService(TcpBannerConfig(ports={22: "SSH-2.0-OpenSSH_8.9\r\n"}), global_config, EventLogger(global_config.log_dir), SubnetAcl(global_config.allowed_clients))
        monkeypatch.setattr("inetsim_py.services.tcp_banner.asyncio.start_server", fake_start_server)

        running = await service.start()

        assert calls == [22, 2222]
        assert running.notes == ["tcp banner port 22 was in use; bound fallback port 2222"]
        assert service._bound_banners == {2222: "SSH-2.0-OpenSSH_8.9\r\n"}

    asyncio.run(run())


def test_tcp_banner_serves_banner_from_bound_port(tmp_path) -> None:
    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = TcpBannerService(TcpBannerConfig(ports={0: "SSH-2.0-OpenSSH_8.9\r\n"}), global_config, EventLogger(global_config.log_dir), SubnetAcl(global_config.allowed_clients))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        try:
            reader, writer = await asyncio.open_connection(global_config.listen_host, port)
            data = await reader.readline()
            writer.close()
            await writer.wait_closed()
            return data
        finally:
            running.close()
            await running.wait_closed()

    assert asyncio.run(run()) == b"SSH-2.0-OpenSSH_8.9\r\n"


async def _noop_wait_closed() -> None:
    return None
