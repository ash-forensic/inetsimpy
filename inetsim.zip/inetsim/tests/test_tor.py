import asyncio
import json
import ssl
import struct

from inetsim_py.acl import SubnetAcl
from inetsim_py.artifacts import ArtifactStore
from inetsim_py.config import GlobalConfig, HttpConfig, TorControlConfig, TorSocksConfig, config_from_dict
from inetsim_py.logger import EventLogger
from inetsim_py.services.tor import TorControlService, TorSocksService


def test_tor_config_defaults_disabled_and_lab_ports_parse() -> None:
    config = config_from_dict({"services": {"tor_socks": {"enabled": True, "port": 9050}, "tor_control": {"enabled": True, "port": 9051}}})

    assert config.tor_socks.enabled is True
    assert config.tor_socks.port == 9050
    assert config.tor_control.enabled is True
    assert config.tor_control.port == 9051


def test_tor_socks_serves_fake_http_download_and_logs_onion(tmp_path) -> None:
    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = TorSocksService(
            TorSocksConfig(port=0),
            HttpConfig(),
            global_config,
            EventLogger(global_config.log_dir),
            ArtifactStore(global_config.artifact_dir),
            SubnetAcl(global_config.allowed_clients),
        )
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        try:
            reader, writer = await asyncio.open_connection(global_config.listen_host, port)
            writer.write(b"\x05\x01\x00")
            await writer.drain()
            assert await reader.readexactly(2) == b"\x05\x00"
            host = b"exampleonionaddress.onion"
            writer.write(b"\x05\x01\x00\x03" + bytes([len(host)]) + host + struct.pack("!H", 80))
            await writer.drain()
            assert await reader.readexactly(10) == b"\x05\x00\x00\x01\x00\x00\x00\x00\x00\x00"
            writer.write(b"GET /evil.exe HTTP/1.1\r\nHost: exampleonionaddress.onion\r\nUser-Agent: sample\r\n\r\n")
            await writer.drain()
            response = await reader.read()
            writer.close()
            await writer.wait_closed()
            return response
        finally:
            running.close()
            await running.wait_closed()

    response = asyncio.run(run())

    assert b"HTTP/1.1 200 OK" in response
    assert b"Server: nginx/1.24.0" in response
    assert b"MZ" in response

    event = json.loads((tmp_path / "logs" / "tor_socks.jsonl").read_text().splitlines()[-1])
    assert event["target_host"] == "exampleonionaddress.onion"
    assert event["target_is_onion"] is True
    assert event["response_kind"] == "fake_download:windows_executable"
    assert event["user_agent"] == "sample"


def test_tor_socks_logs_binary_stream_after_connect(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = TorSocksService(
            TorSocksConfig(port=0),
            HttpConfig(),
            global_config,
            EventLogger(global_config.log_dir),
            ArtifactStore(global_config.artifact_dir),
            SubnetAcl(global_config.allowed_clients),
        )
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        try:
            reader, writer = await asyncio.open_connection(global_config.listen_host, port)
            writer.write(b"\x05\x01\x00")
            await writer.drain()
            await reader.readexactly(2)
            host = b"securehiddenservice.onion"
            writer.write(b"\x05\x01\x00\x03" + bytes([len(host)]) + host + struct.pack("!H", 9001))
            await writer.drain()
            await reader.readexactly(10)
            writer.write(b"\x16\x03\x01\x00\x2e")
            await writer.drain()
            await reader.read()
            writer.close()
            await writer.wait_closed()
        finally:
            running.close()
            await running.wait_closed()

    asyncio.run(run())

    event = json.loads((tmp_path / "logs" / "tor_socks.jsonl").read_text().splitlines()[-1])
    assert event["target_host"] == "securehiddenservice.onion"
    assert event["target_port"] == 9001
    assert event["stream_kind"] == "binary"
    assert event["initial_bytes"] >= 1


def test_tor_socks_accepts_username_password_and_redacts_credentials(tmp_path) -> None:
    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = TorSocksService(
            TorSocksConfig(port=0),
            HttpConfig(),
            global_config,
            EventLogger(global_config.log_dir),
            ArtifactStore(global_config.artifact_dir),
            SubnetAcl(global_config.allowed_clients),
        )
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        try:
            reader, writer = await asyncio.open_connection(global_config.listen_host, port)
            writer.write(b"\x05\x01\x02")
            await writer.drain()
            assert await reader.readexactly(2) == b"\x05\x02"
            writer.write(b"\x01\x07analyst\x06secret")
            await writer.drain()
            assert await reader.readexactly(2) == b"\x01\x00"
            host = b"authhiddenservice.onion"
            writer.write(b"\x05\x01\x00\x03" + bytes([len(host)]) + host + struct.pack("!H", 80))
            await writer.drain()
            assert await reader.readexactly(10) == b"\x05\x00\x00\x01\x00\x00\x00\x00\x00\x00"
            writer.write(b"GET / HTTP/1.1\r\nHost: authhiddenservice.onion\r\n\r\n")
            await writer.drain()
            response = await reader.read()
            writer.close()
            await writer.wait_closed()
            return response
        finally:
            running.close()
            await running.wait_closed()

    response = asyncio.run(run())

    assert b"HTTP/1.1 200 OK" in response
    event = json.loads((tmp_path / "logs" / "tor_socks.jsonl").read_text().splitlines()[-1])
    assert event["auth_method"] == "username_password"
    assert event["auth_username_length"] == len("analyst")
    assert event["auth_password_length"] == len("secret")
    assert "secret" not in json.dumps(event)


def test_tor_socks_prefers_no_auth_when_multiple_methods_are_offered(tmp_path) -> None:
    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = TorSocksService(
            TorSocksConfig(port=0),
            HttpConfig(),
            global_config,
            EventLogger(global_config.log_dir),
            ArtifactStore(global_config.artifact_dir),
            SubnetAcl(global_config.allowed_clients),
        )
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        try:
            reader, writer = await asyncio.open_connection(global_config.listen_host, port)
            writer.write(b"\x05\x02\x02\x00")
            await writer.drain()
            assert await reader.readexactly(2) == b"\x05\x00"
            host = b"mixedmethods.onion"
            writer.write(b"\x05\x01\x00\x03" + bytes([len(host)]) + host + struct.pack("!H", 80))
            await writer.drain()
            await reader.readexactly(10)
            writer.write(b"GET / HTTP/1.1\r\nHost: mixedmethods.onion\r\n\r\n")
            await writer.drain()
            response = await reader.read()
            writer.close()
            await writer.wait_closed()
            return response
        finally:
            running.close()
            await running.wait_closed()

    response = asyncio.run(run())

    assert b"HTTP/1.1 200 OK" in response
    event = json.loads((tmp_path / "logs" / "tor_socks.jsonl").read_text().splitlines()[-1])
    assert event["auth_method"] == "none"


def test_tor_socks4a_serves_onion_http(tmp_path) -> None:
    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = TorSocksService(
            TorSocksConfig(port=0),
            HttpConfig(),
            global_config,
            EventLogger(global_config.log_dir),
            ArtifactStore(global_config.artifact_dir),
            SubnetAcl(global_config.allowed_clients),
        )
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        try:
            reader, writer = await asyncio.open_connection(global_config.listen_host, port)
            host = b"socks4hiddenservice.onion"
            writer.write(b"\x04\x01" + struct.pack("!H", 80) + b"\x00\x00\x00\x01user\x00" + host + b"\x00")
            await writer.drain()
            assert await reader.readexactly(8) == b"\x00\x5a\x00\x50\x00\x00\x00\x00"
            writer.write(b"GET / HTTP/1.1\r\nHost: socks4hiddenservice.onion\r\n\r\n")
            await writer.drain()
            response = await reader.read()
            writer.close()
            await writer.wait_closed()
            return response
        finally:
            running.close()
            await running.wait_closed()

    response = asyncio.run(run())

    assert b"HTTP/1.1 200 OK" in response
    event = json.loads((tmp_path / "logs" / "tor_socks.jsonl").read_text().splitlines()[-1])
    assert event["socks_version"] == 4
    assert event["target_host"] == "socks4hiddenservice.onion"
    assert event["target_is_onion"] is True


def test_tor_socks4_malformed_request_gets_socks4_failure(tmp_path) -> None:
    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts", read_timeout_seconds=0.2)
        service = TorSocksService(
            TorSocksConfig(port=0),
            HttpConfig(),
            global_config,
            EventLogger(global_config.log_dir),
            ArtifactStore(global_config.artifact_dir),
            SubnetAcl(global_config.allowed_clients),
        )
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        try:
            reader, writer = await asyncio.open_connection(global_config.listen_host, port)
            writer.write(b"\x04\x01\x00\x50\x00\x00\x00\x01unterminated")
            await writer.drain()
            response = await reader.read(8)
            writer.close()
            await writer.wait_closed()
            return response
        finally:
            running.close()
            await running.wait_closed()

    response = asyncio.run(run())

    assert response == b"\x00\x5b\x00\x00\x00\x00\x00\x00"
    event = json.loads((tmp_path / "logs" / "tor_socks.jsonl").read_text().splitlines()[-1])
    assert event["error"] == "Socks4Error"


def test_tor_socks_https_onion_serves_fake_http_over_tls(tmp_path) -> None:
    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = TorSocksService(
            TorSocksConfig(port=0),
            HttpConfig(),
            global_config,
            EventLogger(global_config.log_dir),
            ArtifactStore(global_config.artifact_dir),
            SubnetAcl(global_config.allowed_clients),
        )
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        try:
            reader, writer = await asyncio.open_connection(global_config.listen_host, port)
            writer.write(b"\x05\x01\x00")
            await writer.drain()
            await reader.readexactly(2)
            host = b"securehiddenservice.onion"
            writer.write(b"\x05\x01\x00\x03" + bytes([len(host)]) + host + struct.pack("!H", 443))
            await writer.drain()
            assert await reader.readexactly(10) == b"\x05\x00\x00\x01\x00\x00\x00\x00\x00\x00"
            await writer.start_tls(context, server_hostname="securehiddenservice.onion")
            writer.write(b"GET /evil.exe HTTP/1.1\r\nHost: securehiddenservice.onion\r\n\r\n")
            await writer.drain()
            # Wait for server EOF: its session log is written before it closes.
            response = await reader.read()
            writer.close()
            await writer.wait_closed()
            return response
        finally:
            running.close()
            await running.wait_closed()

    response = asyncio.run(run())

    assert b"HTTP/1.1 200 OK" in response
    assert b"MZ" in response
    event = json.loads((tmp_path / "logs" / "tor_socks.jsonl").read_text().splitlines()[-1])
    assert event["target_port"] == 443
    assert event["stream_kind"] == "https"
    assert event["tls_established"] is True
    assert event["tls_version"].startswith("TLS")
    assert event["cipher"]
    assert event["response_kind"] == "fake_download:windows_executable"


def test_tor_socks_plain_http_on_port_443_is_still_served(tmp_path) -> None:
    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = TorSocksService(
            TorSocksConfig(port=0),
            HttpConfig(),
            global_config,
            EventLogger(global_config.log_dir),
            ArtifactStore(global_config.artifact_dir),
            SubnetAcl(global_config.allowed_clients),
        )
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        try:
            reader, writer = await asyncio.open_connection(global_config.listen_host, port)
            writer.write(b"\x05\x01\x00")
            await writer.drain()
            await reader.readexactly(2)
            host = b"plain443.onion"
            writer.write(b"\x05\x01\x00\x03" + bytes([len(host)]) + host + struct.pack("!H", 443))
            await writer.drain()
            await reader.readexactly(10)
            writer.write(b"GET / HTTP/1.1\r\nHost: plain443.onion\r\n\r\n")
            await writer.drain()
            response = await reader.read()
            writer.close()
            await writer.wait_closed()
            return response
        finally:
            running.close()
            await running.wait_closed()

    response = asyncio.run(run())

    assert b"HTTP/1.1 200 OK" in response
    event = json.loads((tmp_path / "logs" / "tor_socks.jsonl").read_text().splitlines()[-1])
    assert event["target_port"] == 443
    assert event["stream_kind"] == "http"
    assert "tls_requested" not in event


def test_tor_control_protocolinfo_auth_getinfo_and_quit(tmp_path) -> None:
    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = TorControlService(
            TorControlConfig(port=0, version="0.4.9.1"),
            TorSocksConfig(port=9050),
            global_config,
            EventLogger(global_config.log_dir),
            SubnetAcl(global_config.allowed_clients),
        )
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        try:
            reader, writer = await asyncio.open_connection(global_config.listen_host, port)
            writer.write(b"PROTOCOLINFO 1\r\n")
            await writer.drain()
            response = await _read_until_ok(reader)
            writer.write(b'AUTHENTICATE "secret"\r\n')
            await writer.drain()
            response += await reader.readline()
            writer.write(b"GETINFO version status/bootstrap-phase net/listeners/socks\r\n")
            await writer.drain()
            response += await _read_until_ok(reader)
            writer.write(b"SIGNAL NEWNYM\r\nQUIT\r\n")
            await writer.drain()
            response += await reader.readline()
            response += await reader.readline()
            writer.close()
            await writer.wait_closed()
            return response
        finally:
            running.close()
            await running.wait_closed()

    response = asyncio.run(run())

    assert b'250-VERSION Tor="0.4.9.1"' in response
    assert b"250-version=0.4.9.1" in response
    assert b"BOOTSTRAP PROGRESS=100" in response
    assert b'250-net/listeners/socks="127.0.0.1:9050"' in response

    event = json.loads((tmp_path / "logs" / "tor_control.jsonl").read_text().splitlines()[-1])
    assert "AUTHENTICATE <redacted>" in event["commands"]
    assert "SIGNAL NEWNYM" in event["commands"]


def test_tor_control_hidden_service_commands(tmp_path) -> None:
    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = TorControlService(
            TorControlConfig(port=0),
            TorSocksConfig(port=9050),
            global_config,
            EventLogger(global_config.log_dir),
            SubnetAcl(global_config.allowed_clients),
        )
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        try:
            reader, writer = await asyncio.open_connection(global_config.listen_host, port)
            writer.write(b"ADD_ONION NEW:ED25519-V3 Flags=DiscardPK Port=80,127.0.0.1:8080\r\n")
            await writer.drain()
            response = await _read_until_ok(reader)
            writer.write(b"GETINFO onions/current onions/detached\r\n")
            await writer.drain()
            response += await _read_until_ok(reader)
            writer.write(b"DEL_ONION inetsiminetsiminetsiminetsiminetsiminetsiminetsiminetsim\r\nQUIT\r\n")
            await writer.drain()
            response += await reader.readline()
            response += await reader.readline()
            writer.close()
            await writer.wait_closed()
            return response
        finally:
            running.close()
            await running.wait_closed()

    response = asyncio.run(run())

    assert b"250-ServiceID=inetsiminetsiminetsiminetsiminetsiminetsiminetsiminetsim" in response
    assert b"250-onions/current=inetsiminetsiminetsiminetsiminetsiminetsiminetsiminetsim" in response
    assert b"250-onions/detached=" in response
    assert b"250-PrivateKey" not in response
    event = json.loads((tmp_path / "logs" / "tor_control.jsonl").read_text().splitlines()[-1])
    assert "ADD_ONION <redacted>" in event["commands"]


def test_tor_control_add_onion_flags_are_case_insensitive(tmp_path) -> None:
    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = TorControlService(
            TorControlConfig(port=0),
            TorSocksConfig(port=9050),
            global_config,
            EventLogger(global_config.log_dir),
            SubnetAcl(global_config.allowed_clients),
        )
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        try:
            reader, writer = await asyncio.open_connection(global_config.listen_host, port)
            writer.write(b"ADD_ONION NEW:ED25519-V3 flags=DiscardPK Port=80,127.0.0.1:8080\r\n")
            await writer.drain()
            response = await _read_until_ok(reader)
            writer.close()
            await writer.wait_closed()
            return response
        finally:
            running.close()
            await running.wait_closed()

    response = asyncio.run(run())

    assert b"250-ServiceID=" in response
    assert b"250-PrivateKey" not in response


def test_tor_control_unknown_getinfo_returns_552(tmp_path) -> None:
    async def run() -> bytes:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = TorControlService(
            TorControlConfig(port=0),
            TorSocksConfig(port=9050),
            global_config,
            EventLogger(global_config.log_dir),
            SubnetAcl(global_config.allowed_clients),
        )
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        try:
            reader, writer = await asyncio.open_connection(global_config.listen_host, port)
            writer.write(b"GETINFO definitely/unknown\r\nQUIT\r\n")
            await writer.drain()
            response = await reader.readline()
            response += await reader.readline()
            writer.close()
            await writer.wait_closed()
            return response
        finally:
            running.close()
            await running.wait_closed()

    response = asyncio.run(run())

    assert b"552 Unrecognized key" in response


def test_tor_control_redacts_sensitive_setconf_values(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = TorControlService(
            TorControlConfig(port=0),
            TorSocksConfig(port=9050),
            global_config,
            EventLogger(global_config.log_dir),
            SubnetAcl(global_config.allowed_clients),
        )
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        try:
            reader, writer = await asyncio.open_connection(global_config.listen_host, port)
            writer.write(b"SETCONF Socks5ProxyPassword=supersecret SafeLogging=1\r\nQUIT\r\n")
            await writer.drain()
            await reader.readline()
            await reader.readline()
            writer.close()
            await writer.wait_closed()
        finally:
            running.close()
            await running.wait_closed()

    asyncio.run(run())

    event = json.loads((tmp_path / "logs" / "tor_control.jsonl").read_text().splitlines()[-1])
    assert "SETCONF <redacted>" in event["commands"]
    assert "supersecret" not in " ".join(event["commands"])


def test_tor_control_truncates_long_logged_commands(tmp_path) -> None:
    async def run() -> None:
        global_config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
        service = TorControlService(
            TorControlConfig(port=0),
            TorSocksConfig(port=9050),
            global_config,
            EventLogger(global_config.log_dir),
            SubnetAcl(global_config.allowed_clients),
        )
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        try:
            reader, writer = await asyncio.open_connection(global_config.listen_host, port)
            writer.write(b"SETCONF LongValue=" + (b"a" * 400) + b"\r\nQUIT\r\n")
            await writer.drain()
            await reader.readline()
            await reader.readline()
            writer.close()
            await writer.wait_closed()
        finally:
            running.close()
            await running.wait_closed()

    asyncio.run(run())

    event = json.loads((tmp_path / "logs" / "tor_control.jsonl").read_text().splitlines()[-1])
    assert event["commands"][0].endswith("...[truncated]")
    assert len(event["commands"][0]) < 280


async def _read_until_ok(reader: asyncio.StreamReader) -> bytes:
    data = b""
    while True:
        line = await reader.readline()
        data += line
        if line == b"250 OK\r\n":
            return data
