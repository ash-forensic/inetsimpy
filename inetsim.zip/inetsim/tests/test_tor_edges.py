import asyncio
from hashlib import sha256
import json
import socket
import ssl
import struct

import pytest

from inetsim_py.acl import SubnetAcl
from inetsim_py.artifacts import ArtifactStore
from inetsim_py.config import GlobalConfig, HttpConfig, TorSocksConfig
from inetsim_py.logger import EventLogger
from inetsim_py.services.https import _ensure_lab_ca
from inetsim_py.services.tor import TorSocksService

ONION = "25njqamcweflpvkl73j4szahhihoc4xt3ktcgjnpaingr5yhkenl5sid.onion"


def service_at(tmp_path):
    config = GlobalConfig(log_dir=tmp_path / "logs", artifact_dir=tmp_path / "artifacts")
    service = TorSocksService(TorSocksConfig(port=0), HttpConfig(), config,
                             EventLogger(config.log_dir), ArtifactStore(config.artifact_dir), SubnetAcl(config.allowed_clients))
    return config, service


def connect_frame(host, port):
    encoded = host.encode()
    return b"\x05\x01\x00\x03" + bytes([len(encoded)]) + encoded + struct.pack("!H", port)


@pytest.mark.parametrize("target_port", [80, 443])
def test_tor_optimistic_plaintext_already_buffered_after_connect(tmp_path, target_port):
    async def run():
        config, service = service_at(tmp_path)
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        try:
            reader, writer = await asyncio.open_connection(config.listen_host, port)
            writer.write(b"\x05\x01\x00")
            await writer.drain()
            assert await reader.readexactly(2) == b"\x05\x00"
            writer.write(connect_frame(ONION, target_port) + f"GET /stage.elf HTTP/1.1\r\nHost: {ONION}\r\n\r\n".encode())
            await writer.drain()
            assert (await reader.readexactly(10))[:2] == b"\x05\x00"
            response = await asyncio.wait_for(reader.read(), timeout=5)
            assert response.startswith(b"HTTP/1.1 200 OK")
            body = response.split(b"\r\n\r\n", 1)[1]
            assert body.startswith(b"\x7fELF")
            writer.close()
            await writer.wait_closed()
        finally:
            running.close()
            await running.wait_closed()
        event = json.loads((config.log_dir / "tor_socks.jsonl").read_text().splitlines()[-1])
        assert event["response_sha256"] == sha256(body).hexdigest()
        assert event["target_onion_version"] == 3
    asyncio.run(run())


def test_tor_onion_subdomain_longer_than_common_name_limit_validates_tls(tmp_path):
    async def run():
        config, service = service_at(tmp_path)
        ca = config.artifact_dir / "tls/inetsim-ca.crt"
        _ensure_lab_ca(ca, ca.with_suffix(".key"))
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        host = "sub.deep." + ONION

        def request():
            with socket.create_connection((config.listen_host, port), timeout=5) as raw:
                raw.sendall(b"\x05\x01\x00")
                assert raw.recv(2) == b"\x05\x00"
                raw.sendall(connect_frame(host, 443))
                assert raw.recv(10)[:2] == b"\x05\x00"
                with ssl.create_default_context(cafile=str(ca)).wrap_socket(raw, server_hostname=host) as tls:
                    assert ("DNS", host) in tls.getpeercert()["subjectAltName"]
                    tls.sendall(f"GET / HTTP/1.1\r\nHost: {host}\r\n\r\n".encode())
                    response = b""
                    while chunk := tls.recv(4096):
                        response += chunk
                    assert b"HTTP/1.1 200 OK" in response
        try:
            await asyncio.to_thread(request)
        finally:
            running.close()
            await running.wait_closed()
        event = json.loads((config.log_dir / "tor_socks.jsonl").read_text().splitlines()[-1])
        assert event["target_onion_name"] == ONION[:-6]
        assert event["target_onion_subdomain"] == "sub.deep"
        assert event["target_onion_version"] == 3
        assert event["tls_established"] is True
    asyncio.run(run())


def test_tor_stream_error_after_success_does_not_send_second_socks_reply(tmp_path):
    async def run():
        config, service = service_at(tmp_path)
        running = await service.start()
        port = running.servers[0].sockets[0].getsockname()[1]
        try:
            reader, writer = await asyncio.open_connection(config.listen_host, port)
            writer.write(b"\x05\x01\x00")
            await writer.drain()
            assert await reader.readexactly(2) == b"\x05\x00"
            writer.write(connect_frame(ONION, 80))
            await writer.drain()
            assert (await reader.readexactly(10))[:2] == b"\x05\x00"
            writer.write(b"GET /incomplete")
            await writer.drain()
            writer.write_eof()
            assert await asyncio.wait_for(reader.read(), timeout=2) == b""
            writer.close()
            await writer.wait_closed()
        finally:
            running.close()
            await running.wait_closed()
        event = json.loads((config.log_dir / "tor_socks.jsonl").read_text().splitlines()[-1])
        assert event["connect_established"] is True
        assert event["error"] == "IncompleteReadError"
    asyncio.run(run())
