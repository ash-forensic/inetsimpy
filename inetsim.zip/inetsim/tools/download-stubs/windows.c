/* Harmless download replacements: no file, registry or network operations. */
#include <windows.h>

#ifdef BUILD_DLL
BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID reserved) {
    (void)instance; (void)reason; (void)reserved;
    return TRUE;
}

__declspec(dllexport) void CALLBACK Run(HWND window, HINSTANCE instance,
                                      LPSTR arguments, int show) {
    (void)window; (void)instance; (void)arguments; (void)show;
}

__declspec(dllexport) HRESULT WINAPI DllRegisterServer(void) { return S_OK; }
__declspec(dllexport) HRESULT WINAPI DllUnregisterServer(void) { return S_OK; }
#else
void WINAPI entry(void) { ExitProcess(0); }
#endif
